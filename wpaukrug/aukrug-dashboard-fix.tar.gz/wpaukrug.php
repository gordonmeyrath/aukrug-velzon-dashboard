<?php
/*
Plugin Name: Aukrug Connect
Plugin URI: https://aukrug.de
Description: WordPress Plugin für Aukrug Connect mit Admin-Dashboard
Version: 1.0.0
Author: MioWorkx
Author URI: https://mioworkx.de
Text Domain: wpaukrug
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin-Version definieren
if (!defined('AU_PLUGIN_VERSION')) {
    define('AU_PLUGIN_VERSION', '1.0.0');
}

// Include necessary files
require_once __DIR__ . '/includes/class-aukrug-cpt.php';
require_once __DIR__ . '/includes/class-aukrug-rest.php';
require_once __DIR__ . '/includes/class-aukrug-api.php';
require_once __DIR__ . '/includes/class-aukrug-database.php';
require_once __DIR__ . '/includes/class-aukrug-public-api.php';
require_once __DIR__ . '/admin/aukrug-dashboard.php';

// Health-Route einbinden
require_once __DIR__ . '/includes/class-aukrug-health.php';
add_action('rest_api_init', ['Aukrug_Health', 'register_route']);

// Initialize the plugin
function aukrug_connect_init() {
    if (class_exists('Aukrug_CPT')) new Aukrug_CPT();
    if (class_exists('Aukrug_REST')) new Aukrug_REST();
    if (class_exists('Aukrug_Public_API')) new Aukrug_Public_API();
    
    // Dashboard initialisieren
    if (class_exists('Aukrug_Dashboard')) {
        new Aukrug_Dashboard();
    }
}
add_action('init', 'aukrug_connect_init');

// Plugin activation hook
register_activation_hook(__FILE__, function() {
    if (function_exists('aukrug_check_database_version')) {
        aukrug_check_database_version();
    }
});

// Database version check on plugin load
add_action('plugins_loaded', function() {
    if (function_exists('aukrug_check_database_version')) {
        aukrug_check_database_version();
    }
});

// Admin-Assets nur auf Aukrug-Seite
add_action('admin_enqueue_scripts', function($hook) {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    $is_aukrug = ($screen && $screen->id === 'toplevel_page_aukrug') || (isset($_GET['page']) && $_GET['page'] === 'aukrug');
    if (!$is_aukrug) return;
    
    // Use dashboard assets
    $css = __DIR__ . '/assets/css/dashboard-admin.css';
    $js = __DIR__ . '/assets/js/dashboard-admin.js';
    
    if (file_exists($css)) {
        wp_enqueue_style('aukrug-admin', plugins_url('assets/css/dashboard-admin.css', __FILE__), [], filemtime($css));
    }
    if (file_exists($js)) {
        wp_enqueue_script('aukrug-admin', plugins_url('assets/js/dashboard-admin.js', __FILE__), [], filemtime($js), true);
        wp_script_add_data('aukrug-admin', 'type', 'module');
    }
    
    // External dependencies
    wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js', [], null, true);
    wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], null, true);
    wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], null);
});

// Load the real plugin implementation from the same directory (flattened)
if (file_exists(__DIR__ . '/au_aukrug_connect.php')) {
    require_once __DIR__ . '/au_aukrug_connect.php';
}
