<?php
/**
 * Aukrug Connect Clean Dashboard
 * Einziges Dashboard - kein doppeltes Menu
 */

// Verhindere direkten Zugriff
if (!defined('ABSPATH')) {
    exit;
}

class Aukrug_Dashboard_Clean {
    
    private static $instance = null;
    
    // Singleton Pattern um doppelte Initialisierung zu verhindern
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Verhindere mehrfache Initialisierung
        if (self::$instance !== null) {
            return;
        }
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_ajax_aukrug_dashboard_action', array($this, 'handle_ajax_actions'));
    }
    
    /**
     * Admin-Menü hinzufügen - nur einmal!
     */
    public function add_admin_menu() {
        // Prüfe ob Menu bereits existiert
        global $admin_page_hooks;
        if (isset($admin_page_hooks['aukrug'])) {
            error_log('[Aukrug] Dashboard menu already exists - skipping');
            return;
        }
        
        error_log('[Aukrug] Registering CLEAN dashboard menu');
        
        add_menu_page(
            'Aukrug Connect',
            'Aukrug Connect',
            'edit_posts',
            'aukrug',
            array($this, 'main_dashboard_page'),
            'dashicons-location-alt',
            25
        );
    }
    
    /**
     * Admin Assets laden
     */
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'aukrug') === false) {
            return;
        }
        
        // CSS und JS Assets laden
        $css_path = plugin_dir_path(__FILE__) . '../assets/css/dashboard-admin-v2.css';
        $js_path = plugin_dir_path(__FILE__) . '../assets/js/dashboard-admin.js';
        
        if (file_exists($css_path)) {
            wp_enqueue_style('aukrug-admin', plugins_url('../assets/css/dashboard-admin-v2.css', __FILE__), [], filemtime($css_path));
        }
        if (file_exists($js_path)) {
            wp_enqueue_script('aukrug-admin', plugins_url('../assets/js/dashboard-admin.js', __FILE__), [], filemtime($js_path), true);
        }
        
        // External dependencies
        wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js', [], null, true);
        
        // Ajax Nonce
        wp_localize_script('aukrug-admin', 'aukrug_ajax', array(
            'nonce' => wp_create_nonce('aukrug_dashboard_nonce'),
            'ajax_url' => admin_url('admin-ajax.php')
        ));
    }

    /**
     * Hauptseite des Dashboards
     */
    public function main_dashboard_page() {
        $current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'overview';
        
        // Dashboard stats
        $stats = $this->get_dashboard_stats();
        ?>
        <div class="aukrug-dashboard">
            <h1>
                <span class="dashicons dashicons-location-alt"></span>
                Aukrug Connect Dashboard
                <span class="version-badge">v1.0.0</span>
            </h1>
            
            <!-- Tab Navigation -->
            <div class="nav-tab-wrapper">
                <a href="?page=aukrug&tab=overview" class="nav-tab <?php echo $current_tab === 'overview' ? 'nav-tab-active' : ''; ?>">
                    <span class="dashicons dashicons-dashboard"></span> Übersicht
                </a>
                <a href="?page=aukrug&tab=reports" class="nav-tab <?php echo $current_tab === 'reports' ? 'nav-tab-active' : ''; ?>">
                    <span class="dashicons dashicons-feedback"></span> Meldungen/Tickets
                </a>
                <a href="?page=aukrug&tab=places" class="nav-tab <?php echo $current_tab === 'places' ? 'nav-tab-active' : ''; ?>">
                    <span class="dashicons dashicons-location"></span> Orte & POIs
                </a>
                <a href="?page=aukrug&tab=users" class="nav-tab <?php echo $current_tab === 'users' ? 'nav-tab-active' : ''; ?>">
                    <span class="dashicons dashicons-admin-users"></span> App-Benutzer
                </a>
                <a href="?page=aukrug&tab=settings" class="nav-tab <?php echo $current_tab === 'settings' ? 'nav-tab-active' : ''; ?>">
                    <span class="dashicons dashicons-admin-settings"></span> Einstellungen
                </a>
            </div>

            <!-- Tab Content -->
            <div class="tab-content">
                <?php
                switch ($current_tab) {
                    case 'overview':
                        $this->render_overview_tab($stats);
                        break;
                    case 'reports':
                        $this->render_reports_tab();
                        break;
                    case 'places':
                        $this->render_places_tab();
                        break;
                    case 'users':
                        $this->render_users_tab();
                        break;
                    case 'settings':
                        $this->render_settings_tab();
                        break;
                    default:
                        $this->render_overview_tab($stats);
                }
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Overview Tab
     */
    private function render_overview_tab($stats) {
        ?>
        <!-- KPI Cards -->
        <div class="kpi-grid">
            <div class="kpi-card users">
                <div class="kpi-icon">
                    <span class="dashicons dashicons-admin-users"></span>
                </div>
                <div class="kpi-content">
                    <h3>App Benutzer</h3>
                    <div class="kpi-value"><?php echo number_format($stats['total_users']); ?></div>
                    <div class="kpi-change positive">+<?php echo $stats['new_users_this_week']; ?> diese Woche</div>
                </div>
            </div>
            
            <div class="kpi-card reports">
                <div class="kpi-icon">
                    <span class="dashicons dashicons-feedback"></span>
                </div>
                <div class="kpi-content">
                    <h3>Offene Tickets</h3>
                    <div class="kpi-value"><?php echo number_format($stats['open_reports']); ?></div>
                    <div class="kpi-change neutral"><?php echo $stats['new_reports_today']; ?> heute</div>
                </div>
            </div>
            
            <div class="kpi-card places">
                <div class="kpi-icon">
                    <span class="dashicons dashicons-location"></span>
                </div>
                <div class="kpi-content">
                    <h3>Orte & POIs</h3>
                    <div class="kpi-value"><?php echo number_format($stats['total_places']); ?></div>
                    <div class="kpi-change neutral"><?php echo $stats['active_places']; ?> aktiv</div>
                </div>
            </div>
            
            <div class="kpi-card api-calls">
                <div class="kpi-icon">
                    <span class="dashicons dashicons-admin-network"></span>
                </div>
                <div class="kpi-content">
                    <h3>API Aufrufe</h3>
                    <div class="kpi-value"><?php echo number_format($stats['api_calls_today']); ?></div>
                    <div class="kpi-change positive">Heute</div>
                </div>
            </div>
        </div>
        
        <!-- Chart mit fester Höhe -->
        <div class="dashboard-panels">
            <div class="panel-left">
                <div class="dashboard-panel chart-panel">
                    <h3><span class="dashicons dashicons-chart-line"></span> Benutzeraktivität (7 Tage)</h3>
                    <div class="chart-container">
                        <canvas id="userActivityChart"></canvas>
                    </div>
                </div>
            </div>
            
            <div class="panel-right">
                <div class="dashboard-panel">
                    <h3><span class="dashicons dashicons-bell"></span> Aktuelle Aktivitäten</h3>
                    <div class="activity-feed">
                        <?php foreach ($stats['recent_activities'] as $activity): ?>
                            <div class="activity-item">
                                <div class="activity-time"><?php echo human_time_diff(strtotime($activity['time'])); ?> ago</div>
                                <div class="activity-description"><?php echo esc_html($activity['description']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        // Chart mit fester Höhe
        document.addEventListener('DOMContentLoaded', function() {
            const canvas = document.getElementById('userActivityChart');
            if (canvas) {
                const ctx = canvas.getContext('2d');
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode($stats['activity_labels']); ?>,
                        datasets: [{
                            label: 'Aktive Benutzer',
                            data: <?php echo json_encode($stats['activity_data']); ?>,
                            borderColor: '#0073aa',
                            backgroundColor: 'rgba(0, 115, 170, 0.1)',
                            tension: 0.4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: true }
                        },
                        scales: {
                            y: { beginAtZero: true }
                        }
                    }
                });
            }
        });
        </script>
        <?php
    }

    /**
     * Reports Tab - Ticket-System
     */
    private function render_reports_tab() {
        ?>
        <div class="reports-management">
            <h2><span class="dashicons dashicons-feedback"></span> Meldungen & Tickets</h2>
            <p>Hier würde das vollständige Ticket-System erscheinen.</p>
            
            <div class="status-filter">
                <a href="#" class="filter-link active">Alle (25)</a>
                <a href="#" class="filter-link">Offen (8)</a>
                <a href="#" class="filter-link">In Bearbeitung (5)</a>
                <a href="#" class="filter-link">Gelöst (10)</a>
                <a href="#" class="filter-link">Geschlossen (2)</a>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Titel</th>
                        <th>Status</th>
                        <th>Priorität</th>
                        <th>Erstellt</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>#001</td>
                        <td>Straßenschaden Hauptstraße</td>
                        <td><span class="status-badge status-open">Offen</span></td>
                        <td><span class="priority-badge priority-high">Hoch</span></td>
                        <td>07.09.2025 09:30</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Places Tab
     */
    private function render_places_tab() {
        echo '<h2>Orte & POIs Verwaltung</h2><p>Places-Management wird hier implementiert.</p>';
    }

    /**
     * Users Tab
     */
    private function render_users_tab() {
        echo '<h2>App Benutzer Verwaltung</h2><p>User-Management wird hier implementiert.</p>';
    }

    /**
     * Settings Tab
     */
    private function render_settings_tab() {
        echo '<h2>Plugin Einstellungen</h2><p>Settings werden hier implementiert.</p>';
    }

    /**
     * Dashboard-Statistiken
     */
    private function get_dashboard_stats() {
        return array(
            'total_users' => 156,
            'new_users_this_week' => 12,
            'open_reports' => 8,
            'new_reports_today' => 3,
            'total_places' => 10,
            'active_places' => 10,
            'api_calls_today' => 1247,
            'activity_labels' => ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'],
            'activity_data' => [45, 52, 38, 47, 59, 73, 68],
            'recent_activities' => array(
                array('time' => '2025-09-07 10:30:00', 'description' => 'Neue Meldung eingegangen'),
                array('time' => '2025-09-07 09:15:00', 'description' => 'Benutzer registriert'),
                array('time' => '2025-09-07 08:45:00', 'description' => 'GeoCaching-Fund gemeldet'),
                array('time' => '2025-09-06 16:20:00', 'description' => 'POI aktualisiert'),
            )
        );
    }

    /**
     * AJAX Actions
     */
    public function handle_ajax_actions() {
        check_ajax_referer('aukrug_dashboard_nonce', 'nonce');
        wp_send_json_success(['message' => 'Action processed']);
    }
}

// Keine automatische Initialisierung hier!
