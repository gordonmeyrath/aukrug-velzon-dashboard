/**
 * Aukrug Connect Dashboard - Modern Admin JavaScript
 * Interactive features and AJAX functionality
 */

(function($) {
    'use strict';
    
    class AukrugDashboard {
        constructor() {
            this.init();
        }
        
        init() {
            this.bindEvents();
            this.initCharts();
            this.initRefreshTimers();
            this.initQuickActions();
        }
        
        bindEvents() {
            // Tab switching with animation
            $('.nav-tab').on('click', this.handleTabSwitch.bind(this));
            
            // Refresh buttons
            $('.refresh-stats').on('click', this.refreshStats.bind(this));
            
            // Quick action buttons
            $('.quick-action-btn').on('click', this.handleQuickAction.bind(this));
            
            // Search functionality
            $('.aukrug-search').on('input', this.handleSearch.bind(this));
        }
        
        handleTabSwitch(e) {
            e.preventDefault();
            
            const $tab = $(e.currentTarget);
            const targetUrl = $tab.attr('href');
            
            // Update active state
            $('.nav-tab').removeClass('nav-tab-active');
            $tab.addClass('nav-tab-active');
            
            // Fade content
            $('.aukrug-tab-content').addClass('loading');
            
            // Load new content (in real app, this would be AJAX)
            setTimeout(() => {
                window.location.href = targetUrl;
            }, 200);
        }
        
        refreshStats() {
            if (!aukrug_ajax) return;
            
            $.ajax({
                url: aukrug_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'aukrug_dashboard_action',
                    action_type: 'refresh_stats',
                    nonce: aukrug_ajax.nonce
                },
                beforeSend: () => {
                    $('.kpi-cards-row').addClass('loading');
                },
                success: (response) => {
                    if (response.success) {
                        this.updateStatsDisplay(response.data);
                        this.showNotice('Statistiken aktualisiert', 'success');
                    }
                },
                error: () => {
                    this.showNotice('Fehler beim Laden der Statistiken', 'error');
                },
                complete: () => {
                    $('.kpi-cards-row').removeClass('loading');
                }
            });
        }
        
        updateStatsDisplay(stats) {
            // Update KPI values with animation
            Object.keys(stats).forEach(key => {
                const $element = $(`.kpi-${key} .kpi-value`);
                if ($element.length) {
                    this.animateNumber($element, parseInt(stats[key]) || 0);
                }
            });
        }
        
        animateNumber($element, targetValue) {
            const startValue = parseInt($element.text().replace(/,/g, '')) || 0;
            const duration = 1000;
            const startTime = Date.now();
            
            const updateNumber = () => {
                const elapsed = Date.now() - startTime;
                const progress = Math.min(elapsed / duration, 1);
                
                // Easing function
                const easeOutCubic = 1 - Math.pow(1 - progress, 3);
                
                const currentValue = Math.round(startValue + (targetValue - startValue) * easeOutCubic);
                $element.text(currentValue.toLocaleString());
                
                if (progress < 1) {
                    requestAnimationFrame(updateNumber);
                }
            };
            
            requestAnimationFrame(updateNumber);
        }
        
        handleQuickAction(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const action = $btn.data('action');
            
            if (!aukrug_ajax || !action) return;
            
            $.ajax({
                url: aukrug_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'aukrug_dashboard_action',
                    action_type: 'quick_action',
                    quick_action: action,
                    nonce: aukrug_ajax.nonce
                },
                beforeSend: () => {
                    $btn.addClass('loading').prop('disabled', true);
                },
                success: (response) => {
                    if (response.success) {
                        this.showNotice(`Aktion "${action}" erfolgreich ausgeführt`, 'success');
                    } else {
                        this.showNotice('Aktion fehlgeschlagen', 'error');
                    }
                },
                error: () => {
                    this.showNotice('Verbindungsfehler', 'error');
                },
                complete: () => {
                    $btn.removeClass('loading').prop('disabled', false);
                }
            });
        }
        
        handleSearch(e) {
            const query = $(e.target).val().toLowerCase();
            const $items = $('.searchable-item');
            
            $items.each(function() {
                const $item = $(this);
                const text = $item.text().toLowerCase();
                
                if (text.includes(query)) {
                    $item.show().addClass('fade-in');
                } else {
                    $item.hide().removeClass('fade-in');
                }
            });
        }
        
        initCharts() {
            // Chart.js initialization is handled in PHP template
            // This method can be extended for additional chart features
            
            // Make charts responsive
            if (window.Chart) {
                Chart.defaults.responsive = true;
                Chart.defaults.maintainAspectRatio = false;
            }
        }
        
        initRefreshTimers() {
            // Auto-refresh stats every 5 minutes
            setInterval(() => {
                this.refreshStats();
            }, 5 * 60 * 1000);
            
            // Update timestamps every minute
            setInterval(() => {
                this.updateTimestamps();
            }, 60 * 1000);
        }
        
        updateTimestamps() {
            $('.activity-time').each(function() {
                const $time = $(this);
                const timeString = $time.data('time');
                if (timeString) {
                    const timeAgo = this.timeAgo(new Date(timeString));
                    $time.text(timeAgo);
                }
            }.bind(this));
        }
        
        timeAgo(date) {
            const now = new Date();
            const seconds = Math.floor((now - date) / 1000);
            
            const intervals = {
                'Jahr': 31536000,
                'Monat': 2592000,
                'Woche': 604800,
                'Tag': 86400,
                'Stunde': 3600,
                'Minute': 60
            };
            
            for (const [unit, secondsInUnit] of Object.entries(intervals)) {
                const interval = Math.floor(seconds / secondsInUnit);
                if (interval >= 1) {
                    return `vor ${interval} ${unit}${interval > 1 ? (unit === 'Monat' ? 'en' : unit === 'Jahr' ? 'en' : 'n') : ''}`;
                }
            }
            
            return 'gerade eben';
        }
        
        initQuickActions() {
            // Initialize quick action tooltips and confirmations
            $('.quick-action-btn[data-confirm]').on('click', function(e) {
                e.preventDefault();
                
                const $btn = $(this);
                const confirmText = $btn.data('confirm');
                
                if (confirm(confirmText)) {
                    // Proceed with original click handler
                    $btn.off('click').trigger('click');
                }
            });
        }
        
        showNotice(message, type = 'info') {
            const $notice = $(`
                <div class="aukrug-notice ${type} fade-in">
                    <span class="dashicons ${this.getNoticeIcon(type)}"></span>
                    ${message}
                    <button type="button" class="notice-dismiss">
                        <span class="dashicons dashicons-dismiss"></span>
                    </button>
                </div>
            `);
            
            // Insert at top of content
            $('.aukrug-tab-content').prepend($notice);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                $notice.fadeOut(() => $notice.remove());
            }, 5000);
            
            // Manual dismiss
            $notice.find('.notice-dismiss').on('click', () => {
                $notice.fadeOut(() => $notice.remove());
            });
        }
        
        getNoticeIcon(type) {
            const icons = {
                'success': 'dashicons-yes-alt',
                'error': 'dashicons-warning',
                'warning': 'dashicons-info',
                'info': 'dashicons-info'
            };
            
            return icons[type] || icons.info;
        }
    }
    
    // Utility functions
    window.AukrugUtils = {
        formatNumber: (num) => {
            return new Intl.NumberFormat('de-DE').format(num);
        },
        
        formatBytes: (bytes) => {
            if (bytes === 0) return '0 Bytes';
            
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        },
        
        copyToClipboard: (text) => {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text).then(() => {
                    window.aukrugDashboard.showNotice('In Zwischenablage kopiert', 'success');
                });
            } else {
                // Fallback for older browsers
                const textArea = document.createElement('textarea');
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                window.aukrugDashboard.showNotice('In Zwischenablage kopiert', 'success');
            }
        }
    };
    
    // Initialize when DOM is ready
    $(document).ready(() => {
        window.aukrugDashboard = new AukrugDashboard();
    });
    
})(jQuery);
