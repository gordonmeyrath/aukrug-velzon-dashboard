<?php
/**
 * Modern Admin Dashboard Page
 * Aukrug Plugin - MioConneX-level polish
 */

// Security check
if (!current_user_can('manage_options')) {
    wp_die(__('Sie haben keine Berechtigung für diese Seite.'));
}
?>

<div id="au-admin-app" class="au-container">
    <!-- Topbar -->
    <div class="au-topbar">
        <h1>Aukrug Dashboard</h1>
        <div class="au-flex au-gap-4">
            <span class="au-version">v<?php echo defined('AUKRUG_CONNECT_VERSION') ? AUKRUG_CONNECT_VERSION : '1.0.0'; ?></span>
            <div class="au-status online" id="health-status">
                <div class="status-indicator"></div>
                System wird geprüft...
            </div>
        </div>
    </div>

    <!-- Tab Navigation -->
    <nav class="au-tabs">
        <button data-tab="overview" class="is-active">Übersicht</button>
        <button data-tab="community">Community</button>
        <button data-tab="geocaching">Geocaching</button>
        <button data-tab="appcaches">App-Caches</button>
        <button data-tab="reports">Meldungen</button>
        <button data-tab="devices">Geräte</button>
        <button data-tab="sync">Synchronisation</button>
        <button data-tab="settings">Einstellungen</button>
    </nav>

    <!-- Overview Tab -->
    <div data-tab-content="overview">
        <!-- KPI Grid -->
        <div class="au-kpi-grid" id="kpis-container">
            <div class="au-kpi">
                <span class="au-kpi-value">-</span>
                <span class="au-kpi-label">Wird geladen...</span>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="au-quick-actions">
            <button class="au-btn au-btn-primary">
                <span>🔄</span> Daten aktualisieren
            </button>
            <button class="au-btn au-btn-ghost">
                <span>📊</span> Vollständiger Bericht
            </button>
            <button class="au-btn au-btn-ghost">
                <span>⚙️</span> System-Check
            </button>
        </div>

        <!-- Recent Activity -->
        <div class="au-card">
            <h2>Letzte Aktivitäten</h2>
            <div id="recent-activity">
                <p class="au-text-muted">Aktivitäten werden geladen...</p>
            </div>
        </div>
    </div>

    <!-- Community Tab -->
    <div data-tab-content="community" style="display: none;">
        <div class="au-card">
            <h2>Community Verwaltung</h2>
            
            <!-- Community Stats -->
            <div class="au-kpi-grid" id="community-stats">
                <div class="au-kpi">
                    <span class="au-kpi-value" id="total-members">-</span>
                    <span class="au-kpi-label">Mitglieder</span>
                </div>
                <div class="au-kpi">
                    <span class="au-kpi-value" id="active-members">-</span>
                    <span class="au-kpi-label">Aktive Mitglieder</span>
                </div>
                <div class="au-kpi">
                    <span class="au-kpi-value" id="new-members">-</span>
                    <span class="au-kpi-label">Neue (30 Tage)</span>
                </div>
            </div>

            <!-- Member Management -->
            <div class="au-flex au-gap-4 au-mb-4">
                <button class="au-btn au-btn-primary">Neues Mitglied</button>
                <button class="au-btn au-btn-ghost">Export CSV</button>
                <div class="au-segmented">
                    <button class="active">Alle</button>
                    <button>Aktiv</button>
                    <button>Inaktiv</button>
                </div>
            </div>

            <div id="community-table">
                <p class="au-text-muted">Mitglieder werden geladen...</p>
            </div>
        </div>
    </div>

    <!-- Geocaching Tab -->
    <div data-tab-content="geocaching" style="display: none;">
        <div class="au-card">
            <h2>Geocaching Verwaltung</h2>
            
            <!-- Geocaching Stats -->
            <div class="au-kpi-grid" id="geocaching-stats">
                <div class="au-kpi">
                    <span class="au-kpi-value" id="total-caches">-</span>
                    <span class="au-kpi-label">Geocaches</span>
                </div>
                <div class="au-kpi">
                    <span class="au-kpi-value" id="active-caches">-</span>
                    <span class="au-kpi-label">Aktive Caches</span>
                </div>
                <div class="au-kpi">
                    <span class="au-kpi-value" id="archived-caches">-</span>
                    <span class="au-kpi-label">Archiviert</span>
                </div>
            </div>

            <!-- Map -->
            <div class="au-card au-mb-4">
                <h3>Karte</h3>
                <div id="geocaching-map" class="au-map"></div>
            </div>

            <!-- Cache Table -->
            <div id="geocaching-table">
                <p class="au-text-muted">Geocaches werden geladen...</p>
            </div>
        </div>
    </div>

    <!-- App-Only Caches Tab -->
    <div data-tab-content="appcaches" style="display: none;">
        <div class="au-card">
            <h2>App-Only Caches</h2>
            
            <div class="au-flex au-gap-4 au-mb-4">
                <button class="au-btn au-btn-primary">Neuen Cache erstellen</button>
                <button class="au-btn au-btn-ghost">Import von GPX</button>
            </div>

            <div id="appcaches-table">
                <p class="au-text-muted">App-Caches werden geladen...</p>
            </div>
        </div>
    </div>

    <!-- Reports Tab -->
    <div data-tab-content="reports" style="display: none;">
        <div class="au-card">
            <h2>Meldungen & Reports</h2>
            
            <!-- Reports Stats -->
            <div class="au-kpi-grid" id="reports-stats">
                <div class="au-kpi">
                    <span class="au-kpi-value" id="total-reports">-</span>
                    <span class="au-kpi-label">Gesamt</span>
                </div>
                <div class="au-kpi">
                    <span class="au-kpi-value" id="open-reports">-</span>
                    <span class="au-kpi-label">Offen</span>
                </div>
                <div class="au-kpi">
                    <span class="au-kpi-value" id="urgent-reports">-</span>
                    <span class="au-kpi-label">Dringend</span>
                </div>
            </div>

            <div class="au-flex au-gap-4 au-mb-4">
                <div class="au-segmented">
                    <button class="active">Alle</button>
                    <button>Offen</button>
                    <button>Bearbeitet</button>
                    <button>Geschlossen</button>
                </div>
                <button class="au-btn au-btn-ghost">Export</button>
            </div>

            <div id="reports-table">
                <p class="au-text-muted">Meldungen werden geladen...</p>
            </div>
        </div>
    </div>

    <!-- Devices Tab -->
    <div data-tab-content="devices" style="display: none;">
        <div class="au-card">
            <h2>Registrierte Geräte</h2>
            
            <div class="au-flex au-gap-4 au-mb-4">
                <div class="au-segmented">
                    <button class="active">Alle Geräte</button>
                    <button>iOS</button>
                    <button>Android</button>
                </div>
                <button class="au-btn au-btn-ghost">Push-Benachrichtigung</button>
            </div>

            <div id="devices-table">
                <p class="au-text-muted">Geräte werden geladen...</p>
            </div>
        </div>
    </div>

    <!-- Sync Tab -->
    <div data-tab-content="sync" style="display: none;">
        <div id="sync-status">
            <p class="au-text-muted">Sync-Status wird geladen...</p>
        </div>

        <div class="au-card">
            <h3>Sync-Protokoll</h3>
            <div id="sync-logs">
                <p class="au-text-muted">Protokoll wird geladen...</p>
            </div>
        </div>
    </div>

    <!-- Settings Tab -->
    <div data-tab-content="settings" style="display: none;">
        <div id="settings-container">
            <!-- Settings werden dynamisch von JavaScript geladen -->
            <div class="au-card">
                <div class="au-loading">Einstellungen werden geladen...</div>
            </div>
        </div>
    </div>
</div>

<!-- Include external dependencies -->
<script src="https://unpkg.com/chart.js@4.4.0/dist/chart.umd.js"></script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

<script>
// WordPress API settings for the dashboard
const wpApiSettings = {
    nonce: '<?php echo wp_create_nonce('wp_rest'); ?>',
    root: '<?php echo esc_url_raw(rest_url()); ?>'
};
</script>
