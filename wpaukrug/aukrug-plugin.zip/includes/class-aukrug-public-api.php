<?php
/**
 * Public REST API Endpoints for Flutter App
 * These endpoints are accessible without authentication
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Aukrug_Public_API {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_public_routes'));
    }

    public function register_public_routes() {
        // Places API
        register_rest_route('aukrug/v1', '/places', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_places'),
            'permission_callback' => '__return_true',
            'args' => array(
                'search' => array(
                    'type' => 'string',
                    'required' => false,
                    'description' => 'Search term for places'
                ),
                'category' => array(
                    'type' => 'string',
                    'required' => false,
                    'description' => 'Filter by category'
                ),
                'per_page' => array(
                    'type' => 'integer',
                    'required' => false,
                    'default' => 20,
                    'minimum' => 1,
                    'maximum' => 100
                ),
                'page' => array(
                    'type' => 'integer',
                    'required' => false,
                    'default' => 1,
                    'minimum' => 1
                )
            )
        ));

        register_rest_route('aukrug/v1', '/places/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_place'),
            'permission_callback' => '__return_true',
            'args' => array(
                'id' => array(
                    'type' => 'integer',
                    'required' => true,
                    'description' => 'Place ID'
                )
            )
        ));

        // Events API
        register_rest_route('aukrug/v1', '/events', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_events'),
            'permission_callback' => '__return_true',
            'args' => array(
                'from_date' => array(
                    'type' => 'string',
                    'required' => false,
                    'description' => 'Filter events from this date (YYYY-MM-DD)'
                ),
                'to_date' => array(
                    'type' => 'string',
                    'required' => false,
                    'description' => 'Filter events to this date (YYYY-MM-DD)'
                ),
                'per_page' => array(
                    'type' => 'integer',
                    'required' => false,
                    'default' => 20,
                    'minimum' => 1,
                    'maximum' => 100
                ),
                'page' => array(
                    'type' => 'integer',
                    'required' => false,
                    'default' => 1,
                    'minimum' => 1
                )
            )
        ));

        register_rest_route('aukrug/v1', '/events/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_event'),
            'permission_callback' => '__return_true',
            'args' => array(
                'id' => array(
                    'type' => 'integer',
                    'required' => true,
                    'description' => 'Event ID'
                )
            )
        ));

        // Public App Health Check
        register_rest_route('aukrug/v1', '/health', array(
            'methods' => 'GET',
            'callback' => array($this, 'health_check'),
            'permission_callback' => '__return_true'
        ));

        // Downloads API (public downloads only)
        register_rest_route('aukrug/v1', '/downloads', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_public_downloads'),
            'permission_callback' => '__return_true',
            'args' => array(
                'category' => array(
                    'type' => 'string',
                    'required' => false,
                    'description' => 'Filter by category'
                ),
                'per_page' => array(
                    'type' => 'integer',
                    'required' => false,
                    'default' => 20,
                    'minimum' => 1,
                    'maximum' => 100
                ),
                'page' => array(
                    'type' => 'integer',
                    'required' => false,
                    'default' => 1,
                    'minimum' => 1
                )
            )
        ));
    }

    public function health_check($request) {
        return rest_ensure_response(array(
            'ok' => true,
            'plugin' => 'Aukrug WordPress Plugin',
            'version' => get_option('aukrug_version', '1.0.0'),
            'time' => current_time('mysql'),
            'endpoints' => array(
                'places' => '/aukrug/v1/places',
                'events' => '/aukrug/v1/events',
                'downloads' => '/aukrug/v1/downloads'
            )
        ));
    }

    public function get_places($request) {
        $args = array(
            'post_type' => 'geocache',
            'post_status' => 'publish',
            'posts_per_page' => $request->get_param('per_page') ?: 20,
            'paged' => $request->get_param('page') ?: 1,
            'orderby' => 'title',
            'order' => 'ASC'
        );

        // Add search parameter
        if ($search = $request->get_param('search')) {
            $args['s'] = sanitize_text_field($search);
        }

        // Add category filter (use taxonomy instead of meta)
        if ($category = $request->get_param('category')) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'cache_type',
                    'field' => 'slug',
                    'terms' => sanitize_text_field($category)
                )
            );
        }

        $query = new WP_Query($args);
        $places = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post_id = get_the_ID();
                
                // Get cache types
                $cache_types = wp_get_post_terms($post_id, 'cache_type', array('fields' => 'slugs'));
                $category = !empty($cache_types) ? $cache_types[0] : 'general';
                
                $places[] = array(
                    'id' => "place_" . str_pad($post_id, 3, '0', STR_PAD_LEFT),
                    'name' => get_the_title(),
                    'description' => get_the_content(),
                    'category' => $category,
                    'coordinates' => array(
                        'lat' => (float) get_post_meta($post_id, 'coords_lat', true),
                        'lng' => (float) get_post_meta($post_id, 'coords_lng', true)
                    ),
                    'website' => get_post_meta($post_id, 'website', true),
                    'phone' => get_post_meta($post_id, 'phone', true),
                    'images' => $this->get_post_images($post_id),
                    'gc_code' => get_post_meta($post_id, 'gc_code', true)
                );
            }
            wp_reset_postdata();
        }

        $response = array(
            'data' => $places,
            'meta' => array(
                'count' => count($places),
                'total' => $query->found_posts,
                'page' => (int) ($request->get_param('page') ?: 1),
                'per_page' => (int) ($request->get_param('per_page') ?: 20),
                'last_modified' => current_time('mysql')
            )
        );

        // Add ETag for caching
        $etag = 'W/"places-v1-' . md5(serialize($response)) . '"';
        
        return rest_ensure_response($response);
    }

    public function get_place($request) {
        $id = $request->get_param('id');
        $post = get_post($id);

        if (!$post || $post->post_type !== 'geocache' || $post->post_status !== 'publish') {
            return new WP_Error('place_not_found', 'Place not found', array('status' => 404));
        }

        $place = array(
            'id' => "place_" . str_pad($id, 3, '0', STR_PAD_LEFT),
            'name' => $post->post_title,
            'description' => $post->post_content,
            'category' => get_post_meta($id, 'category', true) ?: 'general',
            'coordinates' => array(
                'lat' => (float) get_post_meta($id, 'coords_lat', true),
                'lng' => (float) get_post_meta($id, 'coords_lng', true)
            ),
            'website' => get_post_meta($id, 'website', true),
            'phone' => get_post_meta($id, 'phone', true),
            'images' => $this->get_post_images($id),
            'last_modified' => $post->post_modified
        );

        return rest_ensure_response($place);
    }

    public function get_events($request) {
        $args = array(
            'post_type' => 'aukrug_event',
            'post_status' => 'publish',
            'posts_per_page' => $request->get_param('per_page') ?: 20,
            'paged' => $request->get_param('page') ?: 1,
            'meta_key' => 'event_date',
            'orderby' => 'meta_value',
            'order' => 'ASC'
        );

        // Add date filters
        $meta_query = array();
        
        if ($from_date = $request->get_param('from_date')) {
            $meta_query[] = array(
                'key' => 'event_date',
                'value' => sanitize_text_field($from_date),
                'compare' => '>=',
                'type' => 'DATE'
            );
        }

        if ($to_date = $request->get_param('to_date')) {
            $meta_query[] = array(
                'key' => 'event_date',
                'value' => sanitize_text_field($to_date),
                'compare' => '<=',
                'type' => 'DATE'
            );
        }

        if (!empty($meta_query)) {
            $args['meta_query'] = $meta_query;
        }

        $query = new WP_Query($args);
        $events = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post_id = get_the_ID();
                
                $events[] = array(
                    'id' => "event_" . str_pad($post_id, 3, '0', STR_PAD_LEFT),
                    'title' => get_the_title(),
                    'description' => get_the_content(),
                    'date' => get_post_meta($post_id, 'event_date', true),
                    'time' => get_post_meta($post_id, 'event_time', true),
                    'location' => array(
                        'name' => get_post_meta($post_id, 'location_name', true),
                        'address' => get_post_meta($post_id, 'location_address', true),
                        'coordinates' => array(
                            'lat' => (float) get_post_meta($post_id, 'coords_lat', true),
                            'lng' => (float) get_post_meta($post_id, 'coords_lng', true)
                        )
                    ),
                    'organizer' => get_post_meta($post_id, 'organizer', true),
                    'website' => get_post_meta($post_id, 'website', true),
                    'images' => $this->get_post_images($post_id)
                );
            }
            wp_reset_postdata();
        }

        $response = array(
            'data' => $events,
            'meta' => array(
                'count' => count($events),
                'total' => $query->found_posts,
                'page' => (int) ($request->get_param('page') ?: 1),
                'per_page' => (int) ($request->get_param('per_page') ?: 20),
                'last_modified' => current_time('mysql')
            )
        );

        return rest_ensure_response($response);
    }

    public function get_event($request) {
        $id = $request->get_param('id');
        $post = get_post($id);

        if (!$post || $post->post_type !== 'aukrug_event' || $post->post_status !== 'publish') {
            return new WP_Error('event_not_found', 'Event not found', array('status' => 404));
        }

        $event = array(
            'id' => "event_" . str_pad($id, 3, '0', STR_PAD_LEFT),
            'title' => $post->post_title,
            'description' => $post->post_content,
            'date' => get_post_meta($id, 'event_date', true),
            'time' => get_post_meta($id, 'event_time', true),
            'location' => array(
                'name' => get_post_meta($id, 'location_name', true),
                'address' => get_post_meta($id, 'location_address', true),
                'coordinates' => array(
                    'lat' => (float) get_post_meta($id, 'coords_lat', true),
                    'lng' => (float) get_post_meta($id, 'coords_lng', true)
                )
            ),
            'organizer' => get_post_meta($id, 'organizer', true),
            'website' => get_post_meta($id, 'website', true),
            'images' => $this->get_post_images($id),
            'last_modified' => $post->post_modified
        );

        return rest_ensure_response($event);
    }

    public function get_public_downloads($request) {
        $args = array(
            'post_type' => 'aukrug_download',
            'post_status' => 'publish',
            'posts_per_page' => $request->get_param('per_page') ?: 20,
            'paged' => $request->get_param('page') ?: 1,
            'meta_query' => array(
                array(
                    'key' => 'is_public',
                    'value' => '1',
                    'compare' => '='
                )
            ),
            'orderby' => 'date',
            'order' => 'DESC'
        );

        // Add category filter
        if ($category = $request->get_param('category')) {
            $args['meta_query'][] = array(
                'key' => 'category',
                'value' => sanitize_text_field($category),
                'compare' => '='
            );
        }

        $query = new WP_Query($args);
        $downloads = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post_id = get_the_ID();
                
                $downloads[] = array(
                    'id' => "download_" . str_pad($post_id, 3, '0', STR_PAD_LEFT),
                    'title' => get_the_title(),
                    'description' => get_the_content(),
                    'category' => get_post_meta($post_id, 'category', true) ?: 'general',
                    'file_url' => get_post_meta($post_id, 'file_url', true),
                    'file_size' => get_post_meta($post_id, 'file_size', true),
                    'download_count' => (int) get_post_meta($post_id, 'download_count', true),
                    'published_date' => get_the_date('c')
                );
            }
            wp_reset_postdata();
        }

        $response = array(
            'data' => $downloads,
            'meta' => array(
                'count' => count($downloads),
                'total' => $query->found_posts,
                'page' => (int) ($request->get_param('page') ?: 1),
                'per_page' => (int) ($request->get_param('per_page') ?: 20),
                'last_modified' => current_time('mysql')
            )
        );

        return rest_ensure_response($response);
    }

    private function get_post_images($post_id) {
        $images = array();
        
        // Get featured image
        if (has_post_thumbnail($post_id)) {
            $images[] = get_the_post_thumbnail_url($post_id, 'large');
        }

        // Get gallery images
        $gallery = get_post_meta($post_id, '_gallery_images', true);
        if ($gallery && is_array($gallery)) {
            foreach ($gallery as $image_id) {
                $image_url = wp_get_attachment_image_url($image_id, 'large');
                if ($image_url) {
                    $images[] = $image_url;
                }
            }
        }

        return $images;
    }
}
