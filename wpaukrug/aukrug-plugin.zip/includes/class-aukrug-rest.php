<?php
/**
 * Comprehensive REST API Endpoints
 * Complete backend implementation for modern dashboard
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Aukrug_Rest {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        // KPIs and Overview
        register_rest_route('aukrug/v1', '/kpis', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_kpis'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/recent-activity', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_recent_activity'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        // Community Management
        register_rest_route('aukrug/v1', '/community/members', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_community_members'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/community/posts', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_community_posts'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/community/events', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_community_events'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        // Geocaching
        register_rest_route('aukrug/v1', '/geocaching/caches', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_geocaching_caches'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/geocaching/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_geocaching_stats'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        // App-Only Caches
        register_rest_route('aukrug/v1', '/appcaches', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_app_caches'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/appcaches', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_app_cache'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        // Reports
        register_rest_route('aukrug/v1', '/reports', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_reports'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/reports/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_reports_stats'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/reports/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_report'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/reports/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_report'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        // Devices
        register_rest_route('aukrug/v1', '/devices', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_devices'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        // Sync
        register_rest_route('aukrug/v1', '/sync/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_sync_status'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/sync/logs', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_sync_logs'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/sync/start', array(
            'methods' => 'POST',
            'callback' => array($this, 'start_sync'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/sync/stop', array(
            'methods' => 'POST',
            'callback' => array($this, 'stop_sync'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        // Settings
        register_rest_route('aukrug/v1', '/settings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_settings'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));

        register_rest_route('aukrug/v1', '/settings', array(
            'methods' => 'POST',
            'callback' => array($this, 'save_settings'),
            'permission_callback' => array($this, 'check_admin_permission')
        ));
    }

    public function check_admin_permission() {
        return current_user_can('manage_options');
    }

    public function get_kpis($request) {
        global $wpdb;

        // Get community stats
        $total_members = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->users} 
            WHERE user_registered >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
        ");

        $members_delta = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->users} 
            WHERE user_registered >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ") - $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->users} 
            WHERE user_registered BETWEEN DATE_SUB(NOW(), INTERVAL 60 DAY) AND DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");

        // Get geocache stats
        $active_caches = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE post_type = 'geocache' AND post_status = 'publish'
        ");

        $caches_delta = 0; // Placeholder for cache delta calculation

        // Get reports stats
        $total_reports = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE post_type = 'aukrug_report'
        ");

        $reports_delta = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE post_type = 'aukrug_report' AND post_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");

        // App downloads (mock data)
        $app_downloads = get_option('aukrug_app_downloads', 1247);
        $downloads_delta = get_option('aukrug_app_downloads_delta', 23);

        return rest_ensure_response(array(
            'total_members' => (int) $total_members,
            'members_delta' => (int) $members_delta,
            'active_caches' => (int) $active_caches,
            'caches_delta' => (int) $caches_delta,
            'total_reports' => (int) $total_reports,
            'reports_delta' => (int) $reports_delta,
            'app_downloads' => (int) $app_downloads,
            'downloads_delta' => (int) $downloads_delta
        ));
    }

    public function get_recent_activity($request) {
        global $wpdb;

        $activities = $wpdb->get_results("
            SELECT 
                p.post_title as title,
                p.post_date as created_at,
                p.post_type,
                CASE 
                    WHEN p.post_type = 'aukrug_report' THEN CONCAT('Neue Meldung: ', p.post_title)
                    WHEN p.post_type = 'geocache' THEN CONCAT('Geocache aktualisiert: ', p.post_title)
                    ELSE CONCAT('Aktivität: ', p.post_title)
                END as description
            FROM {$wpdb->posts} p
            WHERE p.post_type IN ('aukrug_report', 'geocache', 'post')
            AND p.post_status = 'publish'
            ORDER BY p.post_date DESC
            LIMIT 20
        ");

        return rest_ensure_response($activities ?: array());
    }

    public function get_community_members($request) {
        global $wpdb;

        $members = $wpdb->get_results("
            SELECT 
                u.ID as id,
                u.display_name,
                u.user_email as email,
                u.user_registered as registered,
                CASE 
                    WHEN u.user_status = 0 THEN 'active'
                    ELSE 'inactive'
                END as status
            FROM {$wpdb->users} u
            ORDER BY u.user_registered DESC
            LIMIT 100
        ");

        return rest_ensure_response($members ?: array());
    }

    public function get_community_posts($request) {
        $posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => 50,
            'orderby' => 'date',
            'order' => 'DESC'
        ));

        $formatted_posts = array_map(function($post) {
            return array(
                'id' => $post->ID,
                'title' => $post->post_title,
                'content' => wp_trim_words($post->post_content, 20),
                'author' => get_the_author_meta('display_name', $post->post_author),
                'date' => $post->post_date,
                'status' => $post->post_status
            );
        }, $posts);

        return rest_ensure_response($formatted_posts);
    }

    public function get_community_events($request) {
        // Mock event data
        $events = array(
            array(
                'id' => 1,
                'title' => 'Aukrug Stammtisch',
                'date' => date('Y-m-d H:i:s', strtotime('+1 week')),
                'location' => 'Gasthof zur Post, Aukrug',
                'attendees' => 15
            ),
            array(
                'id' => 2,
                'title' => 'Geocaching Tour',
                'date' => date('Y-m-d H:i:s', strtotime('+2 weeks')),
                'location' => 'Aukrug Wanderweg',
                'attendees' => 8
            )
        );

        return rest_ensure_response($events);
    }

    public function get_geocaching_caches($request) {
        global $wpdb;

        $caches = $wpdb->get_results("
            SELECT 
                p.ID as id,
                p.post_title as name,
                pm1.meta_value as gc_code,
                pm2.meta_value as type,
                pm3.meta_value as latitude,
                pm4.meta_value as longitude,
                p.post_status as status,
                pm5.meta_value as owner,
                p.post_modified as last_sync
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'gc_code'
            LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'cache_type'
            LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = 'latitude'
            LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = 'longitude'
            LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = 'cache_owner'
            WHERE p.post_type = 'geocache'
            ORDER BY p.post_date DESC
            LIMIT 100
        ");

        return rest_ensure_response($caches ?: array());
    }

    public function get_geocaching_stats($request) {
        global $wpdb;

        $stats = array(
            'total_caches' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'geocache'"),
            'active_caches' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'geocache' AND post_status = 'publish'"),
            'archived_caches' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'geocache' AND post_status = 'private'")
        );

        return rest_ensure_response($stats);
    }

    public function get_app_caches($request) {
        global $wpdb;

        $app_caches = $wpdb->get_results("
            SELECT 
                p.ID as id,
                p.post_title as name,
                pm1.meta_value as app_code,
                pm2.meta_value as difficulty,
                pm3.meta_value as terrain,
                pm4.meta_value as latitude,
                pm5.meta_value as longitude,
                p.post_status as status,
                p.post_date as created_at
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'app_code'
            LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'difficulty'
            LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = 'terrain'
            LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = 'latitude'
            LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = 'longitude'
            WHERE p.post_type = 'app_cache'
            ORDER BY p.post_date DESC
        ");

        return rest_ensure_response($app_caches ?: array());
    }

    public function get_reports($request) {
        global $wpdb;

        $reports = $wpdb->get_results("
            SELECT 
                p.ID as id,
                p.post_title as title,
                p.post_content as description,
                pm1.meta_value as category,
                pm2.meta_value as priority,
                p.post_status as status,
                p.post_date as created_at,
                p.post_author as user_id
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'report_category'
            LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'report_priority'
            WHERE p.post_type = 'aukrug_report'
            ORDER BY p.post_date DESC
            LIMIT 50
        ");

        return rest_ensure_response($reports ?: array());
    }

    public function get_reports_stats($request) {
        global $wpdb;

        $stats = array(
            'total_reports' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'aukrug_report'"),
            'open_reports' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'aukrug_report' AND post_status = 'publish'"),
            'urgent_reports' => $wpdb->get_var("
                SELECT COUNT(*) FROM {$wpdb->posts} p
                JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                WHERE p.post_type = 'aukrug_report' 
                AND pm.meta_key = 'report_priority' 
                AND pm.meta_value = 'urgent'
            ")
        );

        return rest_ensure_response($stats);
    }

    public function get_devices($request) {
        global $wpdb;

        // Mock device data
        $devices = array(
            array(
                'id' => 1,
                'device_name' => 'iPhone 15 Pro',
                'platform' => 'iOS',
                'app_version' => '1.2.3',
                'last_seen' => date('Y-m-d H:i:s', strtotime('-2 hours')),
                'is_active' => true
            ),
            array(
                'id' => 2,
                'device_name' => 'Samsung Galaxy S24',
                'platform' => 'Android',
                'app_version' => '1.2.1',
                'last_seen' => date('Y-m-d H:i:s', strtotime('-1 day')),
                'is_active' => false
            )
        );

        return rest_ensure_response($devices);
    }

    public function get_sync_status($request) {
        $status = array(
            'is_running' => get_option('aukrug_sync_running', false),
            'last_run' => get_option('aukrug_sync_last_run', date('Y-m-d H:i:s')),
            'next_run' => get_option('aukrug_sync_next_run', date('Y-m-d H:i:s', strtotime('+15 minutes'))),
            'total_synced' => get_option('aukrug_sync_total_synced', 156),
            'errors' => get_option('aukrug_sync_errors', 0)
        );

        return rest_ensure_response($status);
    }

    public function get_sync_logs($request) {
        $logs = get_option('aukrug_sync_logs', array(
            array(
                'timestamp' => date('Y-m-d H:i:s', strtotime('-1 hour')),
                'type' => 'info',
                'message' => 'Synchronisation erfolgreich abgeschlossen'
            ),
            array(
                'timestamp' => date('Y-m-d H:i:s', strtotime('-2 hours')),
                'type' => 'warning',
                'message' => 'Geocache GC123ABC nicht gefunden'
            )
        ));

        return rest_ensure_response($logs);
    }

    public function start_sync($request) {
        update_option('aukrug_sync_running', true);
        update_option('aukrug_sync_last_run', current_time('mysql'));
        
        // Trigger actual sync process here
        do_action('aukrug_start_sync');

        return rest_ensure_response(array('status' => 'started'));
    }

    public function stop_sync($request) {
        update_option('aukrug_sync_running', false);
        
        // Stop sync process here
        do_action('aukrug_stop_sync');

        return rest_ensure_response(array('status' => 'stopped'));
    }

    public function get_settings($request) {
        $settings = array(
            'api_endpoint' => get_option('aukrug_api_endpoint', ''),
            'api_key' => get_option('aukrug_api_key', ''),
            'auto_sync' => get_option('aukrug_auto_sync', true),
            'sync_interval' => get_option('aukrug_sync_interval', 15),
            'email_notifications' => get_option('aukrug_email_notifications', true),
            'push_notifications' => get_option('aukrug_push_notifications', false),
            'debug_mode' => get_option('aukrug_debug_mode', false),
            'cache_enabled' => get_option('aukrug_cache_enabled', true),
            'cache_ttl' => get_option('aukrug_cache_ttl', 300)
        );

        return rest_ensure_response($settings);
    }

    public function save_settings($request) {
        $params = $request->get_params();
        
        $settings_map = array(
            'api_endpoint' => 'aukrug_api_endpoint',
            'api_key' => 'aukrug_api_key',
            'auto_sync' => 'aukrug_auto_sync',
            'sync_interval' => 'aukrug_sync_interval',
            'email_notifications' => 'aukrug_email_notifications',
            'push_notifications' => 'aukrug_push_notifications',
            'debug_mode' => 'aukrug_debug_mode',
            'cache_enabled' => 'aukrug_cache_enabled',
            'cache_ttl' => 'aukrug_cache_ttl'
        );

        foreach ($settings_map as $param => $option) {
            if (isset($params[$param])) {
                update_option($option, $params[$param]);
            }
        }

        return rest_ensure_response(array('status' => 'saved'));
    }

    public function create_app_cache($request) {
        $params = $request->get_params();
        
        $post_data = array(
            'post_title' => sanitize_text_field($params['name']),
            'post_content' => sanitize_textarea_field($params['description']),
            'post_type' => 'app_cache',
            'post_status' => 'publish',
            'meta_input' => array(
                'app_code' => sanitize_text_field($params['app_code']),
                'difficulty' => floatval($params['difficulty']),
                'terrain' => floatval($params['terrain']),
                'latitude' => floatval($params['latitude']),
                'longitude' => floatval($params['longitude'])
            )
        );

        $post_id = wp_insert_post($post_data);

        if (is_wp_error($post_id)) {
            return new WP_Error('create_failed', 'Failed to create app cache', array('status' => 500));
        }

        return rest_ensure_response(array('id' => $post_id, 'status' => 'created'));
    }

    public function get_report($request) {
        $id = $request['id'];
        $post = get_post($id);
        
        if (!$post || $post->post_type !== 'aukrug_report') {
            return new WP_Error('not_found', 'Report not found', array('status' => 404));
        }

        $report = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'description' => $post->post_content,
            'category' => get_post_meta($post->ID, 'report_category', true),
            'priority' => get_post_meta($post->ID, 'report_priority', true),
            'status' => $post->post_status,
            'created_at' => $post->post_date,
            'user_id' => $post->post_author
        );

        return rest_ensure_response($report);
    }

    public function update_report($request) {
        $id = $request['id'];
        $params = $request->get_params();
        
        $post = get_post($id);
        if (!$post || $post->post_type !== 'aukrug_report') {
            return new WP_Error('not_found', 'Report not found', array('status' => 404));
        }

        $update_data = array('ID' => $id);
        
        if (isset($params['status'])) {
            $update_data['post_status'] = sanitize_text_field($params['status']);
        }
        
        if (isset($params['title'])) {
            $update_data['post_title'] = sanitize_text_field($params['title']);
        }

        wp_update_post($update_data);

        if (isset($params['category'])) {
            update_post_meta($id, 'report_category', sanitize_text_field($params['category']));
        }
        
        if (isset($params['priority'])) {
            update_post_meta($id, 'report_priority', sanitize_text_field($params['priority']));
        }

        return rest_ensure_response(array('status' => 'updated'));
    }
}

new Aukrug_Rest();
