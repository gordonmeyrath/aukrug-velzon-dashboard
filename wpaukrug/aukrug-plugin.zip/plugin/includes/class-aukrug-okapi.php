<?php
namespace Aukrug\Connect;

class Okapi
{
    public function init(): void {}
}
