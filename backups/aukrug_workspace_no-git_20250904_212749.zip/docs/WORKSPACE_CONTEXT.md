# Aukrug Workspace Context

## Vision

The Aukrug project provides a digital platform for the Aukrug municipality, serving both tourists and residents with location-based information, services, and community features.

## Core Concepts

### Target Audiences

**Tourists**
- Public access to places, routes, events
- No registration required for basic features
- Focus on discovery and navigation
- Multilingual support (DE/EN primary)

**Residents**
- Extended features requiring authentication
- Community reports and feedback
- Private notices and local services
- KITA/School specific information

### Technical Architecture

**Offline-First Design**
- Core functionality works without internet
- Delta synchronization for updates
- Local storage with Hive/Isar
- Progressive enhancement for online features

**Privacy by Design (DSGVO)**
- Minimal data collection
- No tracking of children under 16
- Clear consent flows
- Data export/deletion capabilities
- Audit logging for sensitive operations

### Data Categories

**Places**: POIs, businesses, public facilities
**Routes**: Walking/cycling paths, tour recommendations  
**Events**: Public events, festivals, meetings
**Notices**: Official announcements, alerts
**Downloads**: Documents, maps, guides
**Reports**: Community feedback, issue reporting

## Integration Points

- **WordPress REST API**: `/wp-json/aukrug/v1/*`
- **Delta Sync**: ETag/Last-Modified headers for efficient updates
- **JWT Authentication**: For resident-only features
- **Media Handling**: Optimized images, offline caching

## Compliance Notes

- GDPR/DSGVO compliant data handling
- No personal data of minors without explicit consent
- Regular data audits and cleanup procedures
- Privacy-first architecture design
