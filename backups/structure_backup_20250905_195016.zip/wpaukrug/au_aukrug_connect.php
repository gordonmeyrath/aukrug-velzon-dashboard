<?php
// Aukrug Connect – bootstrap (flattened at plugin root)
if (!defined('ABSPATH')) {
    if (PHP_SAPI !== 'cli' && PHP_SAPI !== 'phpdbg') { exit; }
}

// Core constants
defined('AUKRUG_CONNECT_VERSION') || define('AUKRUG_CONNECT_VERSION', '0.1.1');
defined('AUKRUG_CONNECT_FILE') || define('AUKRUG_CONNECT_FILE', __FILE__);
defined('AUKRUG_CONNECT_DIR') || define('AUKRUG_CONNECT_DIR', function_exists('plugin_dir_path') ? plugin_dir_path(__FILE__) : (__DIR__ . '/'));
defined('AUKRUG_CONNECT_URL') || define('AUKRUG_CONNECT_URL', function_exists('plugin_dir_url') ? plugin_dir_url(__FILE__) : '');

// Composer autoloader (prefer root/vendor; fallback to plugin/vendor during transition)
foreach ([AUKRUG_CONNECT_DIR . 'vendor/autoload.php', AUKRUG_CONNECT_DIR . 'plugin/vendor/autoload.php'] as $autoload) {
    if (file_exists($autoload)) { require_once $autoload; break; }
}

// Lightweight autoload for Aukrug\Connect namespace
spl_autoload_register(function ($class) {
    if (strpos($class, 'Aukrug\\Connect\\') !== 0) return;
    $map = [
        'Plugin' => 'class-aukrug-plugin.php',
        'Cpt' => 'class-aukrug-cpt.php',
        'Tax' => 'class-aukrug-tax.php',
        'Rest' => 'class-aukrug-rest.php',
        'Sync' => 'class-aukrug-sync.php',
        'Reports' => 'class-aukrug-reports.php',
        'Downloads' => 'class-aukrug-downloads.php',
        'Community' => 'class-aukrug-community.php',
        'Auth' => 'class-aukrug-auth.php',
        'Privacy' => 'class-aukrug-privacy.php',
        'Media' => 'class-aukrug-media.php',
        'Geo' => 'class-aukrug-geo.php',
        'Settings' => 'class-aukrug-settings.php',
        'Migrations' => 'class-aukrug-migrations.php',
        'Crypto\\E2EE' => 'crypto/class-aukrug-e2ee.php',
        'Notify\\Push' => 'notify/class-aukrug-push.php',
        'Notify\\PushAPNs' => 'notify/class-aukrug-push-apns.php',
        'Notify\\PushWebPush' => 'notify/class-aukrug-push-webpush.php',
    ];
    $short = substr($class, strlen('Aukrug\\Connect\\'));
    $rel = $map[$short] ?? null; if (!$rel) return;
    foreach ([AUKRUG_CONNECT_DIR . 'includes/' . $rel, AUKRUG_CONNECT_DIR . 'plugin/includes/' . $rel] as $candidate) {
        if (file_exists($candidate)) { require_once $candidate; return; }
    }
});

// Hooks
if (function_exists('register_activation_hook')) {
    register_activation_hook(__FILE__, function () {
        if (class_exists('Aukrug\\Connect\\Plugin')) { \Aukrug\Connect\Plugin::activate(); }
    });
}
if (function_exists('register_deactivation_hook')) {
    register_deactivation_hook(__FILE__, function () {
        if (class_exists('Aukrug\\Connect\\Plugin')) { \Aukrug\Connect\Plugin::deactivate(); }
    });
}
if (function_exists('add_action')) {
    add_action('plugins_loaded', function () {
        if (class_exists('Aukrug\\Connect\\Plugin')) { \Aukrug\Connect\Plugin::instance()->init(); }
    });
}
