<?php
/*
Plugin Name: wpaukrug
Plugin URI: https://aukrug.de
Description: Bootstrap for the Aukrug Connect plugin (loads the full implementation).
Version: 1.0.0
Author: MioWorkx
Author URI: https://mioworkx.de
Text Domain: wpaukrug
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Load the real plugin implementation from the same directory (flattened)
if (file_exists(__DIR__ . '/au_aukrug_connect.php')) {
    require_once __DIR__ . '/au_aukrug_connect.php';
}

// Optional: brief admin notice on first activation to confirm load worked
add_action('admin_notices', function () {
    if (!current_user_can('activate_plugins')) {
        return;
    }
    if (get_transient('wpaukrug_activated_notice')) {
        echo "<div class='notice notice-success is-dismissible'><p>Plugin 'wpaukrug' aktiviert und geladen.</p></div>";
        delete_transient('wpaukrug_activated_notice');
    }
});

register_activation_hook(__FILE__, function () {
    // Show a one-time notice after activation
    set_transient('wpaukrug_activated_notice', 1, 30);
});
