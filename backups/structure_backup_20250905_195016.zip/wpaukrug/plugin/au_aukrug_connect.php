<?php
/**
 * Aukrug Connect – internal bootstrap (loaded by wpaukrug/wpaukrug.php)
 * Note: No plugin header here to avoid being detected as a separate plugin.
 */

// Exit if accessed directly via web; allow CLI (e.g., PHPUnit) to include this file.
if (!defined('ABSPATH')) {
    if (PHP_SAPI !== 'cli' && PHP_SAPI !== 'phpdbg') {
        exit;
    }
}

// Define plugin constants (guarded for idempotency when loaded via wrapper).
if (!defined('AUKRUG_CONNECT_VERSION')) {
    define('AUKRUG_CONNECT_VERSION', '0.1.1');
}
if (!defined('AUKRUG_CONNECT_FILE')) {
    define('AUKRUG_CONNECT_FILE', __FILE__);
}
if (!defined('AUKRUG_CONNECT_DIR')) {
    define('AUKRUG_CONNECT_DIR', function_exists('plugin_dir_path') ? (string) \call_user_func('plugin_dir_path', __FILE__) : (__DIR__ . '/'));
}
if (!defined('AUKRUG_CONNECT_URL')) {
    // Point directly to this /plugin/ directory for assets
    if (function_exists('plugin_dir_url')) {
        define('AUKRUG_CONNECT_URL', (string) \call_user_func('plugin_dir_url', __FILE__));
    } else {
        define('AUKRUG_CONNECT_URL', '');
    }
}

// Load Composer autoloader if present.
$autoload = AUKRUG_CONNECT_DIR . 'vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
}

// Fallback autoload: map core classes to their files if Composer isn't installed yet.
spl_autoload_register(function ($class) {
    if (strpos($class, 'Aukrug\\Connect\\') !== 0) {
        return;
    }
    $short = substr($class, strlen('Aukrug\\Connect\\'));
    $map = [
        'Plugin' => 'class-aukrug-plugin.php',
    'Activator' => 'class-aukrug-activator.php',
    'Deactivator' => 'class-aukrug-deactivator.php',
    'Admin' => 'class-aukrug-admin.php',
        'Cpt' => 'class-aukrug-cpt.php',
        'Tax' => 'class-aukrug-tax.php',
        'Rest' => 'class-aukrug-rest.php',
        'Sync' => 'class-aukrug-sync.php',
        'Reports' => 'class-aukrug-reports.php',
        'Downloads' => 'class-aukrug-downloads.php',
    'Okapi' => 'class-aukrug-okapi.php',
    'Appcaches' => 'class-aukrug-appcaches.php',
    'IcsImport' => 'class-aukrug-ics-import.php',
        'Community' => 'class-aukrug-community.php',
        'Auth' => 'class-aukrug-auth.php',
        'Privacy' => 'class-aukrug-privacy.php',
        'Media' => 'class-aukrug-media.php',
        'Geo' => 'class-aukrug-geo.php',
        'Settings' => 'class-aukrug-settings.php',
        'Migrations' => 'class-aukrug-migrations.php',
        'Crypto\\E2EE' => 'crypto/class-aukrug-e2ee.php',
        'Notify\\Push' => 'notify/class-aukrug-push.php',
    'Notify\\PushAPNs' => 'notify/class-aukrug-push-apns.php',
    'Notify\\PushWebPush' => 'notify/class-aukrug-push-webpush.php',
    'Nfc\\NfcJourney' => 'nfc/class-aukrug-nfc-journey.php',
    ];
    $file = $map[$short] ?? null;
    if ($file) {
        $path = AUKRUG_CONNECT_DIR . 'includes/' . $file;
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

// Activation/Deactivation hooks.
if (function_exists('register_activation_hook')) {
    \call_user_func('register_activation_hook', __FILE__, function () {
        if (class_exists('Aukrug\\Connect\\Plugin')) {
            \Aukrug\Connect\Plugin::activate();
        }
    });
}

if (function_exists('register_deactivation_hook')) {
    \call_user_func('register_deactivation_hook', __FILE__, function () {
        if (class_exists('Aukrug\\Connect\\Plugin')) {
            \Aukrug\Connect\Plugin::deactivate();
        }
    });
}

// Bootstrap the plugin.
if (function_exists('add_action')) {
    \call_user_func('add_action', 'plugins_loaded', function () {
        if (class_exists('Aukrug\\Connect\\Plugin')) {
            \Aukrug\Connect\Plugin::instance()->init();
        }
    });
}
