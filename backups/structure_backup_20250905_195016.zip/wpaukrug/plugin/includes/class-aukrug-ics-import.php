<?php
namespace Aukrug\Connect;

class IcsImport
{
    public function init(): void {}
}
