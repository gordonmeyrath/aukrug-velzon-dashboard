<?php
namespace Aukrug\Connect\Nfc;

/**
 * Hidden groundwork for future NFC SchnitzelJagd feature.
 */
class NfcJourney
{
    /** Feature flag (off by default). */
    private bool $enabled = false;

    public function isEnabled(): bool { return $this->enabled; }
}
