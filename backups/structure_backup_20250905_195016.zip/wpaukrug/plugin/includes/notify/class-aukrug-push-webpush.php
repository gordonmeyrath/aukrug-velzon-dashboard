<?php
namespace Aukrug\Connect\Notify;

class PushWebPush
{
    public function send(array $tokens, array $notification, array $data = []): array
    {
        // Expect $tokens to be an array of subscriptions:
        // [ [ 'endpoint' => '...', 'p256dh' => '...', 'auth' => '...' ], ... ]
        if (!$tokens) { return ['ok' => false, 'sent' => 0, 'reason' => 'no_tokens']; }
        $pub = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_vapid_public', '') : '';
        $priv = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_vapid_private', '') : '';
        $subj = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_vapid_subject', 'mailto:admin@example.com') : 'mailto:admin@example.com';
        if (!$pub || !$priv) {
            return ['ok' => false, 'sent' => 0, 'reason' => 'vapid_not_configured'];
        }

        // Message payload (E2EE should be client-side; server just relays envelope)
        $payload = [ 'notification' => $notification, 'data' => $data ];
        $body = (\function_exists('wp_json_encode') ? \call_user_func('wp_json_encode', $payload) : json_encode($payload));

        // Prefer Minishlink/web-push if available (proper encryption + headers)
        $wpClass = '\\Minishlink\\WebPush\\WebPush';
        $subClass = '\\Minishlink\\WebPush\\Subscription';
        if (class_exists($wpClass) && class_exists($subClass)) {
            $auth = [ 'VAPID' => [ 'subject' => $subj, 'publicKey' => $pub, 'privateKey' => $priv ] ];
            $webPush = new $wpClass($auth);
            $sent = 0; $okOverall = true;
            foreach ($tokens as $sub) {
                $endpoint = (string) ($sub['endpoint'] ?? '');
                $p256dh = (string) ($sub['p256dh'] ?? '');
                $authT = (string) ($sub['auth'] ?? '');
                if (!$endpoint || !$p256dh || !$authT) { $okOverall = false; continue; }
                // Modern API expects keys => [p256dh, auth]
                $subscription = \call_user_func([$subClass, 'create'], [
                    'endpoint' => $endpoint,
                    'keys' => [ 'p256dh' => $p256dh, 'auth' => $authT ],
                ]);
                try {
                    // Prefer sendOneNotification when available (v7+), fallback to older sendNotification
                    if (method_exists($webPush, 'sendOneNotification')) {
                        $report = $webPush->sendOneNotification($subscription, $body);
                    } else {
                        $report = $webPush->sendNotification($subscription, $body);
                    }
                    $ok = is_object($report) && method_exists($report, 'isSuccess') ? $report->isSuccess() : true;
                } catch (\Throwable $e) { $ok = false; }
                if ($ok) { $sent++; } else { $okOverall = false; }
            }
            return ['ok' => $okOverall && $sent > 0, 'sent' => $sent];
        }

        // Fallback: no encryption, JWT header attempt (not standard-compliant)
        // Disabled by default; can be enabled for local testing via 'au_webpush_allow_unencrypted' filter.
        $allowFallback = \function_exists('apply_filters') ? (bool) \call_user_func('apply_filters', 'au_webpush_allow_unencrypted', false) : false;
        if (!$allowFallback) {
            return ['ok' => false, 'sent' => 0, 'reason' => 'webpush_library_missing'];
        }
        $jwt = $this->buildVapidJWT($pub, $priv, $subj);
        if (!$jwt) { return ['ok' => false, 'sent' => 0, 'reason' => 'vapid_jwt_error']; }
        $sent = 0; $okOverall = true;
        foreach ($tokens as $sub) {
            $endpoint = (string) ($sub['endpoint'] ?? '');
            if (!$endpoint) { $okOverall = false; continue; }
            $args = [
                'headers' => [
                    'Authorization' => 'WebPush ' . $jwt,
                    'Content-Type' => 'application/json',
                ],
                'timeout' => 15,
                'body' => $body,
            ];
            $resp = \function_exists('wp_remote_post') ? \call_user_func('wp_remote_post', (string)$endpoint, $args) : null;
            $ok = is_array($resp) && isset($resp['response']['code']) && ((int)$resp['response']['code'] >= 200) && ((int)$resp['response']['code'] < 300);
            if ($ok) { $sent++; } else { $okOverall = false; }
        }
        return ['ok' => $okOverall && $sent > 0, 'sent' => $sent];
    }

    private function buildVapidJWT(string $publicKeyB64Url, string $privateKeyB64Url, string $subject): ?string
    {
        // VAPID JWT signed with EC P-256 (ES256). For simplicity, expect keys in Base64URL.
        $aud = 'https://fcm.googleapis.com'; // common default; actual audience should match push service
        $iat = time();
        $exp = $iat + 3600;
        $header = ['alg' => 'ES256', 'typ' => 'JWT'];
        $claims = ['aud' => $aud, 'exp' => $exp, 'iat' => $iat, 'sub' => $subject];
        $b64 = fn($v) => rtrim(strtr(base64_encode(is_string($v) ? $v : json_encode($v)), '+/', '-_'), '=');
        $segments = [$b64(json_encode($header)), $b64(json_encode($claims))];
        $input = implode('.', $segments);
        $privRaw = $this->b64url_decode($privateKeyB64Url);
        if (!$privRaw) { return null; }
        $pem = $this->ecPrivateKeyToPem($privRaw);
        if (!$pem) { return null; }
        $pkey = @openssl_pkey_get_private($pem);
        if (!$pkey) { return null; }
        $sig = '';
        $ok = @openssl_sign($input, $sig, $pkey, OPENSSL_ALGO_SHA256);
        @openssl_free_key($pkey);
        if (!$ok) { return null; }
        $segments[] = $b64($sig);
        return implode('.', $segments);
    }

    private function b64url_decode(string $s): string|false
    {
        $p = strtr($s, '-_', '+/');
        $pad = strlen($p) % 4; if ($pad) { $p .= str_repeat('=', 4 - $pad); }
        return base64_decode($p, true);
    }

    private function ecPrivateKeyToPem(string $raw): ?string
    {
        // Wrap raw 32-byte key into PKCS8 for OpenSSL
        if (strlen($raw) !== 32) { return null; }
        // Minimal ASN.1 for EC private key on prime256v1
        $tmpl = base64_decode('MIGkAgEBBDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoIGWMIGTAgEBMCQwEAYHKoZIzj0CAQYFK4EEACMDgYYABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA');
        if (!$tmpl) { return null; }
    // Replace 32 zero bytes at position 7 with $raw (heuristic placeholder template)
        $pemDer = substr($tmpl, 0, 7) . $raw . substr($tmpl, 39);
        $pem = "-----BEGIN PRIVATE KEY-----\n" . chunk_split(base64_encode($pemDer), 64, "\n") . "-----END PRIVATE KEY-----\n";
        return $pem;
    }
}
