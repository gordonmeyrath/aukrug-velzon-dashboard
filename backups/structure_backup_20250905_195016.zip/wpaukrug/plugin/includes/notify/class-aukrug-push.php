<?php
namespace Aukrug\Connect\Notify;

class Push
{
	public function init(): void {}

	/**
	 * Send payload to tokens using FCM when available.
	 * @param array $tokens list of device tokens
	 * @param array $notification ['title'=>..., 'body'=>...]
	 * @param array $data additional key-value data (must be strings)
	 * @return array result summary
	 */
	public function send(array $tokens, array $notification, array $data = []): array
	{
		$provider = (\function_exists('get_option') ? (string) \call_user_func('get_option', 'au_push_provider', 'fcm') : 'fcm');
		$provider = in_array(strtolower($provider), ['fcm','apns','webpush'], true) ? strtolower($provider) : 'fcm';
		if ($provider === 'fcm') {
			return $this->sendFCM($tokens, $notification, $data);
		}
		if ($provider === 'apns') {
			$apns = new \Aukrug\Connect\Notify\PushAPNs();
			return $apns->send($tokens, $notification, $data);
		}
		if ($provider === 'webpush') {
			$wp = new \Aukrug\Connect\Notify\PushWebPush();
			return $wp->send($tokens, $notification, $data);
		}
		return ['sent' => 0, 'ok' => false, 'reason' => 'unknown_provider'];
	}

	/**
	 * Send payload to tokens using FCM when available.
	 * @param array $tokens list of device tokens
	 * @param array $notification ['title'=>..., 'body'=>...]
	 * @param array $data additional key-value data (must be strings)
	 * @return array result summary
	 */
	public function sendFCM(array $tokens, array $notification, array $data = []): array
	{
		if (!$tokens) { return ['sent' => 0, 'ok' => false, 'reason' => 'no_tokens']; }
		$serverKey = (\function_exists('get_option') ? (string) \call_user_func('get_option', 'au_fcm_server_key', '') : '');
		if (!$serverKey || !\function_exists('wp_remote_post')) {
			return ['sent' => 0, 'ok' => false, 'reason' => 'fcm_not_configured'];
		}
		$payload = [
			'registration_ids' => array_values(array_unique($tokens)),
			'notification' => $notification,
			'data' => $data,
		];
		$args = [
			'headers' => [
				'Authorization' => 'key=' . $serverKey,
				'Content-Type' => 'application/json',
			],
			'timeout' => 15,
			'body' => (\function_exists('wp_json_encode') ? \call_user_func('wp_json_encode', $payload) : json_encode($payload)),
		];
		$response = \call_user_func('wp_remote_post', 'https://fcm.googleapis.com/fcm/send', $args);
		$ok = is_array($response) && isset($response['response']['code']) && (int) $response['response']['code'] === 200;
		return ['ok' => $ok, 'sent' => $ok ? count($tokens) : 0];
	}
}
