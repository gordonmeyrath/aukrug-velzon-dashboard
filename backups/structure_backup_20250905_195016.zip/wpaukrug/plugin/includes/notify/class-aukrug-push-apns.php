<?php
namespace Aukrug\Connect\Notify;

class PushAPNs
{
    public function send(array $tokens, array $notification, array $data = []): array
    {
        // Minimal APNs HTTP/2 JWT flow using WordPress HTTP API.
        // Requirements: Team ID, Key ID, Topic (bundle id), .p8 content in settings.
        if (!$tokens) { return ['ok' => false, 'sent' => 0, 'reason' => 'no_tokens']; }
        $teamId = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_apns_team_id', '') : '';
        $keyId = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_apns_key_id', '') : '';
        $topic = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_apns_topic', '') : '';
        $p8 = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_apns_p8', '') : '';
        $sandbox = \function_exists('get_option') ? (int) \call_user_func('get_option', 'au_apns_sandbox', 1) : 1;
        if (!$teamId || !$keyId || !$topic || !$p8) {
            return ['ok' => false, 'sent' => 0, 'reason' => 'apns_not_configured'];
        }

        $aud = 'https://appleid.apple.com';
        $now = time();
        $header = ['alg' => 'ES256', 'kid' => $keyId, 'typ' => 'JWT'];
        $claims = ['iss' => $teamId, 'iat' => $now, 'aud' => $aud];
        $jwt = $this->jwtES256($header, $claims, $p8);
        if (!$jwt) { return ['ok' => false, 'sent' => 0, 'reason' => 'apns_jwt_error']; }

        $apnsHost = $sandbox ? 'https://api.sandbox.push.apple.com' : 'https://api.push.apple.com';
        $pathBase = $apnsHost . '/3/device/';

        $sent = 0; $okOverall = true;
        foreach ($tokens as $token) {
            $payload = [ 'aps' => [] ];
            if (!empty($notification['title']) || !empty($notification['body'])) {
                $payload['aps']['alert'] = [
                    'title' => $notification['title'] ?? null,
                    'body' => $notification['body'] ?? null,
                ];
            }
            if (!empty($data)) { $payload['data'] = $data; }
            $args = [
                'headers' => [
                    'authorization' => 'bearer ' . $jwt,
                    'apns-topic' => $topic,
                    // Optionally priority, expiration, collapse-id etc.
                ],
                'httpversion' => '2.0',
                'timeout' => 15,
                'body' => (\function_exists('wp_json_encode') ? \call_user_func('wp_json_encode', $payload) : json_encode($payload)),
            ];
            $resp = \function_exists('wp_remote_post') ? \call_user_func('wp_remote_post', $pathBase . $token, $args) : null;
            $ok = is_array($resp) && isset($resp['response']['code']) && ((int)$resp['response']['code'] === 200);
            if ($ok) { $sent++; } else { $okOverall = false; }
        }
        return ['ok' => $okOverall && $sent > 0, 'sent' => $sent];
    }

    private function jwtES256(array $header, array $claims, string $p8): ?string
    {
        $b64 = fn($v) => rtrim(strtr(base64_encode(is_string($v) ? $v : json_encode($v)), '+/', '-_'), '=');
        $segments = [$b64(json_encode($header)), $b64(json_encode($claims))];
        $signingInput = implode('.', $segments);
        // Load private key
        $pkey = @openssl_pkey_get_private($p8);
        if (!$pkey) { return null; }
        $signature = '';
        $ok = @openssl_sign($signingInput, $signature, $pkey, OPENSSL_ALGO_SHA256);
        @openssl_free_key($pkey);
        if (!$ok) { return null; }
        $segments[] = $b64($signature);
        return implode('.', $segments);
    }
}
