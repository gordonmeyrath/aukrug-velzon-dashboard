<?php
namespace Aukrug\Connect;

class Geo { public function init(): void {} }
