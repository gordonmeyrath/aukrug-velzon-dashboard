<?php
namespace Aukrug\Connect;

class Media { public function init(): void {} }
