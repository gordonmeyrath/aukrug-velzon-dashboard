<?php
namespace Aukrug\Connect;

class Community { public function init(): void {} }
