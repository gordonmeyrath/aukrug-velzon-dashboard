<?php
namespace Aukrug\Connect;

class Settings
{
	public function init(): void
	{
		if (\function_exists('add_action')) {
			\add_action('admin_init', [$this, 'registerSettings']);
			\add_action('admin_menu', [$this, 'addMenu']);
			\add_action('admin_notices', [$this, 'maybeShowProviderNotices']);
			// Enqueue our modern admin app and register admin REST routes
			\add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
			\add_action('rest_api_init', [$this, 'registerAdminRoutes']);
		}
	}

	public function registerSettings(): void
	{
		if (\function_exists('register_setting')) {
			\call_user_func('register_setting', 'aukrug_connect', 'au_fcm_server_key', [
				'type' => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'show_in_rest' => false,
			]);
			\call_user_func('register_setting', 'aukrug_connect', 'au_rate_limit_count', [
				'type' => 'integer',
				'sanitize_callback' => 'absint',
				'show_in_rest' => false,
			]);
			\call_user_func('register_setting', 'aukrug_connect', 'au_rate_limit_window', [
				'type' => 'integer',
				'sanitize_callback' => 'absint',
				'show_in_rest' => false,
			]);
			// Push provider selection (fcm, apns, webpush)
			\call_user_func('register_setting', 'aukrug_connect', 'au_push_provider', [
				'type' => 'string',
				'sanitize_callback' => function ($v) { $v = is_string($v) ? strtolower($v) : 'fcm'; return in_array($v, ['fcm','apns','webpush'], true) ? $v : 'fcm'; },
				'show_in_rest' => false,
			]);
			// APNs settings
			\call_user_func('register_setting', 'aukrug_connect', 'au_apns_team_id', [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'show_in_rest' => false ]);
			\call_user_func('register_setting', 'aukrug_connect', 'au_apns_key_id', [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'show_in_rest' => false ]);
			\call_user_func('register_setting', 'aukrug_connect', 'au_apns_topic', [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'show_in_rest' => false ]);
			\call_user_func('register_setting', 'aukrug_connect', 'au_apns_p8', [ 'type' => 'string', 'show_in_rest' => false ]);
			\call_user_func('register_setting', 'aukrug_connect', 'au_apns_sandbox', [ 'type' => 'boolean', 'sanitize_callback' => function($v){ return (int)!empty($v); }, 'show_in_rest' => false ]);

			// Web Push (VAPID) settings
			\call_user_func('register_setting', 'aukrug_connect', 'au_vapid_public', [ 'type' => 'string', 'show_in_rest' => false ]);
			\call_user_func('register_setting', 'aukrug_connect', 'au_vapid_private', [ 'type' => 'string', 'show_in_rest' => false ]);
			\call_user_func('register_setting', 'aukrug_connect', 'au_vapid_subject', [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'show_in_rest' => false ]);

			// Privacy/media settings
			\call_user_func('register_setting', 'aukrug_connect', 'au_strip_exif', [
				'type' => 'boolean',
				'sanitize_callback' => function($v){ return (int)!empty($v); },
				'show_in_rest' => false,
			]);
		}

		$sectionTitle = \function_exists('__') ? (string) \call_user_func('__', 'Push Settings', 'aukrug-connect') : 'Push Settings';
		if (\function_exists('add_settings_section')) {
			\call_user_func('add_settings_section', 'au_push', $sectionTitle, function () {
				$desc = \function_exists('esc_html__') ? (string) \call_user_func('esc_html__', 'Configure push delivery and rate limits.', 'aukrug-connect') : 'Configure push delivery and rate limits.';
				echo '<p>' . htmlspecialchars($desc, ENT_QUOTES) . '</p>';
			}, 'aukrug_connect');
		}

		$labelKey = \function_exists('__') ? (string) \call_user_func('__', 'FCM Server Key', 'aukrug-connect') : 'FCM Server Key';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_fcm_server_key', $labelKey, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_fcm_server_key', '') : '';
				$valAttr = htmlspecialchars($val, ENT_QUOTES);
				echo '<input type="text" class="regular-text" name="au_fcm_server_key" value="' . $valAttr . '" />';
			}, 'aukrug_connect', 'au_push');
		}

		$labelCount = \function_exists('__') ? (string) \call_user_func('__', 'Rate Limit Count', 'aukrug-connect') : 'Rate Limit Count';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_rate_limit_count', $labelCount, function () {
				$val = \function_exists('get_option') ? (int) \call_user_func('get_option', 'au_rate_limit_count', 60) : 60;
				echo '<input type="number" min="1" name="au_rate_limit_count" value="' . $val . '" />';
			}, 'aukrug_connect', 'au_push');
		}

		$labelWindow = \function_exists('__') ? (string) \call_user_func('__', 'Rate Limit Window (seconds)', 'aukrug-connect') : 'Rate Limit Window (seconds)';
		$labelProvider = \function_exists('__') ? (string) \call_user_func('__', 'Push Provider', 'aukrug-connect') : 'Push Provider';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_push_provider', $labelProvider, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_push_provider', 'fcm') : 'fcm';
				$val = in_array($val, ['fcm','apns','webpush'], true) ? $val : 'fcm';
				echo '<select name="au_push_provider">';
				foreach ([
					'fcm' => 'FCM (Firebase Cloud Messaging)',
					'apns' => 'APNs (Apple Push)',
					'webpush' => 'Web Push (VAPID) – requires browser subscriptions',
				] as $k => $label) {
					$sel = $val === $k ? ' selected' : '';
					echo '<option value="' . htmlspecialchars($k, ENT_QUOTES) . '"' . $sel . '>' . htmlspecialchars($label, ENT_QUOTES) . '</option>';
				}
				echo '</select>';
			}, 'aukrug_connect', 'au_push');
		}
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_rate_limit_window', $labelWindow, function () {
				$val = \function_exists('get_option') ? (int) \call_user_func('get_option', 'au_rate_limit_window', 300) : 300;
				echo '<input type="number" min="60" step="60" name="au_rate_limit_window" value="' . $val . '" />';
			}, 'aukrug_connect', 'au_push');
		}

		// APNs fields
		$labelApnsTeam = \function_exists('__') ? (string) \call_user_func('__', 'APNs Team ID', 'aukrug-connect') : 'APNs Team ID';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_apns_team_id', $labelApnsTeam, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_apns_team_id', '') : '';
				echo '<input type="text" name="au_apns_team_id" value="' . htmlspecialchars($val, ENT_QUOTES) . '" />';
			}, 'aukrug_connect', 'au_push');
		}

		$labelApnsKey = \function_exists('__') ? (string) \call_user_func('__', 'APNs Key ID', 'aukrug-connect') : 'APNs Key ID';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_apns_key_id', $labelApnsKey, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_apns_key_id', '') : '';
				echo '<input type="text" name="au_apns_key_id" value="' . htmlspecialchars($val, ENT_QUOTES) . '" />';
			}, 'aukrug_connect', 'au_push');
		}

		$labelApnsTopic = \function_exists('__') ? (string) \call_user_func('__', 'APNs Topic (Bundle ID)', 'aukrug-connect') : 'APNs Topic (Bundle ID)';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_apns_topic', $labelApnsTopic, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_apns_topic', '') : '';
				echo '<input type="text" class="regular-text" name="au_apns_topic" value="' . htmlspecialchars($val, ENT_QUOTES) . '" />';
			}, 'aukrug_connect', 'au_push');
		}

		$labelApnsP8 = \function_exists('__') ? (string) \call_user_func('__', 'APNs .p8 Private Key', 'aukrug-connect') : 'APNs .p8 Private Key';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_apns_p8', $labelApnsP8, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_apns_p8', '') : '';
				echo '<textarea name="au_apns_p8" rows="6" cols="60" placeholder="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n">' . htmlspecialchars($val, ENT_QUOTES) . '</textarea>';
			}, 'aukrug_connect', 'au_push');
		}

		$labelApnsSandbox = \function_exists('__') ? (string) \call_user_func('__', 'APNs Sandbox (Development)', 'aukrug-connect') : 'APNs Sandbox (Development)';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_apns_sandbox', $labelApnsSandbox, function () {
				$val = \function_exists('get_option') ? (int) \call_user_func('get_option', 'au_apns_sandbox', 1) : 1;
				$checked = $val ? ' checked' : '';
				echo '<label><input type="checkbox" name="au_apns_sandbox" value="1"' . $checked . ' /> ' . htmlspecialchars('Use api.sandbox.push.apple.com', ENT_QUOTES) . '</label>';
			}, 'aukrug_connect', 'au_push');
		}

		// Web Push (VAPID) fields
		$labelVapidPub = \function_exists('__') ? (string) \call_user_func('__', 'VAPID Public Key (Base64URL)', 'aukrug-connect') : 'VAPID Public Key (Base64URL)';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_vapid_public', $labelVapidPub, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_vapid_public', '') : '';
				echo '<input type="text" class="regular-text" name="au_vapid_public" value="' . htmlspecialchars($val, ENT_QUOTES) . '" />';
			}, 'aukrug_connect', 'au_push');
		}
		$labelVapidPriv = \function_exists('__') ? (string) \call_user_func('__', 'VAPID Private Key (Base64URL)', 'aukrug-connect') : 'VAPID Private Key (Base64URL)';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_vapid_private', $labelVapidPriv, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_vapid_private', '') : '';
				echo '<input type="text" class="regular-text" name="au_vapid_private" value="' . htmlspecialchars($val, ENT_QUOTES) . '" />';
			}, 'aukrug_connect', 'au_push');
		}
		$labelVapidSubj = \function_exists('__') ? (string) \call_user_func('__', 'VAPID Subject (mailto:… or URL)', 'aukrug-connect') : 'VAPID Subject (mailto:… or URL)';
		if (\function_exists('add_settings_field')) {
			\call_user_func('add_settings_field', 'au_vapid_subject', $labelVapidSubj, function () {
				$val = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_vapid_subject', 'mailto:admin@example.com') : 'mailto:admin@example.com';
				echo '<input type="text" class="regular-text" name="au_vapid_subject" value="' . htmlspecialchars($val, ENT_QUOTES) . '" />';
			}, 'aukrug_connect', 'au_push');
		}
	}

	public function addMenu(): void
	{
		$title = \function_exists('__') ? (string) \call_user_func('__', 'Aukrug Connect', 'aukrug-connect') : 'Aukrug Connect';
		// Register as a top-level menu (main sidebar), not under Settings
		if (\function_exists('add_menu_page')) {
			\call_user_func('add_menu_page', $title, 'Aukrug', 'manage_options', 'aukrug_connect', [$this, 'renderPage'], 'dashicons-admin-site-alt3', 58);
		}
	}

	public function renderPage(): void
	{
		$can = \function_exists('current_user_can') ? (bool) \call_user_func('current_user_can', 'manage_options') : true;
		if (!$can) { return; }
		$title = \function_exists('esc_html__') ? (string) \call_user_func('esc_html__', 'Aukrug Connect', 'aukrug-connect') : 'Aukrug Connect';
		echo '<div class="wrap"><h1>' . htmlspecialchars($title, ENT_QUOTES) . '</h1>';
		// Modern Material UI app root
		echo '<div id="au-admin-app" class="au-admin-app" data-screen="toplevel_page_aukrug_connect"></div>';
		// Accessible fallback: collapsible classic WP settings form
		echo '<details style="margin-top:16px"><summary>Classic settings (fallback)</summary>';
		echo '<form method="post" action="options.php" style="margin-top:12px">';
		if (\function_exists('settings_fields')) { \call_user_func('settings_fields', 'aukrug_connect'); }
		if (\function_exists('do_settings_sections')) { \call_user_func('do_settings_sections', 'aukrug_connect'); }
		if (\function_exists('submit_button')) { \call_user_func('submit_button'); }
		echo '</form></details></div>';
	}

	public function maybeShowProviderNotices(): void
	{
		// Only on settings pages for admins
		if (!\function_exists('get_current_screen') || !\function_exists('current_user_can')) { return; }
		if (!\call_user_func('current_user_can', 'manage_options')) { return; }
		$screen = \call_user_func('get_current_screen');
		if (!$screen || empty($screen->id)) { return; }
		$screenId = (string) $screen->id;
		if ($screenId !== 'toplevel_page_aukrug_connect' && $screenId !== 'settings_page_aukrug_connect') { return; }
		$provider = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_push_provider', 'fcm') : 'fcm';
		$provider = strtolower($provider);
		if ($provider === 'apns') {
			$teamId = (string) (\function_exists('get_option') ? \call_user_func('get_option', 'au_apns_team_id', '') : '');
			$keyId  = (string) (\function_exists('get_option') ? \call_user_func('get_option', 'au_apns_key_id', '') : '');
			$topic  = (string) (\function_exists('get_option') ? \call_user_func('get_option', 'au_apns_topic', '') : '');
			$p8     = (string) (\function_exists('get_option') ? \call_user_func('get_option', 'au_apns_p8', '') : '');
			if (!$teamId || !$keyId || !$topic || !$p8) {
				$this->notice('warning', 'APNs is selected but configuration is incomplete. Please set Team ID, Key ID, Topic and .p8 in the Push Settings section.');
			}
		}
		if ($provider === 'webpush') {
			$pub = (string) (\function_exists('get_option') ? \call_user_func('get_option', 'au_vapid_public', '') : '');
			$priv = (string) (\function_exists('get_option') ? \call_user_func('get_option', 'au_vapid_private', '') : '');
			if (!$pub || !$priv) {
				$this->notice('warning', 'Web Push is selected but VAPID keys are missing. Generate and save VAPID public/private keys and subject.');
			}
		}
		if ($provider === 'fcm') {
			$key = (string) (\function_exists('get_option') ? \call_user_func('get_option', 'au_fcm_server_key', '') : '');
			if (!$key) { $this->notice('info', 'FCM is selected. Add your FCM server key to enable push delivery.'); }
		}
	}

	private function notice(string $type, string $message): void
	{
		echo '<div class="notice notice-' . htmlspecialchars($type, ENT_QUOTES) . '"><p>' . htmlspecialchars($message, ENT_QUOTES) . '</p></div>';
	}

	public function enqueueAssets($hook): void
	{
		// Only on our settings page
		if (!\function_exists('get_current_screen') || !\function_exists('wp_enqueue_script')) { return; }
		$screen = \call_user_func('get_current_screen');
		$screenId = $screen && !empty($screen->id) ? (string) $screen->id : '';
		// Accept both the new top-level screen and the legacy Settings screen during transition
		if ($screenId !== 'toplevel_page_aukrug_connect' && $screenId !== 'settings_page_aukrug_connect') { return; }
		$baseUrl = \defined('AUKRUG_CONNECT_URL') ? \constant('AUKRUG_CONNECT_URL') : '';
		$baseDir = \defined('AUKRUG_CONNECT_DIR') ? \constant('AUKRUG_CONNECT_DIR') : (__DIR__ . '/../../');
		// Support flattened structure: prefer /assets at plugin root, fallback to /plugin/assets
		$assetsRel = is_file($baseDir . 'assets/js/admin-app.js') ? 'assets/' : 'plugin/assets/';
		$cssPath = $baseDir . $assetsRel . 'css/admin-app.css';
		$jsPath = $baseDir . $assetsRel . 'js/admin-app.js';
		$cssVer = is_file($cssPath) ? (string) @filemtime($cssPath) : (\defined('AUKRUG_CONNECT_VERSION') ? \constant('AUKRUG_CONNECT_VERSION') : '0.1.0');
		$jsVer = is_file($jsPath) ? (string) @filemtime($jsPath) : (\defined('AUKRUG_CONNECT_VERSION') ? \constant('AUKRUG_CONNECT_VERSION') : '0.1.0');
		if (\function_exists('wp_enqueue_style')) { \call_user_func('wp_enqueue_style', 'au-admin-app', $baseUrl . $assetsRel . 'css/admin-app.css', [], $cssVer); }
		// Ensure wp-api-fetch is available for REST
		if (\function_exists('wp_enqueue_script')) { \call_user_func('wp_enqueue_script', 'wp-api-fetch'); }
		if (\function_exists('wp_enqueue_script')) { \call_user_func('wp_enqueue_script', 'au-admin-app', $baseUrl . $assetsRel . 'js/admin-app.js', ['wp-api-fetch'], $jsVer, true); }
		// Pass REST data + nonce
		if (\function_exists('wp_create_nonce') && \function_exists('wp_localize_script')) {
			$data = [
				'root' => \function_exists('rest_url') ? (string) \call_user_func('rest_url', 'aukrug-connect/v1/') : '/wp-json/aukrug-connect/v1/',
				'nonce' => (string) \call_user_func('wp_create_nonce', 'wp_rest'),
				'userId' => \function_exists('get_current_user_id') ? (int) \call_user_func('get_current_user_id') : 0,
			];
			\call_user_func('wp_localize_script', 'au-admin-app', 'AU_ADMIN', $data);
		}
	}

	public function registerAdminRoutes(): void
	{
		$ns = 'aukrug-connect/v1';
		if (\function_exists('register_rest_route')) {
			// Admin settings: GET
			\call_user_func('register_rest_route', $ns, '/admin/settings', [
				'methods' => 'GET',
				'permission_callback' => function () { return \function_exists('current_user_can') ? (bool) \call_user_func('current_user_can', 'manage_options') : false; },
				'callback' => function () {
					$opt = fn($k, $d = '') => (string) (\function_exists('get_option') ? \call_user_func('get_option', $k, $d) : $d);
					$optI = fn($k, $d = 0) => (int) (\function_exists('get_option') ? \call_user_func('get_option', $k, $d) : $d);
					$data = [
						'au_push_provider' => $opt('au_push_provider', 'fcm'),
						'au_fcm_server_key' => $opt('au_fcm_server_key', ''),
						'au_rate_limit_count' => $optI('au_rate_limit_count', 60),
						'au_rate_limit_window' => $optI('au_rate_limit_window', 300),
						'au_apns_team_id' => $opt('au_apns_team_id', ''),
						'au_apns_key_id' => $opt('au_apns_key_id', ''),
						'au_apns_topic' => $opt('au_apns_topic', ''),
						'au_apns_p8' => $opt('au_apns_p8', ''),
						'au_apns_sandbox' => $optI('au_apns_sandbox', 1),
						'au_vapid_public' => $opt('au_vapid_public', ''),
						'au_vapid_private' => $opt('au_vapid_private', ''),
						'au_vapid_subject' => $opt('au_vapid_subject', 'mailto:admin@example.com'),
						'au_strip_exif' => $optI('au_strip_exif', 1),
					];
					return \function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $data) : $data;
				}
			]);

			// Admin settings: POST
			\call_user_func('register_rest_route', $ns, '/admin/settings', [
				'methods' => 'POST',
				'permission_callback' => function () { return \function_exists('current_user_can') ? (bool) \call_user_func('current_user_can', 'manage_options') : false; },
				'args' => [ 'data' => ['type' => 'object', 'required' => false] ],
				'callback' => function ($request) {
					$body = is_array($request->get_param('data')) ? $request->get_param('data') : (array) $request->get_json_params();
					$allow = [
						'au_push_provider' => fn($v) => in_array(strtolower((string)$v), ['fcm','apns','webpush'], true) ? strtolower((string)$v) : 'fcm',
						'au_fcm_server_key' => fn($v) => (string) $v,
						'au_rate_limit_count' => fn($v) => max(1, (int)$v),
						'au_rate_limit_window' => fn($v) => max(60, (int)$v),
						'au_apns_team_id' => fn($v) => (string) $v,
						'au_apns_key_id' => fn($v) => (string) $v,
						'au_apns_topic' => fn($v) => (string) $v,
						'au_apns_p8' => fn($v) => (string) $v,
						'au_apns_sandbox' => fn($v) => (int) (!empty($v)),
						'au_vapid_public' => fn($v) => (string) $v,
						'au_vapid_private' => fn($v) => (string) $v,
						'au_vapid_subject' => fn($v) => (string) $v,
						'au_strip_exif' => fn($v) => (int) (!empty($v)),
					];
					$updated = [];
					foreach ($allow as $k => $sanitize) {
						if (array_key_exists($k, $body)) {
							$val = $sanitize($body[$k]);
							if (\function_exists('update_option')) { \call_user_func('update_option', $k, $val); }
							$updated[$k] = $val;
						}
					}
					return \function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', [ 'ok' => true, 'updated' => $updated ]) : [ 'ok' => true, 'updated' => $updated ];
				}
			]);

			// Admin configuration health
			\call_user_func('register_rest_route', $ns, '/admin/health', [
				'methods' => 'GET',
				'permission_callback' => function () { return \function_exists('current_user_can') ? (bool) \call_user_func('current_user_can', 'manage_options') : false; },
				'callback' => function () {
					$opt = fn($k, $d = '') => (string) (\function_exists('get_option') ? \call_user_func('get_option', $k, $d) : $d);
					$opts = [
						'au_push_provider' => $opt('au_push_provider', 'fcm'),
						'au_fcm_server_key' => $opt('au_fcm_server_key', ''),
						'au_apns_team_id' => $opt('au_apns_team_id', ''),
						'au_apns_key_id' => $opt('au_apns_key_id', ''),
						'au_apns_topic' => $opt('au_apns_topic', ''),
						'au_apns_p8' => $opt('au_apns_p8', ''),
						'au_vapid_public' => $opt('au_vapid_public', ''),
						'au_vapid_private' => $opt('au_vapid_private', ''),
						'au_vapid_subject' => $opt('au_vapid_subject', ''),
					];
					$health = self::computeHealth($opts);
					return \function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $health) : $health;
				}
			]);

			// Admin summary counts for dashboard
			\call_user_func('register_rest_route', $ns, '/admin/summary', [
				'methods' => 'GET',
				'permission_callback' => function () { return \function_exists('current_user_can') ? (bool) \call_user_func('current_user_can', 'manage_options') : false; },
				'callback' => function () {
					global $wpdb;
					$counts = [ 'downloads' => 0, 'groups' => 0, 'reports' => 0, 'changes' => 0, 'tombstones' => 0, 'devices' => 0 ];
					if (\function_exists('wp_count_posts')) {
						$downloads = \call_user_func('wp_count_posts', 'au_download');
						$counts['downloads'] = (int) ($downloads->publish ?? 0);
						$groups = \call_user_func('wp_count_posts', 'au_group');
						$counts['groups'] = (int) ($groups->publish ?? 0);
						$reports = \call_user_func('wp_count_posts', 'au_report');
						$counts['reports'] = (int) (($reports->private ?? 0) + ($reports->publish ?? 0));
					}
					if (isset($wpdb)) {
						$counts['changes'] = (int) $wpdb->get_var("SELECT COUNT(1) FROM {$wpdb->prefix}au_changes");
						$counts['tombstones'] = (int) $wpdb->get_var("SELECT COUNT(1) FROM {$wpdb->prefix}au_tombstones");
						$counts['devices'] = (int) $wpdb->get_var("SELECT COUNT(1) FROM {$wpdb->prefix}au_devices");
					}
					return \function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', [ 'counts' => $counts ]) : [ 'counts' => $counts ];
				}
			]);
		}
	}

	/**
	 * Compute configuration health without relying on WordPress runtime.
	 * @param array $opts associative options
	 * @return array health
	 */
	public static function computeHealth(array $opts): array
	{
		$provider = strtolower((string) ($opts['au_push_provider'] ?? 'fcm'));
		if (!in_array($provider, ['fcm','apns','webpush'], true)) { $provider = 'fcm'; }
		$fcmConfigured = isset($opts['au_fcm_server_key']) && trim((string)$opts['au_fcm_server_key']) !== '';
		$apnsMissing = [];
		foreach (['au_apns_team_id' => 'team_id','au_apns_key_id' => 'key_id','au_apns_topic' => 'topic','au_apns_p8' => 'p8'] as $k => $label) {
			$v = (string) ($opts[$k] ?? ''); if ($v === '') { $apnsMissing[] = $label; }
		}
		$apnsConfigured = empty($apnsMissing);
		$vapidMissing = [];
		foreach (['au_vapid_public' => 'public','au_vapid_private' => 'private','au_vapid_subject' => 'subject'] as $k => $label) {
			$v = (string) ($opts[$k] ?? ''); if ($v === '') { $vapidMissing[] = $label; }
		}
		$webpushConfigured = empty($vapidMissing);
		$libraryPresent = class_exists('\\Minishlink\\WebPush\\WebPush');
		$overall = (
			($provider === 'fcm' && $fcmConfigured) ||
			($provider === 'apns' && $apnsConfigured) ||
			($provider === 'webpush' && $webpushConfigured && $libraryPresent)
		);
		return [
			'provider' => $provider,
			'fcm' => [ 'configured' => (bool) $fcmConfigured ],
			'apns' => [ 'configured' => (bool) $apnsConfigured, 'missing' => $apnsMissing ],
			'webpush' => [ 'configured' => (bool) $webpushConfigured, 'missing' => $vapidMissing, 'library' => $libraryPresent ? 'present' : 'missing' ],
			'overall_ok' => (bool) $overall,
		];
	}
}
