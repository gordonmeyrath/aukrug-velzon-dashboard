<?php
namespace Aukrug\Connect;

class Activator
{
    public static function run(): void
    {
        if (class_exists(Plugin::class)) {
            Plugin::activate();
        }
    }
}
