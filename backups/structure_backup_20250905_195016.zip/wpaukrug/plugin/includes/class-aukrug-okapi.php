<?php
namespace Aukrug\Connect;

class Okapi
{
    public function init(): void
    {
        if (\function_exists('add_action')) {
            \add_action('admin_init', [$this, 'registerSettings']);
            \add_action('rest_api_init', [$this, 'registerRoutes']);
        }
    }

    public function registerSettings(): void
    {
        if (!\function_exists('register_setting')) { return; }
        \call_user_func('register_setting', 'aukrug_connect', 'au_okapi_base', [ 'type' => 'string', 'sanitize_callback' => 'esc_url_raw', 'show_in_rest' => false ]);
        \call_user_func('register_setting', 'aukrug_connect', 'au_okapi_key', [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'show_in_rest' => false ]);
        \call_user_func('register_setting', 'aukrug_connect', 'au_okapi_cache_ttl', [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'show_in_rest' => false ]);
    }

    public function registerRoutes(): void
    {
        $ns = 'aukrug-connect/v1';
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/geocaches/near', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'args' => [ 'lat' => ['type' => 'number', 'required' => true], 'lng' => ['type' => 'number', 'required' => true], 'radius_km' => ['type' => 'number', 'required' => false] ],
            'callback' => function($request) {
                $base = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_okapi_base', '') : '';
                $key = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_okapi_key', '') : '';
                $ttl = \function_exists('get_option') ? (int) \call_user_func('get_option', 'au_okapi_cache_ttl', 300) : 300;
                $lat = (float) $request->get_param('lat');
                $lng = (float) $request->get_param('lng');
                $radius = (float) ($request->get_param('radius_km') ?? 5);
                if (!$base || !$key) { return [ 'items' => [], 'error' => 'okapi_not_configured' ]; }

                // Cache key
                $ck = 'au_okapi_' . md5($base . '|' . $lat . '|' . $lng . '|' . $radius);
                $cached = \function_exists('get_transient') ? \call_user_func('get_transient', $ck) : null;
                if (is_array($cached)) { return $this->respWithCacheHeaders($cached, $ttl); }

                // Perform request via wp_remote_get if available
                $items = [];
                if (\function_exists('wp_remote_get')) {
                    $url = rtrim($base, '/') . '/services/caches/shortcuts/search_and_retrieve?search_method=by_location&location=' . rawurlencode($lat . ',' . $lng) . '&radius=' . rawurlencode((string)$radius) . '&consumer_key=' . rawurlencode($key) . '&retr_method=by_codes&fields=code|name|location|status';
                    $res = \call_user_func('wp_remote_get', $url, [ 'timeout' => 10 ]);
                    $hasErrFn = \function_exists('is_wp_error');
                    $isErr = $hasErrFn ? (bool) \call_user_func('is_wp_error', $res) : false;
                    if (!$isErr) {
                        $codeFn = \function_exists('wp_remote_retrieve_response_code') ? 'wp_remote_retrieve_response_code' : null;
                        $bodyFn = \function_exists('wp_remote_retrieve_body') ? 'wp_remote_retrieve_body' : null;
                        $code = $codeFn ? (int) \call_user_func($codeFn, $res) : 0;
                        if ($code === 200 && $bodyFn) {
                            $body = (string) \call_user_func($bodyFn, $res);
                            $data = json_decode($body, true);
                            if (is_array($data)) {
                                foreach ($data as $row) {
                                    $items[] = [
                                        'code' => (string) ($row['code'] ?? ''),
                                        'name' => (string) ($row['name'] ?? ''),
                                        'lat' => isset($row['location']['lat']) ? (float) $row['location']['lat'] : null,
                                        'lng' => isset($row['location']['lon']) ? (float) $row['location']['lon'] : null,
                                        'status' => (string) ($row['status'] ?? ''),
                                    ];
                                }
                            }
                        }
                    }
                }
                $payload = [ 'items' => $items ];
                if (\function_exists('set_transient')) { \call_user_func('set_transient', $ck, $payload, max(60, $ttl)); }
                return $this->respWithCacheHeaders($payload, $ttl);
            }
        ]); }
    }

    private function respWithCacheHeaders(array $payload, int $ttl)
    {
        $etag = 'W/"' . md5(json_encode($payload)) . '"';
        $resp = \function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $payload) : $payload;
        $respClass = '\\WP_REST_Response';
        if (class_exists($respClass)) {
            $resp->header('ETag', $etag);
            $resp->header('Cache-Control', 'public, max-age=' . max(60, $ttl));
        }
        return $resp;
    }
}
