<?php
namespace Aukrug\Connect;

class Sync
{
	private array $cpts = [
		'au_place', 'au_route', 'au_event', 'au_notice', 'au_download', 'au_provider', 'au_group', 'au_community_post'
	];

	public function init(): void
	{
		if (\function_exists('add_action')) {
			\add_action('save_post', [$this, 'onSave'], 10, 3);
			\add_action('before_delete_post', [$this, 'onDelete']);
			\add_action('trashed_post', [$this, 'onDelete']);
		}
	}

	public function onSave(int $post_ID, $post, bool $update): void
	{
		if (!\is_object($post) || !\in_array($post->post_type, $this->cpts, true)) {
			return;
		}
	if (\defined('DOING_AUTOSAVE') && \constant('DOING_AUTOSAVE')) {
			return;
		}
		global $wpdb;
		$table = $wpdb->prefix . 'au_changes';
		$action = $update ? 'updated' : 'created';
		$wpdb->insert($table, [
			'entity_type' => $post->post_type,
			'entity_id'   => (string) $post_ID,
			'action'      => $action,
			'payload'     => null,
			'user_id'     => (\function_exists('get_current_user_id') ? \call_user_func('get_current_user_id') : null),
			'created_at'  => (\function_exists('current_time') ? \call_user_func('current_time', 'mysql', true) : gmdate('Y-m-d H:i:s')),
		]);
	}

	public function onDelete(int $post_ID): void
	{
	$post = (\function_exists('get_post') ? \call_user_func('get_post', $post_ID) : null);
		if (!$post || !\in_array($post->post_type, $this->cpts, true)) {
			return;
		}
		global $wpdb;
		$tableC = $wpdb->prefix . 'au_changes';
		$tableT = $wpdb->prefix . 'au_tombstones';
		// Log tombstone and a delete change
		$wpdb->insert($tableT, [
			'entity_type' => $post->post_type,
			'entity_id'   => (string) $post_ID,
			'deleted_at'  => (\function_exists('current_time') ? \call_user_func('current_time', 'mysql', true) : gmdate('Y-m-d H:i:s')),
		]);
		$wpdb->insert($tableC, [
			'entity_type' => $post->post_type,
			'entity_id'   => (string) $post_ID,
			'action'      => 'deleted',
			'payload'     => null,
			'user_id'     => (\function_exists('get_current_user_id') ? \call_user_func('get_current_user_id') : null),
			'created_at'  => (\function_exists('current_time') ? \call_user_func('current_time', 'mysql', true) : gmdate('Y-m-d H:i:s')),
		]);
	}
}
