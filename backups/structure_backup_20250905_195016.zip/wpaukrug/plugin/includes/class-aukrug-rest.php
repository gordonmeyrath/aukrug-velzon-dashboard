<?php
namespace Aukrug\Connect;

class Rest
{
    public function init(): void
    {
        if (\function_exists('add_action')) {
            \add_action('rest_api_init', [$this, 'registerRoutes']);
        }
    }

    public function registerRoutes(): void
    {
        $ns = 'aukrug-connect/v1';

        // Generic collections endpoint for core CPTs with basic filters + caching headers
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/collection/(?P<type>[a-z\-]+)', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'args' => [
                'type' => [ 'type' => 'string', 'required' => true ],
                'search' => [ 'type' => 'string', 'required' => false ],
                'page' => [ 'type' => 'integer', 'required' => false ],
                'per_page' => [ 'type' => 'integer', 'required' => false ],
                'audience' => [ 'type' => 'array', 'items' => [ 'type' => 'string' ], 'required' => false ],
                'near' => [ 'type' => 'string', 'required' => false ], // "lat,lng,radius_km"
            ],
            'callback' => function ($request) {
                $type = (string) $request->get_param('type');
                $map = [
                    'places' => 'au_place',
                    'routes' => 'au_route',
                    'events' => 'au_event',
                    'notices' => 'au_notice',
                    'providers' => 'au_provider',
                    'groups' => 'au_group',
                    'community-posts' => 'au_community_post',
                    'appcaches' => 'au_appcache',
                ];
                if (!isset($map[$type])) { return [ 'error' => 'unsupported_collection', 'status' => 400 ]; }
                $cpt = $map[$type];

                $search = (string) ($request->get_param('search') ?? '');
                $page = max(1, (int) ($request->get_param('page') ?? 1));
                $pp = (int) ($request->get_param('per_page') ?? 20);
                $pp = max(1, min(100, $pp));
                $args = [
                    'post_type' => $cpt,
                    'post_status' => 'publish',
                    's' => $search ?: null,
                    'orderby' => 'modified',
                    'order' => 'DESC',
                    'posts_per_page' => $pp,
                    'paged' => $page,
                ];

                // Audience taxonomy filter
                $aud = $request->get_param('audience');
                if ($aud) {
                    $aud = is_array($aud) ? $aud : [ (string) $aud ];
                    $args['tax_query'][] = [
                        'taxonomy' => 'au_audience',
                        'field' => 'slug',
                        'terms' => array_values(array_filter(array_map('strval', $aud))),
                    ];
                }

                // near filter (lat,lng,radius_km) using bounding box over canonical meta coords_lat/coords_lng
                $near = (string) ($request->get_param('near') ?? '');
                if ($near && in_array($cpt, ['au_place','au_event','au_appcache'], true)) {
                    $parts = array_map('trim', explode(',', $near));
                    if (count($parts) === 3) {
                        list($lat, $lng, $radiusKm) = $parts;
                        $lat = (float) $lat; $lng = (float) $lng; $radiusKm = max(0.1, (float) $radiusKm);
                        $degLat = $radiusKm / 111.0; // approx per degree
                        $degLng = $radiusKm / max(0.1, (111.0 * cos(deg2rad($lat))));
                        $args['meta_query'] = $args['meta_query'] ?? [];
                        $args['meta_query'][] = [ 'key' => 'coords_lat', 'value' => [$lat - $degLat, $lat + $degLat], 'compare' => 'BETWEEN', 'type' => 'NUMERIC' ];
                        $args['meta_query'][] = [ 'key' => 'coords_lng', 'value' => [$lng - $degLng, $lng + $degLng], 'compare' => 'BETWEEN', 'type' => 'NUMERIC' ];
                    }
                }

                $q = null; $wpq = '\\WP_Query';
                if (class_exists($wpq)) { $q = new $wpq($args); } else { return [ 'items' => [], 'total' => 0 ]; }
                $items = [];
                $maxModified = null;
                foreach ($q->posts as $p) {
                    $id = (int) $p->ID;
                    $title = \function_exists('get_the_title') ? (string) \call_user_func('get_the_title', $id) : (string) ($p->post_title ?? '');
                    $excerpt = \function_exists('wp_trim_words') ? (string) \call_user_func('wp_trim_words', strip_tags($p->post_content), 40) : '';
                    $modified = \function_exists('get_post_modified_time') ? (string) \call_user_func('get_post_modified_time', 'c', true, $id) : (string) ($p->post_modified_gmt ?? '');
                    $meta = \function_exists('get_post_meta') ? (array) \call_user_func('get_post_meta', $id) : [];
                    // Flatten meta and drop private keys
                    $flatMeta = [];
                    foreach ($meta as $k => $vals) {
                        if (!$k || $k[0] === '_') { continue; }
                        $flatMeta[$k] = is_array($vals) ? (count($vals) === 1 ? $vals[0] : array_values($vals)) : $vals;
                    }
                    $items[] = [
                        'id' => $id,
                        'type' => $cpt,
                        'title' => $title,
                        'excerpt' => $excerpt,
                        'updated_at' => $modified,
                        'meta' => $flatMeta,
                    ];
                    if ($modified) { $ts = strtotime($modified); if ($ts) { $maxModified = max($maxModified ?? $ts, $ts); } }
                }
                $respData = [ 'items' => $items, 'total' => (int) $q->found_posts, 'page' => $page, 'per_page' => $pp ];

                // Build conditional response with ETag/Last-Modified; set headers directly when possible
                $etag = 'W/"' . md5($type . '|' . $page . '|' . $pp . '|' . serialize(array_map(fn($i) => $i['updated_at'] ?? '', $items))) . '"';
                $lastModHttp = $maxModified ? gmdate('D, d M Y H:i:s', $maxModified) . ' GMT' : null;
                $ifNoneMatch = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? (string) $_SERVER['HTTP_IF_NONE_MATCH'] : '';
                $ifModSince = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? (string) $_SERVER['HTTP_IF_MODIFIED_SINCE'] : '';
                if (\function_exists('headers_sent') && !\headers_sent()) {
                    if (\function_exists('header')) {
                        \header('ETag: ' . $etag);
                        if ($lastModHttp) { \header('Last-Modified: ' . $lastModHttp); }
                        \header('Cache-Control: public, max-age=60');
                        $nm = ($ifNoneMatch && $ifNoneMatch === $etag) || ($ifModSince && $lastModHttp && (strtotime($ifModSince) >= ($maxModified ?? 0)));
                        if ($nm) { \header('HTTP/1.1 304 Not Modified'); return null; }
                    }
                }
                return $respData;
            },
        ]); }

        // Delta since timestamp
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/delta', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function ($request) {
                global $wpdb;
                $since = $request->get_param('since');
                $limit = (int) ($request->get_param('limit') ?? 200);
                $limit = max(1, min(500, $limit));
                $table = $wpdb->prefix . 'au_changes';
                if (!$since) {
                    $sql = $wpdb->prepare("SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit);
                } else {
                    $sql = $wpdb->prepare("SELECT * FROM {$table} WHERE created_at > %s ORDER BY id DESC LIMIT %d", $since, $limit);
                }
                $rows = $wpdb->get_results($sql, 'ARRAY_A');
                $resp = [
                    'items' => $rows,
                    'next' => count($rows) === $limit ? (end($rows)['created_at'] ?? null) : null,
                ];
                return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
            },
            'args' => [
                'since' => [ 'type' => 'string', 'required' => false ],
                'limit' => [ 'type' => 'integer', 'required' => false ],
            ],
        ]); }

        // Tombstones (deletions)
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/tombstones', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function ($request) {
                global $wpdb;
                $since = $request->get_param('since');
                $limit = (int) ($request->get_param('limit') ?? 200);
                $limit = max(1, min(500, $limit));
                $table = $wpdb->prefix . 'au_tombstones';
                if (!$since) {
                    $sql = $wpdb->prepare("SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit);
                } else {
                    $sql = $wpdb->prepare("SELECT * FROM {$table} WHERE deleted_at > %s ORDER BY id DESC LIMIT %d", $since, $limit);
                }
                $rows = $wpdb->get_results($sql, 'ARRAY_A');
                $resp = [
                    'items' => $rows,
                    'next' => count($rows) === $limit ? (end($rows)['deleted_at'] ?? null) : null,
                ];
                return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
            },
            'args' => [
                'since' => [ 'type' => 'string', 'required' => false ],
                'limit' => [ 'type' => 'integer', 'required' => false ],
            ],
        ]); }

        // Combined sync changes view
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/sync/changes', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'args' => [
                'since' => [ 'type' => 'string', 'required' => false ],
                'limit' => [ 'type' => 'integer', 'required' => false ],
            ],
            'callback' => function ($request) {
                global $wpdb; $since = $request->get_param('since');
                $limit = (int) ($request->get_param('limit') ?? 200);
                $limit = max(1, min(500, $limit));
                $tableC = $wpdb->prefix . 'au_changes';
                $tableT = $wpdb->prefix . 'au_tombstones';
                $sqlC = $since ? $wpdb->prepare("SELECT * FROM {$tableC} WHERE created_at > %s ORDER BY id DESC LIMIT %d", $since, $limit) : $wpdb->prepare("SELECT * FROM {$tableC} ORDER BY id DESC LIMIT %d", $limit);
                $sqlT = $since ? $wpdb->prepare("SELECT * FROM {$tableT} WHERE deleted_at > %s ORDER BY id DESC LIMIT %d", $since, $limit) : $wpdb->prepare("SELECT * FROM {$tableT} ORDER BY id DESC LIMIT %d", $limit);
                $changed = $wpdb->get_results($sqlC, 'ARRAY_A');
                $deleted = $wpdb->get_results($sqlT, 'ARRAY_A');
                $last = null;
                if ($changed) { $lc = strtotime($changed[0]['created_at'] ?? ''); if ($lc) { $last = max($last ?? $lc, $lc); } }
                if ($deleted) { $ld = strtotime($deleted[0]['deleted_at'] ?? ''); if ($ld) { $last = max($last ?? $ld, $ld); } }
                $resp = [
                    'since' => $since ?: null,
                    'changed' => $changed,
                    'deleted' => $deleted,
                    'last_modified' => $last ? gmdate('c', $last) : null,
                ];
                return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
            }
        ]); }

        // Create report (private, authenticated)
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/reports', [
            'methods' => 'POST',
            'permission_callback' => function () {
                return \function_exists('is_user_logged_in') ? \call_user_func('is_user_logged_in') : false;
            },
            'args' => [
                'category' => ['type' => 'string', 'required' => false],
                'lat' => ['type' => 'number', 'required' => false],
                'long' => ['type' => 'number', 'required' => false],
                'photo_url' => ['type' => 'string', 'required' => false],
            ],
            'callback' => function ($request) {
                // Sanitize inputs
                $category = (string) ($request->get_param('category') ?? '');
                $lat = $request->get_param('lat');
                $long = $request->get_param('long');
                $photo_url = (string) ($request->get_param('photo_url') ?? '');

                // Handle file upload if provided (multipart/form-data with field name 'photo')
                $files = method_exists($request, 'get_file_params') ? $request->get_file_params() : [];
                $attachment_id = 0;
                if (!empty($files['photo']) && is_array($files['photo'])) {
                    $file = $files['photo'];
                    $tmp = $file['tmp_name'] ?? '';
                    if (is_readable($tmp)) {
                        $processed = $this->stripExifToTmp($tmp, $file['type'] ?? 'image/jpeg');
                        if ($processed && is_readable($processed)) {
                            // Sideload array per media_handle_sideload
                            $sideload = [
                                'name' => $file['name'] ?? 'report.jpg',
                                'type' => $file['type'] ?? 'image/jpeg',
                                'tmp_name' => $processed,
                                'error' => 0,
                                'size' => filesize($processed),
                            ];
                            if (\function_exists('media_handle_sideload')) {
                                $attachment_id = \call_user_func('media_handle_sideload', $sideload, 0);
                            }
                        }
                    }
                }

                // Create private report post
                $title = 'Report ' . gmdate('Y-m-d H:i:s');
                $post_id = 0;
                if (\function_exists('wp_insert_post')) {
                    $post_id = \call_user_func('wp_insert_post', [
                        'post_type' => 'au_report',
                        'post_status' => 'private',
                        'post_title' => $title,
                        'post_content' => '',
                    ]);
                }
                if (!$post_id || (\function_exists('is_wp_error') && \call_user_func('is_wp_error', $post_id))) {
                    $err = [ 'error' => 'au_report_failed', 'message' => 'Failed to create report', 'status' => 500 ];
                    return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $err) : $err);
                }

                // Save meta
                if ($category) { \call_user_func('update_post_meta', $post_id, 'au_report_category', (\function_exists('sanitize_text_field') ? \call_user_func('sanitize_text_field', $category) : $category)); }
                if ($lat !== null) { \call_user_func('update_post_meta', $post_id, 'au_latitude', (float) $lat); }
                if ($long !== null) { \call_user_func('update_post_meta', $post_id, 'au_longitude', (float) $long); }
                $final_photo_url = '';
                if ($attachment_id && (!\function_exists('is_wp_error') || !\call_user_func('is_wp_error', $attachment_id))) {
                    $final_photo_url = \function_exists('wp_get_attachment_url') ? (string) \call_user_func('wp_get_attachment_url', $attachment_id) : '';
                } elseif ($photo_url) {
                    $final_photo_url = (\function_exists('esc_url_raw') ? \call_user_func('esc_url_raw', $photo_url) : $photo_url);
                }
                if ($final_photo_url) {
                    \call_user_func('update_post_meta', $post_id, 'au_photo_url', $final_photo_url);
                }

                $response = [
                    'id' => (int) $post_id,
                    'photo_url' => $final_photo_url,
                ];
                return \function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $response) : $response;
            },
        ]); }

        // Relay message envelope (no content storage)
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/relay', [
            'methods' => 'POST',
            'permission_callback' => function () { return \function_exists('is_user_logged_in') ? \call_user_func('is_user_logged_in') : false; },
            'args' => [
                'target_user_ids' => ['type' => 'array', 'required' => true],
                'notification' => ['type' => 'object', 'required' => false],
                'data' => ['type' => 'object', 'required' => false],
            ],
            'callback' => function ($request) {
                $uid = (\function_exists('get_current_user_id') ? (int) \call_user_func('get_current_user_id') : 0);
                if (!$uid) { return [ 'error' => 'unauthorized', 'status' => 401 ]; }
                // Simple rate limit using configurable options
                $k = 'au_rl_' . $uid;
                $count = (int) (\function_exists('get_transient') ? \call_user_func('get_transient', $k) : 0);
                $maxCount = \function_exists('get_option') ? (int) \call_user_func('get_option', 'au_rate_limit_count', 60) : 60;
                $window = \function_exists('get_option') ? (int) \call_user_func('get_option', 'au_rate_limit_window', 300) : 300;
                if ($count >= max(1, $maxCount)) { return [ 'error' => 'rate_limited', 'status' => 429 ]; }
                $ttl = $window > 0 ? $window : (\defined('MINUTE_IN_SECONDS') ? (5 * \constant('MINUTE_IN_SECONDS')) : 300);
                if (\function_exists('set_transient')) { \call_user_func('set_transient', $k, $count + 1, $ttl); }

                $targets = (array) $request->get_param('target_user_ids');
                $targets = array_values(array_filter(array_map('intval', $targets)));
                if (!$targets) { return [ 'ok' => true, 'delivered' => 0 ]; }

                // Fetch device tokens from registry and filter per provider/platform
                global $wpdb; $table = $wpdb->prefix . 'au_devices';
                $in = implode(',', array_fill(0, count($targets), '%d'));
                $rows = $wpdb->get_results($wpdb->prepare("SELECT push_token, platform, web_endpoint, web_p256dh, web_auth FROM {$table} WHERE user_id IN ($in)", ...$targets), 'ARRAY_A');
                $provider = (\function_exists('get_option') ? (string) \call_user_func('get_option', 'au_push_provider', 'fcm') : 'fcm');
                $provider = strtolower($provider);
                $platformFilter = function(array $r) use ($provider) {
                    $p = strtolower($r['platform'] ?? '');
                    if ($provider === 'apns') { return $p === 'ios'; }
                    if ($provider === 'webpush') { return $p === 'web'; }
                    // default fcm
                    return ($p === 'android' || $p === 'web' || $p === '');
                };
                $filtered = array_values(array_filter($rows, $platformFilter));
                if ($provider === 'webpush') {
                    $tokens = [];
                    foreach ($filtered as $r) {
                        $endpoint = $r['web_endpoint'] ?? '';
                        $p256dh = $r['web_p256dh'] ?? '';
                        $auth = $r['web_auth'] ?? '';
                        if ($endpoint && $p256dh && $auth) {
                            $tokens[] = [ 'endpoint' => $endpoint, 'p256dh' => $p256dh, 'auth' => $auth ];
                        }
                    }
                } else {
                    $tokens = array_values(array_unique(array_filter(array_map(fn($r) => $r['push_token'] ?? '', $filtered))));
                }

                $notification = (array) ($request->get_param('notification') ?? []);
                $data = (array) ($request->get_param('data') ?? []);

                // Send via Push adapter (provider selected in settings)
                $p = new \Aukrug\Connect\Notify\Push();
                $res = $p->send($tokens, $notification, $data);
                $resp = [ 'ok' => (bool) ($res['ok'] ?? false), 'delivered' => (int) ($res['sent'] ?? 0) ];
                return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
            },
        ]); }
    }

    private function stripExifToTmp(string $src, string $mime)
    {
        // Re-encode image with GD to drop metadata when possible
        if (!\function_exists('imagecreatefromjpeg')) {
            return $src; // fallback: return original if GD not present
        }
        $tmp = function_exists('wp_tempnam') ? \call_user_func('wp_tempnam', 'au_report') : tempnam(sys_get_temp_dir(), 'au_report');
        if (!$tmp) { return $src; }
        $mime = strtolower($mime);
        try {
            if (strpos($mime, 'jpeg') !== false || strpos($mime, 'jpg') !== false) {
                $im = @imagecreatefromjpeg($src);
                if ($im) { imagejpeg($im, $tmp, 90); imagedestroy($im); return $tmp; }
            } elseif (strpos($mime, 'png') !== false) {
                if (\function_exists('imagecreatefrompng')) { $im = @imagecreatefrompng($src); if ($im) { imagepng($im, $tmp, 6); imagedestroy($im); return $tmp; } }
            }
        } catch (\Throwable $e) {
            // ignore and fallback
        }
        return $src;
    }
}
