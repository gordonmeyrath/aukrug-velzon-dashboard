<?php
namespace Aukrug\Connect;

class Deactivator
{
    public static function run(): void
    {
        if (class_exists(Plugin::class)) {
            Plugin::deactivate();
        }
    }
}
