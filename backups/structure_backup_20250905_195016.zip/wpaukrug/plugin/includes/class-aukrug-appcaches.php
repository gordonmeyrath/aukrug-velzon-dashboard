<?php
namespace Aukrug\Connect;

class Appcaches
{
    public function init(): void
    {
        if (\function_exists('add_action')) {
            \add_action('rest_api_init', [$this, 'registerRoutes']);
        }
    }

    public function registerRoutes(): void
    {
        $ns = 'aukrug-connect/v1';
        // Domain-specific view (thin wrapper around collection for now)
    if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/appcaches', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'args' => [
                'search' => [ 'type' => 'string', 'required' => false ],
                'page' => [ 'type' => 'integer', 'required' => false ],
                'per_page' => [ 'type' => 'integer', 'required' => false ],
        'near' => [ 'type' => 'string', 'required' => false ], // "lat,lng,radius_km"
            ],
            'callback' => function($request) {
                // Delegate to Rest collection to avoid duplication
                $rest = new Rest();
                // Build a synthetic request-like object for collection/appcaches
                $params = [
                    'type' => 'appcaches',
                    'search' => $request->get_param('search'),
                    'page' => $request->get_param('page'),
                    'per_page' => $request->get_param('per_page'),
                    'near' => $request->get_param('near'),
                ];
                // Late-bind route callback by calling Rest::registerRoutes and invoking the same logic
                // Simpler: locally issue a WP_Query directly mirroring Rest
                $page = max(1, (int) ($params['page'] ?? 1));
                $pp = max(1, min(100, (int) ($params['per_page'] ?? 20)));
                $args = [
                    'post_type' => 'au_appcache',
                    'post_status' => 'publish',
                    's' => (string) ($params['search'] ?? '') ?: null,
                    'orderby' => 'modified', 'order' => 'DESC',
                    'posts_per_page' => $pp, 'paged' => $page,
                ];
                // near filter (lat,lng,radius_km) using bounding box over canonical meta coords_lat/coords_lng
                $near = (string) ($params['near'] ?? '');
                if ($near) {
                    $parts = array_map('trim', explode(',', $near));
                    if (count($parts) === 3) {
                        list($lat, $lng, $radiusKm) = $parts;
                        $lat = (float) $lat; $lng = (float) $lng; $radiusKm = max(0.1, (float) $radiusKm);
                        $degLat = $radiusKm / 111.0; // approx per degree
                        $degLng = $radiusKm / max(0.1, (111.0 * cos(deg2rad($lat))));
                        $args['meta_query'] = $args['meta_query'] ?? [];
                        $args['meta_query'][] = [ 'key' => 'coords_lat', 'value' => [$lat - $degLat, $lat + $degLat], 'compare' => 'BETWEEN', 'type' => 'NUMERIC' ];
                        $args['meta_query'][] = [ 'key' => 'coords_lng', 'value' => [$lng - $degLng, $lng + $degLng], 'compare' => 'BETWEEN', 'type' => 'NUMERIC' ];
                    }
                }
                $wpq = '\\WP_Query';
                if (!class_exists($wpq)) { return [ 'items' => [], 'total' => 0, 'page' => $page, 'per_page' => $pp ]; }
                $q = new $wpq($args);
                $items = [];
                $maxModified = null;
                foreach ($q->posts as $p) {
                    $id = (int) $p->ID;
                    $title = \function_exists('get_the_title') ? (string) \call_user_func('get_the_title', $id) : (string) ($p->post_title ?? '');
                    $modified = \function_exists('get_post_modified_time') ? (string) \call_user_func('get_post_modified_time', 'c', true, $id) : (string) ($p->post_modified_gmt ?? '');
                    $meta = \function_exists('get_post_meta') ? (array) \call_user_func('get_post_meta', $id) : [];
                    $flatMeta = [];
                    foreach ($meta as $k => $vals) {
                        if (!$k || $k[0] === '_') { continue; }
                        $flatMeta[$k] = is_array($vals) ? (count($vals) === 1 ? $vals[0] : array_values($vals)) : $vals;
                    }
                    $items[] = [ 'id' => $id, 'title' => $title, 'updated_at' => $modified, 'meta' => $flatMeta ];
                    if ($modified) { $ts = strtotime($modified); if ($ts) { $maxModified = max($maxModified ?? $ts, $ts); } }
                }
                $resp = [ 'items' => $items, 'total' => (int) $q->found_posts, 'page' => $page, 'per_page' => $pp ];
                // Cache headers
                $etag = 'W/"' . md5('appcaches|' . $page . '|' . $pp . '|' . serialize(array_map(fn($i) => $i['updated_at'] ?? '', $items))) . '"';
                $lastModHttp = $maxModified ? gmdate('D, d M Y H:i:s', $maxModified) . ' GMT' : null;
                $ifNoneMatch = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? (string) $_SERVER['HTTP_IF_NONE_MATCH'] : '';
                $ifModSince = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? (string) $_SERVER['HTTP_IF_MODIFIED_SINCE'] : '';
                if (\function_exists('headers_sent') && !\headers_sent()) {
                    if (\function_exists('header')) {
                        \header('ETag: ' . $etag);
                        if ($lastModHttp) { \header('Last-Modified: ' . $lastModHttp); }
                        \header('Cache-Control: public, max-age=60');
                        $nm = ($ifNoneMatch && $ifNoneMatch === $etag) || ($ifModSince && $lastModHttp && (strtotime($ifModSince) >= ($maxModified ?? 0)));
                        if ($nm) { \header('HTTP/1.1 304 Not Modified'); return null; }
                    }
                }
                return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
            }
        ]); }

        // Create/update an app-only cache (auth required)
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/appcaches', [
            'methods' => 'POST',
            'permission_callback' => function () { return \function_exists('is_user_logged_in') ? \call_user_func('is_user_logged_in') : false; },
            'args' => [
                'id' => [ 'type' => 'integer', 'required' => false ],
                'title' => [ 'type' => 'string', 'required' => true ],
                'content' => [ 'type' => 'string', 'required' => false ],
                'coords_lat' => [ 'type' => 'number', 'required' => false ],
                'coords_lng' => [ 'type' => 'number', 'required' => false ],
                'audience' => [ 'type' => 'array', 'required' => false, 'items' => [ 'type' => 'string' ] ],
                'status' => [ 'type' => 'string', 'required' => false ],
            ],
            'callback' => function($request) {
                $raw = [
                    'id' => $request->get_param('id'),
                    'title' => $request->get_param('title'),
                    'content' => $request->get_param('content'),
                    'coords_lat' => $request->get_param('coords_lat'),
                    'coords_lng' => $request->get_param('coords_lng'),
                    'audience' => $request->get_param('audience'),
                    'status' => $request->get_param('status'),
                ];
                $san = self::sanitizePayload($raw);
                if ($san['errors']) { return [ 'ok' => false, 'errors' => $san['errors'], 'status' => 400 ]; }
                if (!\function_exists('wp_insert_post')) { return [ 'ok' => false, 'reason' => 'wp_runtime_missing', 'status' => 500 ]; }

                $postarr = [
                    'post_type' => 'au_appcache',
                    'post_status' => $san['status'],
                    'post_title' => $san['title'],
                    'post_content' => $san['content'],
                ];
                $pid = 0; $updating = false;
                if ($san['id'] > 0) {
                    $postarr['ID'] = $san['id'];
                    $pid = \call_user_func('wp_update_post', $postarr, true);
                    $updating = true;
                } else {
                    $pid = \call_user_func('wp_insert_post', $postarr, true);
                }
                if (\function_exists('is_wp_error') && \call_user_func('is_wp_error', $pid)) {
                    return [ 'ok' => false, 'reason' => 'save_failed', 'status' => 500 ];
                }
                $pid = (int) $pid;
                // Update canonical meta
                if ($san['coords_lat'] !== null) { \call_user_func('update_post_meta', $pid, 'coords_lat', (float) $san['coords_lat']); }
                if ($san['coords_lng'] !== null) { \call_user_func('update_post_meta', $pid, 'coords_lng', (float) $san['coords_lng']); }
                // Audience terms
                if ($san['audience']) {
                    if (\function_exists('wp_set_object_terms')) {
                        \call_user_func('wp_set_object_terms', $pid, $san['audience'], 'au_audience', false);
                    }
                }

                return (\function_exists('rest_ensure_response')
                    ? \call_user_func('rest_ensure_response', [ 'ok' => true, 'id' => $pid, 'updated' => $updating ])
                    : [ 'ok' => true, 'id' => $pid, 'updated' => $updating ]);
            }
        ]); }

        // Delete
        if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/appcaches', [
            'methods' => 'DELETE',
            'permission_callback' => function () {
                if (!\function_exists('is_user_logged_in') || !\function_exists('current_user_can')) { return false; }
                if (!\call_user_func('is_user_logged_in')) { return false; }
                return \call_user_func('current_user_can', 'delete_posts');
            },
            'args' => [ 'id' => [ 'type' => 'integer', 'required' => true ] ],
            'callback' => function($request) {
                $id = (int) ($request->get_param('id') ?? 0);
                if ($id <= 0) { return [ 'ok' => false, 'error' => 'bad_request', 'status' => 400 ]; }
                if (!\function_exists('get_post_type') || !\function_exists('wp_delete_post')) {
                    return [ 'ok' => false, 'error' => 'wp_runtime_missing', 'status' => 500 ];
                }
                $pt = (string) \call_user_func('get_post_type', $id);
                if ($pt !== 'au_appcache') { return [ 'ok' => false, 'error' => 'not_found', 'status' => 404 ]; }
                $res = \call_user_func('wp_delete_post', $id, true);
                if (!$res) { return [ 'ok' => false, 'error' => 'delete_failed', 'status' => 500 ]; }
                return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', [ 'ok' => true ]) : [ 'ok' => true ]);
            }
        ]); }
    }

    /**
     * Sanitize and validate POST payload for app-only caches.
     * Returns array: [id, title, content, coords_lat|null, coords_lng|null, audience[], status, errors[]]
     */
    public static function sanitizePayload(array $in): array
    {
        $errors = [];
        $id = isset($in['id']) ? max(0, (int) $in['id']) : 0;
        $title = trim((string) ($in['title'] ?? ''));
        if ($title === '') { $errors[] = 'title_required'; }
        $content = (string) ($in['content'] ?? '');
        $lat = isset($in['coords_lat']) ? (float) $in['coords_lat'] : null;
        $lng = isset($in['coords_lng']) ? (float) $in['coords_lng'] : null;
        if ($lat !== null && ($lat < -90.0 || $lat > 90.0)) { $errors[] = 'coords_lat_invalid'; }
        if ($lng !== null && ($lng < -180.0 || $lng > 180.0)) { $errors[] = 'coords_lng_invalid'; }
        $aud = $in['audience'] ?? [];
        if (!is_array($aud)) { $aud = [$aud]; }
        $aud = array_values(array_filter(array_map('strval', $aud), fn($s) => $s !== ''));
        $status = strtolower((string) ($in['status'] ?? 'publish'));
        if (!in_array($status, ['publish','private','draft'], true)) { $status = 'publish'; }

        return [
            'id' => $id,
            'title' => $title,
            'content' => $content,
            'coords_lat' => $lat,
            'coords_lng' => $lng,
            'audience' => $aud,
            'status' => $status,
            'errors' => $errors,
        ];
    }
}

