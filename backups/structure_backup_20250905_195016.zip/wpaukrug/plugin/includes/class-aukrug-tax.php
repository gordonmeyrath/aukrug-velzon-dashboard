<?php
namespace Aukrug\Connect;

class Tax
{
	private function callWp(string $fn, ...$args)
	{
		// Normalize to global function name
		if ($fn[0] !== '\\') {
			$fn = '\\' . $fn;
		}
		if (\function_exists(ltrim($fn, '\\'))) {
			return \call_user_func_array($fn, $args);
		}
		return null;
	}

	public function init(): void
	{
		$this->callWp('add_action', 'init', [$this, 'registerTaxonomies']);
	}

	public function registerTaxonomies(): void
	{
		// Audience taxonomy for most content
		$this->callWp('register_taxonomy', 'au_audience', ['au_place', 'au_route', 'au_event', 'au_notice', 'au_download', 'au_provider'], [
			'labels' => [
				'name' => (\function_exists('__') ? \__('Audience', 'aukrug-connect') : 'Audience'),
				'singular_name' => (\function_exists('__') ? \__('Audience', 'aukrug-connect') : 'Audience'),
			],
			'public' => false,
			'show_ui' => true,
			'show_in_rest' => true,
			'hierarchical' => false,
		]);

		// Download categories
		$this->callWp('register_taxonomy', 'au_download_category', ['au_download'], [
			'labels' => [
				'name' => (\function_exists('__') ? \__('Download Categories', 'aukrug-connect') : 'Download Categories'),
				'singular_name' => (\function_exists('__') ? \__('Download Category', 'aukrug-connect') : 'Download Category'),
			],
			'public' => false,
			'show_ui' => true,
			'show_in_rest' => true,
			'hierarchical' => true,
		]);

		// Group type taxonomy
		$this->callWp('register_taxonomy', 'au_group_type', ['au_group'], [
			'labels' => [
				'name' => (\function_exists('__') ? \__('Group Types', 'aukrug-connect') : 'Group Types'),
				'singular_name' => (\function_exists('__') ? \__('Group Type', 'aukrug-connect') : 'Group Type'),
			],
			'public' => false,
			'show_ui' => true,
			'show_in_rest' => true,
			'hierarchical' => false,
		]);
	}

	public function seedDefaultTerms(): void
	{
		// Seed default terms (idempotent)
		foreach (['tourist', 'resident', 'kita', 'schule'] as $slug) {
			if (!$this->callWp('term_exists', $slug, 'au_audience')) {
				$this->callWp('wp_insert_term', $slug, 'au_audience', [
					'slug' => $slug,
					'description' => ucfirst($slug),
				]);
			}
		}

		$download_cats = ['Formulare', 'Satzungen', 'Veranstaltungen', 'Kita', 'Schule', 'Abfall', 'Bauen', 'Gesundheit', 'Freizeit', 'Sonstiges'];
		foreach ($download_cats as $name) {
			$slug = (string) ($this->callWp('sanitize_title', $name) ?? $name);
			if (!$this->callWp('term_exists', $slug, 'au_download_category')) {
				$this->callWp('wp_insert_term', $name, 'au_download_category', [
					'slug' => $slug,
				]);
			}
		}

		foreach (['public', 'private', 'resident', 'school'] as $slug) {
			if (!$this->callWp('term_exists', $slug, 'au_group_type')) {
				$this->callWp('wp_insert_term', $slug, 'au_group_type', [
					'slug' => $slug,
				]);
			}
		}
	}
}

