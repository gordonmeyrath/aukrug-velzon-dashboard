<?php
namespace Aukrug\Connect;

class Privacy { public function init(): void {} }
