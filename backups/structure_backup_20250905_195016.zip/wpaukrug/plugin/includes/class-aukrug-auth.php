<?php
namespace Aukrug\Connect;

class Auth { public function init(): void {} }
