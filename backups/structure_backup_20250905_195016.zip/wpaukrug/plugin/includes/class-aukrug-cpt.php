<?php
namespace Aukrug\Connect;

class Cpt
{
	public function init(): void
	{
	\add_action('init', [$this, 'registerPostTypes']);
	\add_action('init', [$this, 'registerMeta']);
	}

	public function registerPostTypes(): void
	{
		// Common args
		$common = [
			'public' => false,
			'show_ui' => true,
			'show_in_rest' => true,
			'has_archive' => false,
			'rewrite' => false,
			'supports' => ['title', 'editor', 'thumbnail', 'custom-fields', 'excerpt'],
		];

	\register_post_type('au_place', $common + [
			'labels' => [
				'name' => __('Places', 'aukrug-connect'),
				'singular_name' => __('Place', 'aukrug-connect'),
			],
		]);

	\register_post_type('au_route', $common + [
			'labels' => [
				'name' => __('Routes', 'aukrug-connect'),
				'singular_name' => __('Route', 'aukrug-connect'),
			],
		]);

	\register_post_type('au_event', $common + [
			'labels' => [
				'name' => __('Events', 'aukrug-connect'),
				'singular_name' => __('Event', 'aukrug-connect'),
			],
		]);

	\register_post_type('au_notice', $common + [
			'labels' => [
				'name' => __('Notices', 'aukrug-connect'),
				'singular_name' => __('Notice', 'aukrug-connect'),
			],
		]);

	\register_post_type('au_download', $common + [
			'labels' => [
				'name' => __('Downloads', 'aukrug-connect'),
				'singular_name' => __('Download', 'aukrug-connect'),
			],
		]);

	\register_post_type('au_provider', $common + [
			'labels' => [
				'name' => __('Providers', 'aukrug-connect'),
				'singular_name' => __('Provider', 'aukrug-connect'),
			],
		]);

	\register_post_type('au_group', $common + [
			'labels' => [
				'name' => __('Groups', 'aukrug-connect'),
				'singular_name' => __('Group', 'aukrug-connect'),
			],
		]);

	\register_post_type('au_community_post', $common + [
			'labels' => [
				'name' => __('Community Posts', 'aukrug-connect'),
				'singular_name' => __('Community Post', 'aukrug-connect'),
			],
		]);

		// App-only Geocache CPT (never exported to OKAPI)
	\register_post_type('au_appcache', $common + [
			'labels' => [
				'name' => __('App Caches', 'aukrug-connect'),
				'singular_name' => __('App Cache', 'aukrug-connect'),
			],
		]);

		// Private report CPT (no REST)
		$report_args = $common;
		$report_args['show_in_rest'] = false;
	\register_post_type('au_report', $report_args + [
			'labels' => [
				'name' => __('Reports', 'aukrug-connect'),
				'singular_name' => __('Report', 'aukrug-connect'),
			],
			'capabilities' => [
				'create_posts' => 'manage_options',
				'edit_posts' => 'manage_options',
				'edit_others_posts' => 'manage_options',
				'publish_posts' => 'manage_options',
				'read_private_posts' => 'manage_options',
			],
		]);
	}

	public function registerMeta(): void
	{
		// coords for multiple CPTs
		$geo_types = ['au_place', 'au_route', 'au_event', 'au_provider', 'au_appcache'];
		foreach ($geo_types as $type) {
			// New canonical keys per spec
			\function_exists('register_post_meta') ? \call_user_func('register_post_meta', $type, 'coords_lat', [
				'show_in_rest' => [
					'schema' => ['type' => 'number'],
				],
				'single' => true,
				'type' => 'number',
				'auth_callback' => '__return_true',
			]) : null;
			\function_exists('register_post_meta') ? \call_user_func('register_post_meta', $type, 'coords_lng', [
				'show_in_rest' => [
					'schema' => ['type' => 'number'],
				],
				'single' => true,
				'type' => 'number',
				'auth_callback' => '__return_true',
			]) : null;
			// Back-compat legacy keys
			\function_exists('register_post_meta') ? \call_user_func('register_post_meta', $type, 'au_latitude', [
				'show_in_rest' => [
					'schema' => ['type' => 'number'],
				],
				'single' => true,
				'type' => 'number',
				'auth_callback' => '__return_true',
			]) : null;
			\function_exists('register_post_meta') ? \call_user_func('register_post_meta', $type, 'au_longitude', [
				'show_in_rest' => [
					'schema' => ['type' => 'number'],
				],
				'single' => true,
				'type' => 'number',
				'auth_callback' => '__return_true',
			]) : null;
		}

		// opening hours (stringified schedule)
	// canonical key
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_place', 'opening_hours', [
			'show_in_rest' => [
				'schema' => ['type' => 'string'],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
	// back-compat
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_place', 'au_opening_hours', [
			'show_in_rest' => [
				'schema' => ['type' => 'string'],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;

	// Place: accessibility_json, media_gallery[]
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_place', 'accessibility_json', [
			'show_in_rest' => [ 'schema' => ['type' => 'string'] ],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
		]) : null;
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_place', 'media_gallery', [
			'show_in_rest' => [ 'schema' => ['type' => 'array', 'items' => ['type' => 'integer']] ],
			'single' => true,
			'type' => 'array',
			'auth_callback' => '__return_true',
		]) : null;

	// Provider canonical opening_hours and fields
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_provider', 'opening_hours', [
			'show_in_rest' => [
				'schema' => ['type' => 'string'],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_provider', 'kind', [
			'show_in_rest' => [ 'schema' => ['type' => 'string'] ],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
		]) : null;
	foreach ([['phone','string'],['website','string'],['address','string']] as [$key,$type]) {
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_provider', $key, [
			'show_in_rest' => [ 'schema' => ['type' => $type] ],
			'single' => true,
			'type' => $type,
			'auth_callback' => '__return_true',
		]) : null;
	}
	// Back-compat provider keys
	foreach ([['au_opening_hours','string'],['au_kind','string'],['au_phone','string'],['au_website','string'],['au_address','string']] as [$key,$type]) {
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_provider', $key, [
			'show_in_rest' => [ 'schema' => ['type' => $type] ],
			'single' => true,
			'type' => $type,
			'auth_callback' => '__return_true',
		]) : null;
	}

		// notice severity + expires_at
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_notice', 'severity', [
			'show_in_rest' => [
				'schema' => ['type' => 'string', 'enum' => ['info', 'warn', 'critical']],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_notice', 'expires_at', [
				'show_in_rest' => [ 'schema' => ['type' => 'string', 'format' => 'date-time'] ],
				'single' => true,
				'type' => 'string',
				'auth_callback' => '__return_true',
			]) : null;
		// back-compat
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_notice', 'au_severity', [
				'show_in_rest' => [ 'schema' => ['type' => 'string'] ],
				'single' => true,
				'type' => 'string',
				'auth_callback' => '__return_true',
			]) : null;

		// route specifics (canonical)
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_route', 'type', [
			'show_in_rest' => [
				'schema' => ['type' => 'string', 'enum' => ['hike', 'bike']],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_route', 'distance_km', [
			'show_in_rest' => [
				'schema' => ['type' => 'number'],
			],
			'single' => true,
			'type' => 'number',
			'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_route', 'duration_min', [
			'show_in_rest' => [
				'schema' => ['type' => 'integer'],
			],
			'single' => true,
			'type' => 'integer',
			'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_route', 'track_url', [
			'show_in_rest' => [
					'schema' => ['type' => 'string', 'format' => 'uri'],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_route', 'track_format', [
				'show_in_rest' => [ 'schema' => ['type' => 'string', 'enum' => ['gpx','geojson']] ],
				'single' => true,
				'type' => 'string',
				'auth_callback' => '__return_true',
			]) : null;
		// back-compat legacy keys
		foreach (['au_route_type' => 'string', 'au_distance_km' => 'number', 'au_duration_min' => 'integer', 'au_gpx_url' => 'string', 'au_geojson_url' => 'string'] as $k => $t) {
			\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_route', $k, [
				'show_in_rest' => [ 'schema' => ['type' => $t] ],
				'single' => true,
				'type' => $t,
				'auth_callback' => '__return_true',
			]) : null;
		}

		// event specifics (canonical)
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_event', 'start', [
			'show_in_rest' => [
				'schema' => ['type' => 'string', 'format' => 'date-time'],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_event', 'end', [
			'show_in_rest' => [
				'schema' => ['type' => 'string', 'format' => 'date-time'],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_event', 'location_ref', [
				'show_in_rest' => [ 'schema' => ['type' => 'string'] ],
				'single' => true,
				'type' => 'string',
				'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_event', 'audiences', [
				'show_in_rest' => [ 'schema' => ['type' => 'array', 'items' => ['type' => 'string']] ],
				'single' => true,
				'type' => 'array',
				'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_event', 'ics_url', [
			'show_in_rest' => [
				'schema' => ['type' => 'string', 'format' => 'uri'],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
		// back-compat
		foreach (['au_start' => 'string','au_end' => 'string','au_ics_url' => 'string'] as $k => $t) {
			\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_event', $k, [
				'show_in_rest' => [ 'schema' => ['type' => $t] ],
				'single' => true,
				'type' => $t,
				'auth_callback' => '__return_true',
			]) : null;
		}

		// download specifics (canonical)
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_download', 'file_url', [
				'show_in_rest' => [ 'schema' => ['type' => 'string', 'format' => 'uri'] ],
				'single' => true,
				'type' => 'string',
				'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_download', 'audiences', [
				'show_in_rest' => [ 'schema' => ['type' => 'array', 'items' => ['type' => 'string']] ],
				'single' => true,
				'type' => 'array',
				'auth_callback' => '__return_true',
			]) : null;

		// back-compat download keys
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_download', 'au_url', [
			'show_in_rest' => [
				'schema' => ['type' => 'string', 'format' => 'uri'],
			],
			'single' => true,
			'type' => 'string',
			'auth_callback' => '__return_true',
			]) : null;
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_download', 'au_requires_auth', [
			'show_in_rest' => [ 'schema' => ['type' => 'boolean'] ],
			'single' => true,
			'type' => 'boolean',
			'auth_callback' => '__return_true',
			]) : null;
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_download', 'au_popular', [
			'show_in_rest' => [ 'schema' => ['type' => 'boolean'] ],
			'single' => true,
			'type' => 'boolean',
			'auth_callback' => '__return_true',
			]) : null;
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_download', 'au_size', [
			'show_in_rest' => [ 'schema' => ['type' => 'integer'] ],
			'single' => true,
			'type' => 'integer',
			'auth_callback' => '__return_true',
			]) : null;

		// group specifics
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_group', 'au_parent_group_id', [
			'show_in_rest' => [
				'schema' => ['type' => 'integer'],
			],
			'single' => true,
			'type' => 'integer',
			'auth_callback' => '__return_true',
			]) : null;
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_group', 'au_is_public', [
			'show_in_rest' => [
				'schema' => ['type' => 'boolean'],
			],
			'single' => true,
			'type' => 'boolean',
			'auth_callback' => '__return_true',
			]) : null;

		// report specifics (private)
	\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_report', 'au_report_category', [
			'show_in_rest' => false,
			'single' => true,
			'type' => 'string',
			]) : null;
		foreach ([['au_latitude','number'], ['au_longitude','number'], ['au_photo_url','string']] as [$k,$t]) {
				\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_report', $k, [
				'show_in_rest' => false,
				'single' => true,
				'type' => $t,
				]) : null;
		}

			// appcache specifics
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_appcache', 'difficulty', [
				'show_in_rest' => [ 'schema' => ['type' => 'string'] ],
				'single' => true,
				'type' => 'string',
				'auth_callback' => '__return_true',
			]) : null;
		\function_exists('register_post_meta') ? \call_user_func('register_post_meta', 'au_appcache', 'hint', [
				'show_in_rest' => [ 'schema' => ['type' => 'string'] ],
				'single' => true,
				'type' => 'string',
				'auth_callback' => '__return_true',
			]) : null;
	}
}

