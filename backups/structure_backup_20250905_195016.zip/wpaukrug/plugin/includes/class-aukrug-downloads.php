<?php
namespace Aukrug\Connect;

class Downloads
{
	public function init(): void
	{
		if (\function_exists('add_action')) {
			\add_action('rest_api_init', [$this, 'registerRoutes']);
		}
	}

	public function registerRoutes(): void
	{
		$ns = 'aukrug-connect/v1';
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/downloads', [
			'methods' => 'GET',
			'permission_callback' => '__return_true',
			'args' => [
				'search' => ['type' => 'string', 'required' => false],
				'category' => ['type' => 'string', 'required' => false],
				'popular' => ['type' => 'boolean', 'required' => false],
				'limit' => ['type' => 'integer', 'required' => false],
				'offset' => ['type' => 'integer', 'required' => false],
			],
			'callback' => function ($request) {
				$search = (string) ($request->get_param('search') ?? '');
				$category = (string) ($request->get_param('category') ?? '');
				$popular = $request->get_param('popular');
				$limit = (int) ($request->get_param('limit') ?? 50);
				$offset = (int) ($request->get_param('offset') ?? 0);

				$args = [
					'post_type' => 'au_download',
					'post_status' => 'publish',
					's' => $search ?: null,
					'posts_per_page' => max(1, min(100, $limit)),
					'offset' => max(0, $offset),
					'orderby' => 'date',
					'order' => 'DESC',
				];

				// Category filter via taxonomy
				if ($category) {
					$args['tax_query'] = [[
						'taxonomy' => 'au_download_category',
						'field' => 'slug',
						'terms' => $category,
					]];
				}

				// Popular filter via meta
				if ($popular !== null) {
					$args['meta_query'][] = [
						'key' => 'au_popular',
						'value' => $popular ? '1' : '0',
						'compare' => '=',
					];
				}

				$q = null;
				$wpq = '\\WP_Query';
				if (class_exists($wpq)) {
					$q = new $wpq($args);
				} else {
					return [ 'items' => [], 'total' => 0 ];
				}
				$items = [];
				foreach ($q->posts as $p) {
					$id = $p->ID;
					$title = \function_exists('get_the_title') ? (string) \call_user_func('get_the_title', $id) : '';
					$excerpt = \function_exists('wp_trim_words') ? (string) \call_user_func('wp_trim_words', strip_tags($p->post_content), 40) : '';
					$url = \function_exists('get_post_meta') ? (string) \call_user_func('get_post_meta', $id, 'au_url', true) : '';
					$requires = \function_exists('get_post_meta') ? (bool) \call_user_func('get_post_meta', $id, 'au_requires_auth', true) : false;
					$popularV = \function_exists('get_post_meta') ? (bool) \call_user_func('get_post_meta', $id, 'au_popular', true) : false;
					$size = \function_exists('get_post_meta') ? (int) \call_user_func('get_post_meta', $id, 'au_size', true) : 0;
					$cats = \function_exists('wp_get_post_terms') ? (array) \call_user_func('wp_get_post_terms', $id, 'au_download_category', ['fields' => 'slugs']) : [];
					$updated = \function_exists('get_post_modified_time') ? (string) \call_user_func('get_post_modified_time', 'c', true, $id) : '';
					$items[] = [
						'id' => (int) $id,
						'title' => $title,
						'excerpt' => $excerpt,
						'url' => $url,
						'requires_auth' => $requires,
						'popular' => $popularV,
						'size' => $size,
						'categories' => $cats,
						'updated_at' => $updated,
					];
				}
				$resp = [ 'items' => $items, 'total' => (int) $q->found_posts ];
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			},
		]); }
		// Single download resolver: returns URL if permitted, enforces requires_auth
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/download', [
			'methods' => 'GET',
			'permission_callback' => '__return_true',
			'args' => [ 'id' => ['type' => 'integer', 'required' => true] ],
			'callback' => function ($request) {
				$id = (int) ($request->get_param('id') ?? 0);
				if (!$id) { return [ 'error' => 'bad_request', 'status' => 400 ]; }
				$ptype = \function_exists('get_post_type') ? (string) \call_user_func('get_post_type', $id) : '';
				if ($ptype !== 'au_download') { return [ 'error' => 'not_found', 'status' => 404 ]; }
				$requires = \function_exists('get_post_meta') ? (bool) \call_user_func('get_post_meta', $id, 'au_requires_auth', true) : false;
				if ($requires) {
					$logged = \function_exists('is_user_logged_in') ? (bool) \call_user_func('is_user_logged_in') : false;
					if (!$logged) { return [ 'error' => 'unauthorized', 'status' => 401 ]; }
				}
				$url = \function_exists('get_post_meta') ? (string) \call_user_func('get_post_meta', $id, 'au_url', true) : '';
				if (!$url) { return [ 'error' => 'not_configured', 'status' => 404 ]; }
				// Increment hits counter (best-effort)
				if (\function_exists('get_post_meta') && \function_exists('update_post_meta')) {
					$hits = (int) \call_user_func('get_post_meta', $id, 'au_download_hits', true);
					\call_user_func('update_post_meta', $id, 'au_download_hits', $hits + 1);
				}
				$resp = [ 'id' => $id, 'url' => $url ];
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			}
		]); }

		// Optional proxy: issues 302 redirect to the file URL (auth-aware). Useful to hide direct URLs.
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/download-proxy', [
			'methods' => 'GET',
			'permission_callback' => '__return_true',
			'args' => [
				'id' => ['type' => 'integer', 'required' => true],
				'disposition' => ['type' => 'string', 'required' => false],
			],
			'callback' => function ($request) {
				$id = (int) ($request->get_param('id') ?? 0);
				$disposition = (string) ($request->get_param('disposition') ?? 'attachment');
				$resp = $this->buildDownloadProxyResponse($id, $disposition);
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			}
		]); }
		// Taxonomy listing for categories
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/download-categories', [
			'methods' => 'GET',
			'permission_callback' => '__return_true',
			'callback' => function () {
				$terms = \function_exists('get_terms') ? (array) \call_user_func('get_terms', [
					'taxonomy' => 'au_download_category',
					'hide_empty' => false,
				]) : [];
				$items = [];
				foreach ($terms as $t) {
					$items[] = [
						'id' => (int) ($t->term_id ?? 0),
						'slug' => (string) ($t->slug ?? ''),
						'name' => (string) ($t->name ?? ''),
						'count' => (int) ($t->count ?? 0),
					];
				}
				$resp = [ 'items' => $items ];
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			},
		]); }
	}

	/**
	 * Build an auth-aware redirect response for download proxying.
	 * Returns an array with 'status' and 'headers' keys when WP REST objects are not available.
	 */
	public function buildDownloadProxyResponse(int $id, string $disposition = 'attachment')
	{
		if ($id <= 0) { return [ 'error' => 'bad_request', 'status' => 400 ]; }
		$ptype = \function_exists('get_post_type') ? (string) \call_user_func('get_post_type', $id) : '';
		if ($ptype !== 'au_download') { return [ 'error' => 'not_found', 'status' => 404 ]; }
		$requires = \function_exists('get_post_meta') ? (bool) \call_user_func('get_post_meta', $id, 'au_requires_auth', true) : false;
		if ($requires) {
			$logged = \function_exists('is_user_logged_in') ? (bool) \call_user_func('is_user_logged_in') : false;
			if (!$logged) { return [ 'error' => 'unauthorized', 'status' => 401 ]; }
		}
		$url = \function_exists('get_post_meta') ? (string) \call_user_func('get_post_meta', $id, 'au_url', true) : '';
		if (!$url) { return [ 'error' => 'not_configured', 'status' => 404 ]; }
		// Increment hits (best-effort)
		if (\function_exists('get_post_meta') && \function_exists('update_post_meta')) {
			$hits = (int) \call_user_func('get_post_meta', $id, 'au_download_hits', true);
			\call_user_func('update_post_meta', $id, 'au_download_hits', $hits + 1);
		}
		$disp = strtolower($disposition) === 'inline' ? 'inline' : 'attachment';
		$filename = basename(parse_url($url, PHP_URL_PATH) ?: 'download');
		$headers = [
			'Location' => $url,
			'Content-Disposition' => $disp . '; filename="' . $filename . '"',
		];
		// If WP_REST_Response exists, use it to set headers + 302 (late-bound for analyzers)
		$respClass = '\\WP_REST_Response';
		if (class_exists($respClass)) {
			$resp = new $respClass(null, 302);
			if (method_exists($resp, 'header')) { foreach ($headers as $k => $v) { $resp->header($k, $v); } }
			return $resp;
		}
		return [ 'status' => 302, 'headers' => $headers ];
	}
}
