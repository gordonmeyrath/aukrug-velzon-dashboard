<?php
namespace Aukrug\Connect\Crypto;

class E2EE
{
	public function init(): void
	{
		if (\function_exists('add_action')) {
			\add_action('rest_api_init', [$this, 'registerRoutes']);
		}
		if (\function_exists('register_activation_hook')) {
			// create device registry table on activation via action
			\add_action('aukrug_connect_activate', [$this, 'migrate']);
		}
	}

	public function migrate(): void
	{
		if (!\function_exists('dbDelta') && defined('ABSPATH')) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}
		global $wpdb;
		if (!isset($wpdb)) { return; }
		$table = $wpdb->prefix . 'au_devices';
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			device_id varchar(128) NOT NULL,
			public_identity text NOT NULL,
			push_token varchar(255) NULL,
			platform varchar(32) NULL,
			web_endpoint text NULL,
			web_p256dh text NULL,
			web_auth text NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			UNIQUE KEY uniq_user_device (user_id, device_id),
			PRIMARY KEY (id)
		) {$charset};";
		if (\function_exists('dbDelta')) { \call_user_func('dbDelta', $sql); }
	}

	public function registerRoutes(): void
	{
		$ns = 'aukrug-connect/v1';
		// Register device (upsert). Auth required
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/devices', [
			'methods' => 'POST',
			'permission_callback' => function () { return \function_exists('is_user_logged_in') ? \call_user_func('is_user_logged_in') : false; },
			'args' => [
				'device_id' => ['type' => 'string', 'required' => true],
				'public_identity' => ['type' => 'string', 'required' => true],
				'push_token' => ['type' => 'string', 'required' => false],
				'platform' => ['type' => 'string', 'required' => false],
				'subscription' => ['type' => 'object', 'required' => false],
			],
			'callback' => function ($request) {
				$device_id = (string) $request->get_param('device_id');
				$identity = (string) $request->get_param('public_identity');
				$push = (string) ($request->get_param('push_token') ?? '');
				$platform = (string) ($request->get_param('platform') ?? '');
				$subscription = $request->get_param('subscription');
				$web_endpoint = '';
				$web_p256dh = '';
				$web_auth = '';
				if (is_array($subscription)) {
					$web_endpoint = (string) ($subscription['endpoint'] ?? '');
					$keys = (array) ($subscription['keys'] ?? []);
					$web_p256dh = (string) ($keys['p256dh'] ?? '');
					$web_auth = (string) ($keys['auth'] ?? '');
				}
				$uid = (\function_exists('get_current_user_id') ? (int) \call_user_func('get_current_user_id') : 0);
				if (!$uid) { return [ 'error' => 'unauthorized', 'status' => 401 ]; }
				global $wpdb; $table = $wpdb->prefix . 'au_devices';
				// Upsert using REPLACE to avoid duplicate insert when row exists with same values
				$wpdb->replace($table, [
					'user_id' => $uid,
					'device_id' => $device_id,
					'public_identity' => $identity,
					'push_token' => $push,
					'platform' => $platform,
					'web_endpoint' => $web_endpoint,
					'web_p256dh' => $web_p256dh,
					'web_auth' => $web_auth,
				]);
				$resp = [ 'ok' => true ];
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			},
		]); }

		// Lookup identities for user IDs (for small group fanout addressing)
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/identities', [
			'methods' => 'GET',
			'permission_callback' => function () { return \function_exists('current_user_can') ? \call_user_func('current_user_can', 'read') : false; },
			'args' => [ 'user_ids' => ['type' => 'array', 'required' => true, 'items' => ['type' => 'integer']] ],
			'callback' => function ($request) {
				$ids = (array) $request->get_param('user_ids');
				$ids = array_map('intval', $ids);
				if (!$ids) { return [ 'items' => [] ]; }
				global $wpdb; $table = $wpdb->prefix . 'au_devices';
				$in = implode(',', array_fill(0, count($ids), '%d'));
				$sql = $wpdb->prepare("SELECT user_id, device_id, public_identity, push_token, platform FROM {$table} WHERE user_id IN ($in)", ...$ids);
				$rows = $wpdb->get_results($sql, 'ARRAY_A');
				$resp = [ 'items' => $rows ];
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			},
		]); }

		// Public endpoint to fetch VAPID configuration for Web Push subscription
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/vapid', [
			'methods' => 'GET',
			'permission_callback' => '__return_true',
			'callback' => function () {
				$pub = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_vapid_public', '') : '';
				$subj = \function_exists('get_option') ? (string) \call_user_func('get_option', 'au_vapid_subject', 'mailto:admin@example.com') : 'mailto:admin@example.com';
				$resp = [ 'publicKey' => $pub, 'subject' => $subj ];
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			},
		]); }

		// Admin: list registered devices
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/admin/devices', [
			'methods' => 'GET',
			'permission_callback' => function () { return \function_exists('current_user_can') ? \call_user_func('current_user_can', 'manage_options') : false; },
			'args' => [ 'limit' => ['type' => 'integer', 'required' => false], 'user_id' => ['type' => 'integer', 'required' => false] ],
			'callback' => function ($request) {
				$limit = (int) ($request->get_param('limit') ?? 100);
				$limit = max(1, min(500, $limit));
				$userId = (int) ($request->get_param('user_id') ?? 0);
				global $wpdb; $table = $wpdb->prefix . 'au_devices';
				if ($userId > 0) {
					$sql = $wpdb->prepare("SELECT id, user_id, device_id, platform, (push_token IS NOT NULL AND push_token <> '') AS has_push, (web_endpoint IS NOT NULL AND web_endpoint <> '') AS has_web, created_at, updated_at FROM {$table} WHERE user_id = %d ORDER BY updated_at DESC LIMIT %d", $userId, $limit);
				} else {
					$sql = $wpdb->prepare("SELECT id, user_id, device_id, platform, (push_token IS NOT NULL AND push_token <> '') AS has_push, (web_endpoint IS NOT NULL AND web_endpoint <> '') AS has_web, created_at, updated_at FROM {$table} ORDER BY updated_at DESC LIMIT %d", $limit);
				}
				$rows = $wpdb->get_results($sql, 'ARRAY_A');
				$resp = [ 'items' => array_map(function($r){
					$r['id'] = (int) $r['id']; $r['user_id'] = (int) $r['user_id']; $r['has_push'] = (bool) $r['has_push']; $r['has_web'] = (bool) $r['has_web'];
					return $r;
				}, $rows) ];
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			}
		]); }

		// Admin: delete a device by id
		if (\function_exists('register_rest_route')) { \call_user_func('register_rest_route', $ns, '/admin/devices', [
			'methods' => 'DELETE',
			'permission_callback' => function () { return \function_exists('current_user_can') ? \call_user_func('current_user_can', 'manage_options') : false; },
			'args' => [ 'id' => ['type' => 'integer', 'required' => true] ],
			'callback' => function ($request) {
				$id = (int) ($request->get_param('id') ?? 0);
				if ($id <= 0) { return [ 'error' => 'bad_request', 'status' => 400 ]; }
				global $wpdb; $table = $wpdb->prefix . 'au_devices';
				$deleted = $wpdb->delete($table, [ 'id' => $id ], [ '%d' ]);
				$resp = [ 'ok' => (bool) $deleted ];
				return (\function_exists('rest_ensure_response') ? \call_user_func('rest_ensure_response', $resp) : $resp);
			}
		]); }
	}
}
