<?php
namespace Aukrug\Connect;

class Reports { public function init(): void {} }
