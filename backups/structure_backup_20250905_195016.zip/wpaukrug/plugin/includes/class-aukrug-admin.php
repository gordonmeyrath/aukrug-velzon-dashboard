<?php
namespace Aukrug\Connect;

class Admin
{
    public function init(): void
    {
        // Placeholder: main admin dashboard rendered via Settings::renderPage and assets
    }
}
