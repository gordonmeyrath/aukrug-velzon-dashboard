<?php
namespace Aukrug\Connect;

class Migrations
{
	public function init(): void
	{
		// Reserved for runtime migrations or checks if needed later.
	}

	public function run(): void
	{
		if (!\function_exists('dbDelta')) {
			// Load dbDelta
			if (defined('ABSPATH')) {
				require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			}
		}

		global $wpdb;
		if (!isset($wpdb)) {
			return; // Should not happen in WP context
		}

		$charset_collate = $wpdb->get_charset_collate();

		$changes_table = $wpdb->prefix . 'au_changes';
		$tomb_table = $wpdb->prefix . 'au_tombstones';

		$sql_changes = "CREATE TABLE {$changes_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			entity_type varchar(64) NOT NULL,
			entity_id varchar(64) NOT NULL,
			action varchar(16) NOT NULL,
			payload longtext NULL,
			user_id bigint(20) unsigned NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY entity (entity_type, entity_id),
			KEY created_at (created_at)
		) {$charset_collate};";

		$sql_tomb = "CREATE TABLE {$tomb_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			entity_type varchar(64) NOT NULL,
			entity_id varchar(64) NOT NULL,
			deleted_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY uniq_entity (entity_type, entity_id)
		) {$charset_collate};";

		if (\function_exists('dbDelta')) {
			\call_user_func('dbDelta', $sql_changes);
			\call_user_func('dbDelta', $sql_tomb);
		}

		// Store a simple schema version for future upgrades
		if (\function_exists('update_option')) {
			\call_user_func('update_option', 'aukrug_connect_db_version', '1.0');
		}
	}
}

