<?php
// Dashboard page wrapper (rendered by Settings::renderPage via JS SPA).
