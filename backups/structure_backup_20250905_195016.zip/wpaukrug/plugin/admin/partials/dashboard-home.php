<?php
// Dashboard Home partial (SPA uses JS; this is a placeholder for server render fallback).
