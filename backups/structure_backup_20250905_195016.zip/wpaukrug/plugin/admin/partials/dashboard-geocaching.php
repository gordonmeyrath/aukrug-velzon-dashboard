<?php
// Geocaching partial placeholder: OKAPI status, mini map (Leaflet), app caches list.
