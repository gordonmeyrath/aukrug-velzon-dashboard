(function () {
    if (!window.AU_ADMIN || !window.wp || !window.wp.apiFetch) return;
    const el = document.getElementById('au-admin-app');
    if (!el) return;

    const TABS = [
        { id: 'general', label: 'Allgemein' },
        { id: 'push', label: 'Push' },
        { id: 'apns', label: 'APNs' },
        { id: 'webpush', label: 'Web Push' },
        { id: 'downloads', label: 'Downloads' },
        { id: 'appcaches', label: 'App-Caches' },
        { id: 'devices', label: 'Geräte' },
        { id: 'reports', label: 'Meldungen' },
        { id: 'sync', label: 'Sync' },
        { id: 'advanced', label: 'Erweitert' }
    ];

    let state = {
        active: 'general',
        loading: true,
        saving: false,
        msg: '',
        toasts: [],
        data: {},
        summary: { counts: null, loading: false },
        downloads: { items: [], categories: [], filters: { search: '', category: '', popular: false }, loading: false },
        appcaches: {
            items: [], total: 0, loading: false, page: 1, per_page: 20, search: '',
            near_lat: '', near_lng: '', near_radius: '',
            form: { id: 0, title: '', content: '', coords_lat: '', coords_lng: '', audience: '' }, saving: false,
            errors: []
        },
        devices: { items: [], loading: false },
        sync: { delta: [], tombstones: [], loading: false },
        reports: { submitting: false }
    };

    function h(tag, attrs, ...children) {
        const n = document.createElement(tag);
        if (attrs) for (const k in attrs) {
            if (k === 'class') n.className = attrs[k];
            else if (k === 'onclick') n.addEventListener('click', attrs[k]);
            else n.setAttribute(k, attrs[k]);
        }
        children.flat().forEach(c => n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c));
        return n;
    }

    function field(label, input, errorText) {
        const wrap = h('div', { class: 'au-field' }, h('label', null, label), input);
        if (errorText) wrap.appendChild(h('div', { class: 'au-field-error' }, String(errorText)));
        return wrap;
    }

    function inputText(name, value, attrs) {
        const i = h('input', Object.assign({ type: 'text', value: value || '' }, attrs));
        i.addEventListener('input', () => { state.data[name] = i.value; });
        return i;
    }
    function inputNumber(name, value, attrs) {
        const i = h('input', Object.assign({ type: 'number', value: value ?? 0 }, attrs));
        i.addEventListener('input', () => { state.data[name] = parseInt(i.value || '0', 10); });
        return i;
    }
    function inputTextarea(name, value, attrs) {
        const i = h('textarea', Object.assign({}, attrs), value || '');
        i.addEventListener('input', () => { state.data[name] = i.value; });
        return i;
    }
    function select(name, value, options) {
        const s = h('select');
        options.forEach(([val, label]) => {
            const o = h('option', { value: val }, label);
            if (val === value) o.selected = true;
            s.appendChild(o);
        });
        s.addEventListener('change', () => { state.data[name] = s.value; render(); });
        return s;
    }

    // Toasts
    function toast(text, kind = 'info') {
        const id = Date.now() + Math.random();
        state.toasts.push({ id, text, kind });
        renderToasts();
        setTimeout(() => { state.toasts = state.toasts.filter(t => t.id !== id); renderToasts(); }, 3500);
    }
    function renderToasts() {
        let c = document.getElementById('au-toasts');
        if (!c) { c = h('div', { id: 'au-toasts', class: 'au-toasts' }); document.body.appendChild(c); }
        c.innerHTML = '';
        state.toasts.forEach(t => c.appendChild(h('div', { class: 'au-toast ' + (t.kind || 'info') }, t.text)));
    }
    function paginate(total, page, perPage) {
        const from = total ? ((page - 1) * perPage + 1) : (0);
        const to = Math.min(total || (page * perPage), (page - 1) * perPage + perPage);
        const isLast = total ? (page * perPage >= total) : false;
        return { from, to, isLast };
    }

    // Admin Summary
    async function loadSummary() {
        state.summary.loading = true; render();
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'admin/summary', headers: { 'X-WP-Nonce': AU_ADMIN.nonce } });
            state.summary.counts = (res && res.counts) || null;
        } catch (e) { state.msg = 'Übersicht laden fehlgeschlagen'; }
        state.summary.loading = false; render();
    }

    function summaryView() {
        if (state.summary.loading) return h('div', { class: 'au-panel' }, 'Übersicht lädt…');
        const c = state.summary.counts || {};
        const items = [
            ['Downloads', c.downloads || 0],
            ['Gruppen', c.groups || 0],
            ['Meldungen', c.reports || 0],
            ['Änderungen', c.changes || 0],
            ['Gelöscht', c.tombstones || 0],
            ['Geräte', c.devices || 0]
        ];
        const grid = h('div', { class: 'au-list' }, ...items.map(([label, val]) =>
            h('div', { class: 'au-list-item' },
                h('div', { class: 'au-list-title' }, String(val)),
                h('div', { class: 'au-list-sub' }, label)
            )
        ));
        return h('div', null,
            h('div', { class: 'au-actions' }, h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); loadSummary(); } }, 'Aktualisieren')),
            grid
        );
    }

    function panelGeneral() {
        // EXIF Toggle select (1/0)
        const exifOptions = [['1', 'EXIF entfernen (empfohlen)'], ['0', 'EXIF beibehalten']];
        return [
            h('h3', null, 'Übersicht'),
            summaryView(),
            h('h3', null, 'Allgemeine Einstellungen'),
            field('Rate Limit Anzahl', inputNumber('au_rate_limit_count', state.data.au_rate_limit_count, { min: 1 })),
            field('Rate Limit Fenster (Sekunden)', inputNumber('au_rate_limit_window', state.data.au_rate_limit_window, { min: 60, step: 60 })),
            field('Fotos – EXIF', (function () { const s = select('au_strip_exif', String(state.data.au_strip_exif ?? '1'), exifOptions); s.addEventListener('change', () => { state.data.au_strip_exif = s.value; }); return s; })())
        ];
    }
    function panelPush() {
        return [
            field('Provider', select('au_push_provider', state.data.au_push_provider, [
                ['fcm', 'FCM'], ['apns', 'APNs'], ['webpush', 'Web Push']
            ])),
            field('FCM Server Key', inputText('au_fcm_server_key', state.data.au_fcm_server_key, { placeholder: 'AAAA...' }))
        ];
    }
    function panelAPNs() {
        return [
            field('APNs Team ID', inputText('au_apns_team_id', state.data.au_apns_team_id)),
            field('APNs Key ID', inputText('au_apns_key_id', state.data.au_apns_key_id)),
            field('APNs Topic (Bundle ID)', inputText('au_apns_topic', state.data.au_apns_topic)),
            field('APNs .p8 Private Key', inputTextarea('au_apns_p8', state.data.au_apns_p8, { rows: 6 }))
        ];
    }
    function panelWebPush() {
        return [
            field('VAPID Public Key', inputText('au_vapid_public', state.data.au_vapid_public)),
            field('VAPID Private Key', inputText('au_vapid_private', state.data.au_vapid_private)),
            field('VAPID Subject', inputText('au_vapid_subject', state.data.au_vapid_subject))
        ];
    }

    // Downloads Tab
    async function loadDownloadCategoriesOnce() {
        if (state.downloads.categories && state.downloads.categories.length) return;
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'download-categories' });
            state.downloads.categories = (res && res.items) || [];
        } catch (e) { }
    }
    async function loadDownloads() {
        state.downloads.loading = true; render();
        const f = state.downloads.filters || {};
        const params = new URLSearchParams();
        if (f.search) params.set('search', f.search);
        if (f.category) params.set('category', f.category);
        if (f.popular) params.set('popular', '1');
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'downloads?' + params.toString() });
            state.downloads.items = (res && res.items) || [];
        } catch (e) {
            state.msg = 'Downloads laden fehlgeschlagen';
        }
        state.downloads.loading = false; render();
    }
    function panelDownloads() {
        const f = state.downloads.filters;
        const cats = state.downloads.categories;
        const list = state.downloads.loading ? h('div', { class: 'au-panel' }, 'Lade…') : h('div', { class: 'au-list' },
            ...state.downloads.items.map(it => h('div', { class: 'au-list-item' },
                h('div', { class: 'au-list-title' }, it.title || ('Download #' + it.id)),
                h('div', { class: 'au-list-sub' }, (it.excerpt || '').toString()),
                h('div', { class: 'au-list-actions' },
                    h('a', { class: 'au-button', href: it.url || '#', target: '_blank' }, 'Öffnen'),
                    h('a', { class: 'au-button', style: 'margin-left:8px', href: (AU_ADMIN.root + 'download-proxy?id=' + it.id), target: '_blank' }, 'Proxy')
                )
            ))
        );
        const catOptions = [['', 'Alle Kategorien'], ...cats.map(c => [c.slug, c.name + ' (' + c.count + ')'])];
        return [
            field('Suche', (function () { const i = inputText('au_dl_search', f.search, { placeholder: 'Suchbegriff' }); i.addEventListener('input', () => { f.search = i.value; }); return i; })()),
            field('Kategorie', (function () { const s = select('au_dl_cat', f.category, catOptions); s.addEventListener('change', () => { f.category = s.value; }); return s; })()),
            field('Beliebt', (function () { const s = h('select');[['0', 'Alle'], ['1', 'Nur beliebt']].forEach(([v, l]) => { const o = h('option', { value: v }, l); if ((f.popular ? '1' : '0') === v) o.selected = true; s.appendChild(o); }); s.addEventListener('change', () => { f.popular = s.value === '1'; }); return s; })()),
            h('div', { class: 'au-actions' }, h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); loadDownloads(); } }, 'Filtern')),
            list
        ];
    }

    // App-Caches Tab
    async function loadAppcaches() {
        state.appcaches.loading = true; render();
        const p = state.appcaches;
        const params = new URLSearchParams();
        if (p.search) params.set('search', p.search);
        params.set('page', String(p.page));
        params.set('per_page', String(p.per_page));
        if (p.near_lat && p.near_lng && p.near_radius) {
            params.set('near', `${p.near_lat},${p.near_lng},${p.near_radius}`);
        }
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'appcaches?' + params.toString() });
            p.items = (res && res.items) || [];
            p.total = (res && typeof res.total === 'number') ? res.total : (p.items.length + ((p.page - 1) * p.per_page));
        } catch (e) { state.msg = 'App-Caches laden fehlgeschlagen'; }
        state.appcaches.loading = false; render();
    }
    function editAppcache(it) {
        const f = state.appcaches.form;
        f.id = it.id || 0; f.title = it.title || '';
        f.content = (it.meta && (it.meta.content || '')) || '';
        f.coords_lat = (it.meta && it.meta.coords_lat) || '';
        f.coords_lng = (it.meta && it.meta.coords_lng) || '';
        f.audience = Array.isArray(it.meta?.audience) ? it.meta.audience.join(',') : (it.meta?.audience || '');
        render();
    }
    async function saveAppcache() {
        const f = state.appcaches.form;
        // Inline validation
        const errs = [];
        if (!f.title || !String(f.title).trim()) errs.push('title_required');
        const latOK = (f.coords_lat === '' || (!isNaN(parseFloat(f.coords_lat)) && parseFloat(f.coords_lat) >= -90 && parseFloat(f.coords_lat) <= 90));
        const lngOK = (f.coords_lng === '' || (!isNaN(parseFloat(f.coords_lng)) && parseFloat(f.coords_lng) >= -180 && parseFloat(f.coords_lng) <= 180));
        if (!latOK) errs.push('coords_lat_invalid');
        if (!lngOK) errs.push('coords_lng_invalid');
        state.appcaches.errors = errs;
        if (errs.length) { render(); if (typeof toast === 'function') toast('Bitte Eingaben prüfen', 'warn'); return; }
        const body = {
            id: f.id || undefined,
            title: f.title,
            content: f.content,
            coords_lat: f.coords_lat ? parseFloat(String(f.coords_lat)) : undefined,
            coords_lng: f.coords_lng ? parseFloat(String(f.coords_lng)) : undefined,
            audience: (f.audience || '').split(',').map(s => s.trim()).filter(Boolean),
            status: 'publish'
        };
        state.appcaches.saving = true; state.msg = ''; state.appcaches.errors = []; render();
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'appcaches', method: 'POST', headers: { 'X-WP-Nonce': AU_ADMIN.nonce }, data: body });
            if (res && res.ok) {
                state.msg = `App-Cache ${res.updated ? 'aktualisiert' : 'erstellt'} (#${res.id})`;
                if (typeof toast === 'function') toast(state.msg, 'ok');
                // reset form and reload list
                state.appcaches.form = { id: 0, title: '', content: '', coords_lat: '', coords_lng: '', audience: '' };
                state.appcaches.errors = [];
                await loadAppcaches();
            } else {
                state.msg = 'Speichern fehlgeschlagen'; if (typeof toast === 'function') toast('Speichern fehlgeschlagen', 'error');
                if (res && Array.isArray(res.errors)) state.appcaches.errors = res.errors;
            }
        } catch (e) { state.msg = 'Speichern fehlgeschlagen'; if (typeof toast === 'function') toast('Speichern fehlgeschlagen', 'error'); }
        state.appcaches.saving = false; render();
    }
    function panelAppcaches() {
        const p = state.appcaches;
        const list = p.loading ? h('div', { class: 'au-panel' }, 'Lade…') : h('div', { class: 'au-list' },
            ...p.items.map(it => h('div', { class: 'au-list-item' },
                h('div', { class: 'au-list-title' }, it.title || ('Eintrag #' + it.id)),
                h('div', { class: 'au-list-sub' }, (it.updated_at || '')),
                h('div', { class: 'au-list-actions' },
                    h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); editAppcache(it); } }, 'Bearbeiten'),
                    h('button', {
                        class: 'au-button', style: 'margin-left:8px', onclick: async (e) => {
                            e.preventDefault();
                            if (!window.confirm('Diesen App-Cache wirklich löschen?')) { return; }
                            try {
                                const res = await wp.apiFetch({ path: AU_ADMIN.root + 'appcaches?id=' + encodeURIComponent(it.id), method: 'DELETE', headers: { 'X-WP-Nonce': AU_ADMIN.nonce } });
                                if (res && res.ok) {
                                    state.msg = 'Gelöscht'; if (typeof toast === 'function') toast('App-Cache gelöscht', 'ok');
                                    await loadAppcaches();
                                } else { state.msg = 'Löschen fehlgeschlagen'; if (typeof toast === 'function') toast('Löschen fehlgeschlagen', 'error'); }
                            } catch (e) { state.msg = 'Löschen fehlgeschlagen'; if (typeof toast === 'function') toast('Löschen fehlgeschlagen', 'error'); }
                            render();
                        }
                    }, 'Löschen')
                )
            ))
        );
        const f = p.form;
        const errSet = new Set(p.errors || []);
        const form = h('div', { class: 'au-panel' },
            h('h3', null, f.id ? ('Bearbeite #' + f.id) : 'Neu anlegen'),
            (p.errors && p.errors.length ? h('div', { class: 'au-error-list' }, ...p.errors.map(err => h('div', { class: 'au-error' }, String(err)))) : null),
            field('Titel', (function () { const i = inputText('au_appc_title', f.title, { placeholder: 'Titel' }); i.addEventListener('input', () => { f.title = i.value; }); return i; })(), errSet.has('title_required') ? 'Titel ist erforderlich' : ''),
            field('Inhalt', (function () { const t = inputTextarea('au_appc_content', f.content, { rows: 4 }); t.addEventListener('input', () => { f.content = t.value; }); return t; })()),
            field('Breite (Lat)', (function () { const i = inputText('au_appc_lat', f.coords_lat, { placeholder: 'z.B. 54.123', inputmode: 'decimal' }); i.addEventListener('input', () => { f.coords_lat = i.value; }); return i; })(), errSet.has('coords_lat_invalid') ? 'Ungültige Breite (−90 bis 90)' : ''),
            field('Länge (Lng)', (function () { const i = inputText('au_appc_lng', f.coords_lng, { placeholder: 'z.B. 9.876', inputmode: 'decimal' }); i.addEventListener('input', () => { f.coords_lng = i.value; }); return i; })(), errSet.has('coords_lng_invalid') ? 'Ungültige Länge (−180 bis 180)' : ''),
            field('Audience (Komma-getrennt)', (function () { const i = inputText('au_appc_audience', f.audience, { placeholder: 'tourist,resident' }); i.addEventListener('input', () => { f.audience = i.value; }); return i; })()),
            h('div', { class: 'au-actions' }, h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); saveAppcache(); } }, p.saving ? 'Speichern…' : 'Speichern'),
                f.id ? h('button', { class: 'au-button', style: 'margin-left:8px', onclick: (e) => { e.preventDefault(); state.appcaches.form = { id: 0, title: '', content: '', coords_lat: '', coords_lng: '', audience: '' }; render(); } }, 'Neu') : null)
        );
        const { from, to, isLast } = paginate(p.total, p.page, p.per_page);
        const pager = h('div', { class: 'au-actions' },
            h('button', { class: 'au-button', disabled: p.page <= 1, onclick: (e) => { e.preventDefault(); if (p.page > 1) { p.page -= 1; loadAppcaches(); } } }, 'Zurück'),
            h('span', { style: 'margin:0 12px' }, `Seite ${p.page} • ${from}-${to} von ${p.total || '…'}`),
            h('button', { class: 'au-button', disabled: isLast, onclick: (e) => { e.preventDefault(); if (!isLast) { p.page += 1; loadAppcaches(); } } }, 'Weiter')
        );
        const perPage = field('Pro Seite', (function () { const s = h('select');[10, 20, 50].forEach(n => { const o = h('option', { value: String(n) }, String(n)); if (n === p.per_page) o.selected = true; s.appendChild(o); }); s.addEventListener('change', () => { p.per_page = parseInt(s.value, 10) || 20; p.page = 1; }); return s; })());
        const nearControls = h('div', { class: 'au-inline' },
            field('Nahe (Lat)', (function () { const i = inputText('au_appc_near_lat', p.near_lat, { placeholder: 'z.B. 54.123', inputmode: 'decimal' }); i.addEventListener('input', () => { p.near_lat = i.value; }); return i; })()),
            field('Nahe (Lng)', (function () { const i = inputText('au_appc_near_lng', p.near_lng, { placeholder: 'z.B. 9.876', inputmode: 'decimal' }); i.addEventListener('input', () => { p.near_lng = i.value; }); return i; })()),
            field('Radius km', (function () { const i = inputText('au_appc_near_radius', p.near_radius, { placeholder: 'z.B. 2', inputmode: 'decimal' }); i.addEventListener('input', () => { p.near_radius = i.value; }); return i; })())
        );
        return [
            field('Suche', (function () { const i = inputText('au_appc_search', p.search, { placeholder: 'Suchbegriff' }); i.addEventListener('input', () => { p.search = i.value; }); return i; })()),
            perPage,
            nearControls,
            h('div', { class: 'au-actions' },
                h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); p.page = 1; loadAppcaches(); } }, 'Aktualisieren'),
                h('button', { class: 'au-button', style: 'margin-left:8px', onclick: (e) => { e.preventDefault(); p.near_lat = p.near_lng = p.near_radius = ''; p.page = 1; loadAppcaches(); } }, 'Nahe zurücksetzen')
            ),
            list,
            pager,
            form
        ];
    }

    // Devices Tab
    async function loadDevices() {
        state.devices.loading = true; render();
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'admin/devices?limit=100', headers: { 'X-WP-Nonce': AU_ADMIN.nonce } });
            state.devices.items = (res && res.items) || [];
        } catch (e) { state.msg = 'Geräte laden fehlgeschlagen'; }
        state.devices.loading = false; render();
    }
    async function deleteDevice(id) {
        try {
            await wp.apiFetch({ path: AU_ADMIN.root + 'admin/devices?id=' + encodeURIComponent(id), method: 'DELETE', headers: { 'X-WP-Nonce': AU_ADMIN.nonce } });
            state.devices.items = state.devices.items.filter(d => d.id !== id);
            state.msg = 'Gerät entfernt'; if (typeof toast === 'function') toast('Gerät entfernt', 'ok');
        } catch (e) { state.msg = 'Entfernen fehlgeschlagen'; }
        render();
    }
    function panelDevices() {
        if (state.devices.loading) return [h('div', { class: 'au-panel' }, 'Lade…')];
        const rows = state.devices.items.map(d => h('div', { class: 'au-list-item' },
            h('div', { class: 'au-list-title' }, `User #${d.user_id} – ${d.platform || 'unbekannt'}`),
            h('div', { class: 'au-list-sub' }, `${d.device_id}`),
            h('div', { class: 'au-list-actions' },
                h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); if (window.confirm('Dieses Gerät wirklich entfernen?')) deleteDevice(d.id); } }, 'Entfernen')
            )
        ));
        return [
            h('div', { class: 'au-actions' }, h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); loadDevices(); } }, 'Aktualisieren')),
            h('div', { class: 'au-list' }, ...rows)
        ];
    }

    // Reports Tab
    async function submitReport(formVals) {
        state.reports.submitting = true; state.msg = ''; render();
        const fd = new FormData();
        if (formVals.category) fd.append('category', formVals.category);
        if (formVals.lat) fd.append('lat', String(formVals.lat));
        if (formVals.long) fd.append('long', String(formVals.long));
        if (formVals.photo) fd.append('photo', formVals.photo);
        try {
            const res = await fetch(AU_ADMIN.root + 'reports', {
                method: 'POST',
                headers: { 'X-WP-Nonce': AU_ADMIN.nonce },
                body: fd
            });
            const data = await res.json();
            if (res.ok && data && data.id) {
                state.msg = 'Meldung erstellt (#' + data.id + ')'; if (typeof toast === 'function') toast(state.msg, 'ok');
            } else {
                state.msg = 'Meldung fehlgeschlagen'; if (typeof toast === 'function') toast('Meldung fehlgeschlagen', 'error');
            }
        } catch (e) {
            state.msg = 'Meldung fehlgeschlagen'; if (typeof toast === 'function') toast('Meldung fehlgeschlagen', 'error');
        }
        state.reports.submitting = false; render();
    }
    function panelReports() {
        const vals = { category: state.data.au_report_category || '', lat: '', long: '', photo: null };
        const cat = inputText('au_report_category', vals.category, { placeholder: 'Kategorie (optional)' });
        const ilat = inputNumber('au_report_lat', '', { step: 'any', placeholder: 'Breite' });
        const ilon = inputNumber('au_report_long', '', { step: 'any', placeholder: 'Länge' });
        const file = h('input', { type: 'file', accept: 'image/*' });
        file.addEventListener('change', () => { vals.photo = file.files && file.files[0]; });
        const onSubmit = (e) => { e.preventDefault(); vals.category = cat.value; vals.lat = parseFloat(ilat.value || ''); vals.long = parseFloat(ilon.value || ''); submitReport(vals); };
        return [
            field('Kategorie', cat),
            field('Breite (Lat)', ilat),
            field('Länge (Long)', ilon),
            field('Foto', file),
            h('div', { class: 'au-actions' }, h('button', { class: 'au-button', onclick: onSubmit }, state.reports.submitting ? 'Sende…' : 'Senden'))
        ];
    }

    // Sync Tab
    async function loadDelta() {
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'delta?limit=50' });
            state.sync.delta = (res && res.items) || [];
        } catch (e) { state.msg = 'Delta laden fehlgeschlagen'; }
        render();
    }
    async function loadTombstones() {
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'tombstones?limit=50' });
            state.sync.tombstones = (res && res.items) || [];
        } catch (e) { state.msg = 'Tombstones laden fehlgeschlagen'; }
        render();
    }
    function panelSync() {
        const deltaList = h('div', { class: 'au-list' }, ...state.sync.delta.map(r => h('div', { class: 'au-list-item' }, `${r.entity_type}#${r.entity_id} – ${r.action} – ${r.created_at}`)));
        const tombList = h('div', { class: 'au-list' }, ...state.sync.tombstones.map(r => h('div', { class: 'au-list-item' }, `${r.entity_type}#${r.entity_id} – ${r.deleted_at}`)));
        return [
            h('div', { class: 'au-actions' },
                h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); loadDelta(); } }, 'Letzte Änderungen'),
                h('button', { class: 'au-button', style: 'margin-left:8px', onclick: (e) => { e.preventDefault(); loadTombstones(); } }, 'Gelöschte Einträge')
            ),
            h('h3', null, 'Delta'),
            deltaList,
            h('h3', null, 'Tombstones'),
            tombList
        ];
    }
    async function runHealthCheck() {
        state.msg = '';
        render();
        try {
            const res = await wp.apiFetch({ path: AU_ADMIN.root + 'admin/health', headers: { 'X-WP-Nonce': AU_ADMIN.nonce } });
            const items = [];
            items.push(h('div', { class: 'au-health-item' }, `Provider: ${res.provider}`));
            items.push(h('div', { class: 'au-health-item' }, `FCM: ${res.fcm?.configured ? 'OK' : 'Fehlt'}`));
            items.push(h('div', { class: 'au-health-item' }, `APNs: ${res.apns?.configured ? 'OK' : 'Fehlt'}`));
            if (res.apns?.missing?.length) items.push(h('div', { class: 'au-health-item' }, 'APNs fehlt: ' + res.apns.missing.join(', ')));
            items.push(h('div', { class: 'au-health-item' }, `Web Push: ${res.webpush?.configured ? 'OK' : 'Fehlt'} (lib: ${res.webpush?.library})`));
            if (res.webpush?.missing?.length) items.push(h('div', { class: 'au-health-item' }, 'Web Push fehlt: ' + res.webpush.missing.join(', ')));
            // Clear previous result if any
            const container = document.getElementById('au-admin-app');
            const old = container && container.querySelector('.au-health-result');
            if (old) old.remove();
            const box = h('div', { class: 'au-panel au-health-result' },
                h('h3', null, res.overall_ok ? 'Konfiguration OK' : 'Konfiguration unvollständig'),
                ...items
            );
            if (container) container.appendChild(box);
        } catch (e) {
            state.msg = 'Health-Check fehlgeschlagen';
            render();
        }
    }

    async function sendTestPush() {
        try {
            const userId = AU_ADMIN.userId || 0;
            const body = {
                target_user_ids: userId ? [userId] : [],
                notification: { title: 'Test', body: 'Aukrug Connect Testnachricht' },
                data: { kind: 'test' }
            };
            const res = await wp.apiFetch({
                path: AU_ADMIN.root + 'relay',
                method: 'POST',
                headers: { 'X-WP-Nonce': AU_ADMIN.nonce },
                data: body
            });
            state.msg = res && res.ok ? `Test Push gesendet (${res.delivered})` : 'Test Push fehlgeschlagen';
            if (typeof toast === 'function') toast(state.msg, (res && res.ok) ? 'ok' : 'error');
        } catch (e) {
            state.msg = 'Test Push fehlgeschlagen'; if (typeof toast === 'function') toast('Test Push fehlgeschlagen', 'error');
        }
        render();
    }

    function panelAdvanced() {
        return [
            h('div', null, 'Werkzeuge'),
            h('div', { class: 'au-actions' },
                h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); runHealthCheck(); } }, 'Konfiguration prüfen'),
                h('button', { class: 'au-button', style: 'margin-left:8px', onclick: (e) => { e.preventDefault(); sendTestPush(); } }, 'Test Push an mich')
            )
        ];
    }

    function panels() {
        switch (state.active) {
            case 'push': return panelPush();
            case 'apns': return panelAPNs();
            case 'webpush': return panelWebPush();
            case 'downloads': return panelDownloads();
            case 'appcaches': return panelAppcaches();
            case 'reports': return panelReports();
            case 'devices': return panelDevices();
            case 'sync': return panelSync();
            case 'advanced': return panelAdvanced();
            default: return panelGeneral();
        }
    }

    function save() {
        state.saving = true; state.msg = '';
        render();
        return wp.apiFetch({
            path: AU_ADMIN.root + 'admin/settings',
            method: 'POST',
            headers: { 'X-WP-Nonce': AU_ADMIN.nonce },
            data: { data: state.data }
        }).then(() => {
            state.saving = false; state.msg = 'Gespeichert'; if (typeof toast === 'function') toast('Einstellungen gespeichert', 'ok'); render();
        }).catch(err => {
            state.saving = false; state.msg = 'Fehler: ' + (err && err.message || ''); if (typeof toast === 'function') toast('Speichern fehlgeschlagen', 'error'); render();
        });
    }

    function render() {
        el.innerHTML = '';
        const tabs = h('div', { class: 'au-tabs' },
            ...TABS.map(t => h('div', { class: 'au-tab' + (state.active === t.id ? ' active' : ''), onclick: () => { state.active = t.id; render(); } }, t.label))
        );
        const panel = h('div', { class: 'au-panel' }, ...panels());
        const actions = h('div', { class: 'au-actions' },
            h('button', { class: 'au-button', onclick: (e) => { e.preventDefault(); save(); } }, state.saving ? 'Speichern…' : 'Speichern'),
            h('span', { class: 'au-message' }, state.msg)
        );
        el.appendChild(tabs);
        if (state.loading) {
            el.appendChild(h('div', { class: 'au-panel' }, 'Lade…'));
            return;
        }
        el.appendChild(panel);
        el.appendChild(actions);
    }

    function load() {
        state.loading = true; render();
        wp.apiFetch({ path: AU_ADMIN.root + 'admin/settings', headers: { 'X-WP-Nonce': AU_ADMIN.nonce } })
            .then(data => { state.data = data || {}; state.loading = false; render(); })
            .catch(() => { state.loading = false; state.msg = 'Laden fehlgeschlagen'; render(); });
        // Preload download categories
        loadDownloadCategoriesOnce();
        // Load summary in background
        loadSummary();
        // Lazy-load appcaches list in background
        loadAppcaches();
    }

    render();
    load();
})();
