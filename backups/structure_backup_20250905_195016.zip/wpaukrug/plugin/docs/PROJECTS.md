# Projects


## SchnitzelJagd (NFC Journey)

- Scope: NFC-tagged journey with stations (UID binding), optional QR fallback.
- MVP: define journey and stations, validate tag IDs, client routes.
- API Sketch: (future) POST /nfc/journey, GET /nfc/journey/:id (commented until feature flag on)
- Rollout: hidden groundwork now; UI disabled. Enable after field testing.
