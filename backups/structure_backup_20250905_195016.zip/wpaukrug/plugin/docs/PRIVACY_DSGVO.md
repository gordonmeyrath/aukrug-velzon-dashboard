# PRIVACY DSGVO (placeholder)

Zero-storage messenger, client-side backups only. To be expanded in step 3.
